/**
 * split-dicts.mjs —— 把词库切成「计划索引 + 分片」，给网页版省流量
 *
 * 为什么需要：
 *   今日页要算「今天该背哪些词、哪些到期了」，必须知道**整本词书**有哪些词。
 *   但一本 CET-4 的完整数据是 4366 KB（带例句、词根词缀、真题…），
 *   在 40–95 KB/s 的链路上光这一个文件就要等好几分钟。
 *
 * 做法：每本词书额外产出两份东西（**原文件保持不动**，桌面版和旧的取词路径照常用）
 *
 *   dicts/<id>.plan.json       每个词只留 { name, trans }，只用来算计划和抽干扰项
 *                              CET-4: 4366 KB → 131 KB（gzip 后约 35 KB）
 *
 *   dicts/<id>/p00.json …      完整词对象，每片 128 个词
 *                              今日的会话只有 20–40 个词，命中 1–2 片就够
 *
 * ⚠️ plan 数组的**顺序必须与完整词库完全一致** —— 客户端靠「名字在 plan 里的下标」
 *    反推该词落在第几片。切的时候一定不能排序、不能过滤。
 *
 * 用法：node tools/split-dicts.mjs [--write]
 */

import { mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const DICT_DIR = join(ROOT, '_src', 'qwerty-learner', 'public', 'dicts')
const CHUNK_SIZE = 128
const WRITE = process.argv.includes('--write')

const files = readdirSync(DICT_DIR).filter((f) => f.endsWith('.json') && !f.endsWith('.plan.json'))
console.log(`词库目录：${DICT_DIR}`)
console.log(`找到 ${files.length} 本词书，分片大小 ${CHUNK_SIZE} 词/片${WRITE ? '' : '（演练模式，加 --write 才真写）'}\n`)

let totalPlanBefore = 0
let totalPlanAfter = 0

for (const f of files) {
  const id = f.replace(/\.json$/, '')
  const raw = readFileSync(join(DICT_DIR, f), 'utf8')
  const words = JSON.parse(raw)
  if (!Array.isArray(words)) {
    console.log(`  ✘ ${id} 不是数组，跳过`)
    continue
  }

  // 计划索引：只留 name + trans（补上空音标，保持 Word 结构合法）
  const plan = words.map((w) => ({ name: w.name, trans: w.trans ?? [], usphone: '', ukphone: '' }))

  // 分片：严格按原顺序切
  const chunks = []
  for (let i = 0; i < words.length; i += CHUNK_SIZE) chunks.push(words.slice(i, i + CHUNK_SIZE))

  const rawKB = Buffer.byteLength(raw) / 1024
  const planStr = JSON.stringify(plan)
  const planKB = Buffer.byteLength(planStr) / 1024
  totalPlanBefore += rawKB
  totalPlanAfter += planKB

  const chunkKB = chunks.map((c) => Buffer.byteLength(JSON.stringify(c)) / 1024)
  const maxChunk = Math.max(...chunkKB)
  const avgChunk = chunkKB.reduce((a, b) => a + b, 0) / chunkKB.length

  console.log(
    `  ${id.padEnd(30)} ${String(words.length).padStart(5)} 词   ` +
      `计划 ${String(Math.round(planKB)).padStart(4)} KB（原 ${String(Math.round(rawKB)).padStart(4)} KB）   ` +
      `${chunks.length} 片，平均 ${Math.round(avgChunk)} KB / 最大 ${Math.round(maxChunk)} KB`,
  )

  if (WRITE) {
    writeFileSync(join(DICT_DIR, `${id}.plan.json`), planStr, 'utf8')
    const dir = join(DICT_DIR, id)
    rmSync(dir, { recursive: true, force: true })
    mkdirSync(dir, { recursive: true })
    chunks.forEach((c, i) => {
      writeFileSync(join(dir, `p${String(i).padStart(2, '0')}.json`), JSON.stringify(c), 'utf8')
    })
  }
}

console.log(
  `\n合计：完整词库 ${Math.round(totalPlanBefore)} KB → 计划索引 ${Math.round(totalPlanAfter)} KB` +
    `（省 ${Math.round((1 - totalPlanAfter / totalPlanBefore) * 100)}%）`,
)
if (!WRITE) console.log('演练完成。加 --write 才会真的写文件。')
