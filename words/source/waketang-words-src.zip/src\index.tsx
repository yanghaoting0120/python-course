import Loading from './components/Loading'
import './index.css'
import TodayPage from './pages/Today'
import { isOpenDarkModeAtom } from '@/store'
import 'animate.css'
import { useAtomValue } from 'jotai'
import React, { Suspense, lazy, useEffect } from 'react'
import 'react-app-polyfill/stable'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, HashRouter, Navigate, Route, Routes } from 'react-router-dom'

/**
 * 路由级懒加载。
 *
 * 2026-10-06 改：原来只有 Analysis / Gallery / Recall 是 lazy 的，
 * **TodayPage 和 TypingPage 是静态 import** —— 于是打字页那一大串依赖
 * （howler、use-sound、@floating-ui、@headlessui、一堆 radix、canvas-confetti …）
 * 全被塞进首屏主包（实测 1338 KB，gzip 后 465 KB）。
 * 桌面版无所谓，但网页版在 40–95 KB/s 的链路上，主包每少 100 KB 就是少等十几秒。
 *
 * 首页只需要 TodayPage（依赖很轻），其余的按路由拆开。
 */
const TypingPage = lazy(() => import('./pages/Typing'))
const AnalysisPage = lazy(() => import('./pages/Analysis'))
const GalleryPage = lazy(() => import('./pages/Gallery-N'))
const RecallPage = lazy(() => import('./pages/Recall'))
const ErrorBook = lazy(() => import('./pages/ErrorBook').then((m) => ({ default: m.ErrorBook })))

// 蛙课堂背单词（本地自用）
// 相对原版的改动：
//   1. 移除 mixpanel / Vercel Analytics 全部外发埋点
//   2. 移除移动端落地页与「窗口变窄就跳转」的行为——桌面程序不需要
//   3. 移除 Google Analytics
//   4. /quiz（学完即测）改成 /recall（选词记忆）——与拼写并列的一条路，不再藏在打字结束后
//   5. 支持「网页版」构建：REACT_APP_DEPLOY_ENV=web 时改用 HashRouter

/**
 * 路由方式按部署环境选。
 *
 * 桌面版跑在 Electron 的 app:// 协议下，刷新 /typing 由主进程兜底回 index.html，
 * BrowserRouter 没问题，地址也干净。
 *
 * 但「蛙课堂网站」的背单词栏目是**静态托管**（GitHub Pages / 服务器静态目录）：
 * 在 /words/typing 上刷新会直接 404，因为静态服务器没有 SPA 回退。
 * 所以网页版构建改用 HashRouter —— 地址变成 /words/#/typing，刷新永远命中 index.html。
 */
const isWebDeploy = REACT_APP_DEPLOY_ENV === 'web'
const Router = isWebDeploy ? HashRouter : BrowserRouter

function Root() {
  const darkMode = useAtomValue(isOpenDarkModeAtom)
  useEffect(() => {
    darkMode ? document.documentElement.classList.add('dark') : document.documentElement.classList.remove('dark')
  }, [darkMode])

  return (
    <React.StrictMode>
      <Router basename={REACT_APP_DEPLOY_ENV === 'pages' ? '/waketang-words' : undefined}>
        <Suspense fallback={<Loading />}>
          <Routes>
            {/* 首页 = 今日计划；两条并列的路：选词记忆（先认脸）/ 拼写（上手打） */}
            <Route index element={<TodayPage />} />
            <Route path="/recall" element={<RecallPage />} />
            <Route path="/typing" element={<TypingPage />} />
            <Route path="/gallery" element={<GalleryPage />} />
            <Route path="/analysis" element={<AnalysisPage />} />
            <Route path="/error-book" element={<ErrorBook />} />
            <Route path="/*" element={<Navigate to="/" />} />
          </Routes>
        </Suspense>
      </Router>
    </React.StrictMode>
  )
}

const container = document.getElementById('root')

container && createRoot(container).render(<Root />)
