import HeatmapCharts from './components/HeatmapCharts'
import LineCharts from './components/LineCharts'
import { useWordStats } from './hooks/useWordStats'
import Header from '@/components/Header'
import Layout from '@/components/Layout'
import Setting from '@/components/Setting'
import { currentDictIdAtom, isOpenDarkModeAtom } from '@/store'
import { MASTERED_STAGE, SRS_INTERVALS } from '@/utils/srs'
import { useMemoryRecords } from '@/utils/db'
import dayjs from 'dayjs'
import { useAtom, useAtomValue } from 'jotai'
import { useCallback, useMemo } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import { Link, useNavigate } from 'react-router-dom'
import IconChartBar from '~icons/tabler/chart-bar'

/**
 * 统计页。
 *
 * 评审 B5 的四项：
 *   B5-1 加载态从"一行灰字"改成**骨架屏**（热力图这种大区块加载慢，灰字会让人觉得卡住了）
 *   B5-2 从"弹层（右上角 ×）"改为**独立页面**，与词库 / 错词本同一种出现方式
 *   B5-3 空数据有明确引导，而不是一片空白
 *   B5-4 移除打字类图表（WPM / 按键错误排行，与背单词无关），
 *        换成**记忆持久度分布** —— 每个阶段各有多少词，这正是"破除算法黑盒"的那个视图
 */

/** 记忆持久度分布：各阶段词数（纯 CSS 条形图，不需要 echarts） */
function MemoryDistribution() {
  const dictId = useAtomValue(currentDictIdAtom)
  const memory = useMemoryRecords(dictId)

  const { bars, total } = useMemo(() => {
    const counts = new Array(SRS_INTERVALS.length).fill(0) as number[]
    let mastered = 0
    for (const m of memory) {
      if (m.mastered || m.stage >= MASTERED_STAGE) mastered += 1
      else counts[Math.min(Math.max(m.stage, 0), SRS_INTERVALS.length - 1)] += 1
    }
    const bars = [
      ...counts.map((count, i) => ({ label: `${i + 1} 档`, hint: `${SRS_INTERVALS[i]} 天`, count })),
      { label: '已掌握', hint: '退出复习', count: mastered },
    ]
    return { bars, total: memory.length }
  }, [memory])

  if (total === 0) {
    return <p className="c-muted t-sm">还没有学习记录。</p>
  }

  const max = Math.max(1, ...bars.map((b) => b.count))

  return (
    <div className="flex flex-col gap-2">
      {bars.map((b) => (
        <div key={b.label} className="flex items-center gap-3">
          <span className="c-soft t-micro w-14 shrink-0 text-right">{b.label}</span>
          <div className="progress-track progress-sm flex-1">
            <div className="progress-fill" style={{ width: `${Math.round((b.count / max) * 100)}%` }} />
          </div>
          <span className="c-faint t-micro w-16 shrink-0 tabular-nums">
            {b.count} 词 · {b.hint}
          </span>
        </div>
      ))}
    </div>
  )
}

const Analysis = () => {
  const navigate = useNavigate()
  const [, setIsOpenDarkMode] = useAtom(isOpenDarkModeAtom)
  const dictId = useAtomValue(currentDictIdAtom)
  const memory = useMemoryRecords(dictId)

  const onBack = useCallback(() => {
    navigate('/')
  }, [navigate])

  const changeDarkModeState = () => {
    setIsOpenDarkMode((old) => !old)
  }

  useHotkeys(
    'ctrl+d',
    () => {
      changeDarkModeState()
    },
    { enableOnFormTags: true, preventDefault: true },
    [],
  )

  useHotkeys('enter,esc', onBack, { preventDefault: true })

  // ⚠️ 原版把 dayjs().unix() 直接写在调用参数里，而它每秒都在变，
  //    导致 useWordStats 里 useEffect 的依赖每秒变化 → 每秒重查一次 IndexedDB。
  //    这里固定住时间范围，只在挂载时计算一次。
  const [rangeStart, rangeEnd] = useMemo(() => [dayjs().subtract(1, 'year').unix(), dayjs().unix()], [])

  const { isLoading, isEmpty, error, exerciseRecord, accuracyRecord } = useWordStats(rangeStart, rangeEnd)

  const hasMemory = memory.length > 0

  return (
    <Layout>
      <Header>
        <Link className="btn-secondary btn-sm" to="/">
          返回今日
        </Link>
        <Setting />
      </Header>

      <div className="container-app flex min-h-0 flex-1 flex-col overflow-y-auto pb-10">
        {/* B5-4：记忆持久度分布 —— 放在最上面，这是最该被看见的一张图 */}
        <section className="glass mb-4 rounded-2xl px-5 py-4">
          <h2 className="c-ink t-sm mb-3 font-bold">记忆持久度分布</h2>
          <MemoryDistribution />
          <p className="c-faint t-micro mt-3">第 N 档 = 该词的复习间隔已排到 {SRS_INTERVALS.join(' / ')} 天中的第 N 档。</p>
        </section>

        {error ? (
          <div className="alert alert-danger">
            <span>统计数据读取失败：{error}</span>
          </div>
        ) : isLoading ? (
          // B5-1：骨架屏，形状与最终布局一致
          <div className="space-y-4">
            <div className="skeleton h-56 w-full" />
            <div className="skeleton h-56 w-full" />
            <div className="skeleton h-72 w-full" />
          </div>
        ) : isEmpty && !hasMemory ? (
          // B5-3：空状态有明确引导
          <div className="glass empty-state rounded-2xl">
            <span className="empty-state-icon">
              <IconChartBar className="h-7 w-7" />
            </span>
            <p className="empty-state-title">还没有练习记录</p>
            <p className="empty-state-desc">学习一天就会在这里出现你的记录。</p>
            <Link className="my-btn-primary mt-1" to="/">
              去今日页开始
            </Link>
          </div>
        ) : (
          <>
            <section className="glass mb-4 rounded-2xl px-5 py-5">
              <HeatmapCharts title="过去一年练习次数" data={exerciseRecord} />
            </section>
            <section className="glass mb-4 h-80 rounded-2xl px-5 py-5">
              <LineCharts title="正确率趋势" name="正确率(%)" data={accuracyRecord} suffix="%" />
            </section>
          </>
        )}
      </div>
    </Layout>
  )
}

export default Analysis
