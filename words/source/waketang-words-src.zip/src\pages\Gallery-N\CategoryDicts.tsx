import DictTagSwitcher from './DictTagSwitcher'
import DictionaryComponent from './DictionaryWithoutCover'
import { currentDictInfoAtom } from '@/store'
import type { Dictionary } from '@/typings'
import { findCommonValues } from '@/utils'
import { useAtomValue } from 'jotai'
import { useCallback, useEffect, useMemo, useState } from 'react'

export default function DictionaryGroup({ groupedDictsByTag }: { groupedDictsByTag: Record<string, Dictionary[]> }) {
  const tagList = useMemo(() => Object.keys(groupedDictsByTag), [groupedDictsByTag])
  const [currentTag, setCurrentTag] = useState(tagList.length > 0 ? tagList[0] : '')
  const currentDictInfo = useAtomValue(currentDictInfoAtom)

  const onChangeCurrentTag = useCallback((tag: string) => {
    setCurrentTag(tag)
  }, [])

  useEffect(() => {
    const commonTags = findCommonValues(tagList, currentDictInfo.tags)
    if (commonTags.length > 0) {
      setCurrentTag(commonTags[0])
    }
  }, [currentDictInfo.tags, tagList])

  return (
    <div>
      <DictTagSwitcher tagList={tagList} currentTag={currentTag} onChangeCurrentTag={onChangeCurrentTag} />
      {/* 原来写死 md:2 / dic3:3 / dic4:4 列：英语分类下只有 CET-4、CET-6 两本，
          4 列时右边空两格，整个词库页看着像「内容只占了左上角」。
          改成 auto-fit + 卡宽上限 + 整体居中：有几本就用几本，
          两本时两张并排居中，九本时自动折行铺满。 */}
      <div className="mt-7 grid justify-center gap-x-5 gap-y-7 px-1 pb-4 [grid-template-columns:repeat(auto-fit,minmax(16rem,21rem))]">
        {currentTag && groupedDictsByTag[currentTag] ? (
          groupedDictsByTag[currentTag].map((dict) => <DictionaryComponent key={dict.id} dictionary={dict} />)
        ) : (
          <div className="c-muted col-span-full text-center">当前分类下没有可用的词典</div>
        )}
      </div>
    </div>
  )
}
