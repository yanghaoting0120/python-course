import { Row, Section, StateChip, Toggle } from './parts'
import {
  isIgnoreCaseAtom,
  isLooseTypingAtom,
  isShowAnswerOnHoverAtom,
  isShowPrevAndNextWordAtom,
  isTextSelectableAtom,
  randomConfigAtom,
} from '@/store'
import { useAtom } from 'jotai'

/** 高级设置 —— 打字行为相关的开关。排版已改走全站统一的 Section/Row/Toggle。 */
export default function AdvancedSetting() {
  const [randomConfig, setRandomConfig] = useAtom(randomConfigAtom)
  const [isShowPrevAndNextWord, setIsShowPrevAndNextWord] = useAtom(isShowPrevAndNextWordAtom)
  const [isIgnoreCase, setIsIgnoreCase] = useAtom(isIgnoreCaseAtom)
  const [isLooseTyping, setIsLooseTyping] = useAtom(isLooseTypingAtom)
  const [isTextSelectable, setIsTextSelectable] = useAtom(isTextSelectableAtom)
  const [isShowAnswerOnHover, setIsShowAnswerOnHover] = useAtom(isShowAnswerOnHoverAtom)

  return (
    <>
      <Section
        title="宽松打字模式"
        hint="开启（推荐）：打错时该字母标红，光标停在原地等你重打这个字母，已经打对的字母全部保留。关闭：打错立刻清空整词，从头重打。"
      >
        <Row label="宽松模式" hint={isLooseTyping ? '打错停在原字母' : '打错整词重来'}>
          <StateChip on={isLooseTyping} />
          <Toggle checked={isLooseTyping} onChange={setIsLooseTyping} label="宽松打字模式" />
        </Row>
      </Section>

      <Section title="练习顺序与显示">
        <Row label="章节乱序" hint="下一章节生效">
          <StateChip on={randomConfig.isOpen} />
          <Toggle checked={randomConfig.isOpen} onChange={(v) => setRandomConfig((p) => ({ ...p, isOpen: v }))} label="章节乱序" />
        </Row>
        <Row label="展示上一个 / 下一个词" hint="练习时在词卡上方显示前后词预览">
          <StateChip on={isShowPrevAndNextWord} />
          <Toggle checked={isShowPrevAndNextWord} onChange={setIsShowPrevAndNextWord} label="展示前后词" />
        </Row>
      </Section>

      <Section title="输入与选择">
        <Row label="忽略大小写" hint="输入 hello 和 Hello 都算对">
          <StateChip on={isIgnoreCase} />
          <Toggle checked={isIgnoreCase} onChange={setIsIgnoreCase} label="忽略大小写" />
        </Row>
        <Row label="允许鼠标选中文本" hint="背单词时方便把词复制出去查">
          <StateChip on={isTextSelectable} />
          <Toggle checked={isTextSelectable} onChange={setIsTextSelectable} label="允许选择文本" />
        </Row>
        <Row label="默写模式下 hover 显示答案" hint="鼠标停在单词上显示正确答案">
          <StateChip on={isShowAnswerOnHover} />
          <Toggle checked={isShowAnswerOnHover} onChange={setIsShowAnswerOnHover} label="hover 显示答案" />
        </Row>
      </Section>
    </>
  )
}
