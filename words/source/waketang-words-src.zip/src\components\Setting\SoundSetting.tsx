import { Row, Section, SliderRow, StateChip, Toggle } from './parts'
import { keySoundResources } from '@/resources/soundResource'
import { hintSoundsConfigAtom, keySoundsConfigAtom, pronunciationConfigAtom } from '@/store'
import type { SoundResource } from '@/typings'
import { toFixedNumber } from '@/utils'
import { playKeySoundResource } from '@/utils/sounds/keySounds'
import { Listbox, Transition } from '@headlessui/react'
import { useAtom } from 'jotai'
import { Fragment } from 'react'
import IconCheck from '~icons/tabler/check'
import IconChevronDown from '~icons/tabler/chevron-down'
import IconEar from '~icons/tabler/ear'

/** 音效设置。2026-10-06：开关/滑杆/下拉全部换成全站统一控件。 */
export default function SoundSetting() {
  const [pronunciationConfig, setPronunciationConfig] = useAtom(pronunciationConfigAtom)
  const [keySoundsConfig, setKeySoundsConfig] = useAtom(keySoundsConfigAtom)
  const [hintSoundsConfig, setHintSoundsConfig] = useAtom(hintSoundsConfigAtom)

  const onPlayKeySound = (r: SoundResource) => playKeySoundResource(r)

  return (
    <>
      <Section title="单词发音" hint="默认走有道在线发音（美音），需要联网。">
        <Row label="开启发音" hint={pronunciationConfig.isOpen ? '点击喇叭会读单词' : '已静音'}>
          <StateChip on={pronunciationConfig.isOpen} />
          <Toggle
            checked={pronunciationConfig.isOpen}
            onChange={(v) => setPronunciationConfig((p) => ({ ...p, isOpen: v }))}
            label="单词发音"
          />
        </Row>
        <SliderRow
          label="音量"
          value={Math.round(pronunciationConfig.volume * 100)}
          min={0}
          max={100}
          step={10}
          onChange={(v) => setPronunciationConfig((p) => ({ ...p, volume: v / 100 }))}
          display={`${Math.round(pronunciationConfig.volume * 100)}%`}
          disabled={!pronunciationConfig.isOpen}
        />
        <SliderRow
          label="倍速"
          value={pronunciationConfig.rate ?? 1}
          min={0.5}
          max={4}
          step={0.1}
          onChange={(v) => setPronunciationConfig((p) => ({ ...p, rate: v }))}
          display={`${toFixedNumber(pronunciationConfig.rate, 2)}×`}
          disabled={!pronunciationConfig.isOpen}
        />
      </Section>

      {window.speechSynthesis ? (
        <Section title="释义发音" hint="朗读中文释义（用系统语音，不走网络）。">
          <Row label="朗读释义">
            <StateChip on={pronunciationConfig.isTransRead} />
            <Toggle
              checked={pronunciationConfig.isTransRead}
              onChange={(v) => setPronunciationConfig((p) => ({ ...p, isTransRead: v }))}
              label="释义发音"
            />
          </Row>
          <SliderRow
            label="音量"
            value={Math.round(pronunciationConfig.transVolume * 100)}
            min={0}
            max={100}
            step={10}
            onChange={(v) => setPronunciationConfig((p) => ({ ...p, transVolume: v / 100 }))}
            display={`${Math.round(pronunciationConfig.transVolume * 100)}%`}
          />
        </Section>
      ) : null}

      <Section title="按键音">
        <Row label="开启按键音">
          <StateChip on={keySoundsConfig.isOpen} />
          <Toggle checked={keySoundsConfig.isOpen} onChange={(v) => setKeySoundsConfig((p) => ({ ...p, isOpen: v }))} label="按键音" />
        </Row>
        <SliderRow
          label="音量"
          value={Math.round(keySoundsConfig.volume * 100)}
          min={1}
          max={100}
          step={10}
          onChange={(v) => setKeySoundsConfig((p) => ({ ...p, volume: v / 100 }))}
          display={`${Math.round(keySoundsConfig.volume * 100)}%`}
          disabled={!keySoundsConfig.isOpen}
        />

        <Row label="音效包">
          <Listbox
            value={keySoundsConfig.resource.key}
            onChange={(key: string) => {
              const r = keySoundResources.find((item: SoundResource) => item.key === key) as SoundResource
              if (r) setKeySoundsConfig((p) => ({ ...p, resource: r }))
            }}
          >
            <div className="relative">
              <Listbox.Button className="btn-secondary btn-sm w-44 justify-between">
                <span className="truncate">{keySoundsConfig.resource.name}</span>
                <IconChevronDown className="h-4 w-4 shrink-0" />
              </Listbox.Button>
              <Transition as={Fragment} leave="transition ease-in duration-100" leaveFrom="opacity-100" leaveTo="opacity-0">
                <Listbox.Options className="glass-strong absolute right-0 z-10 mt-1 max-h-64 w-56 overflow-y-auto rounded-xl p-1.5 shadow-xl">
                  {keySoundResources.map((r) => (
                    <Listbox.Option key={r.key} value={r.key}>
                      {({ selected }) => (
                        <div className="group flex cursor-pointer items-center justify-between rounded-lg px-2.5 py-1.5 hover:bg-black/[0.05] dark:hover:bg-white/[0.07]">
                          <span className="c-ink-soft t-sm">{r.name}</span>
                          <span className="flex items-center gap-1.5">
                            {selected ? <IconCheck className="h-4 w-4 text-[color:var(--c-brand-text)]" /> : null}
                            <IconEar
                              onClick={(e) => {
                                e.stopPropagation()
                                onPlayKeySound(r)
                              }}
                              className="c-faint hidden h-4 w-4 cursor-pointer hover:text-[color:var(--c-brand-text)] group-hover:block"
                            />
                          </span>
                        </div>
                      )}
                    </Listbox.Option>
                  ))}
                </Listbox.Options>
              </Transition>
            </div>
          </Listbox>
        </Row>
      </Section>

      <Section title="效果音" hint="答对、打错时的提示音。">
        <Row label="开启效果音">
          <StateChip on={hintSoundsConfig.isOpen} />
          <Toggle
            checked={hintSoundsConfig.isOpen}
            onChange={(v) => setHintSoundsConfig((p) => ({ ...p, isOpen: v }))}
            label="效果音"
          />
        </Row>
        <SliderRow
          label="音量"
          value={Math.round(hintSoundsConfig.volume * 100)}
          min={1}
          max={100}
          step={10}
          onChange={(v) => setHintSoundsConfig((p) => ({ ...p, volume: v / 100 }))}
          display={`${Math.round(hintSoundsConfig.volume * 100)}%`}
          disabled={!hintSoundsConfig.isOpen}
        />
      </Section>
    </>
  )
}
