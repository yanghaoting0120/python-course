import type { WordUpdateAction } from '../InputHandler'
import InputHandler from '../InputHandler'
import Letter from './Letter'
import Notation from './Notation'
import { TipAlert } from './TipAlert'
import style from './index.module.css'
import { initialWordState } from './type'
import type { WordState } from './type'
import Tooltip from '@/components/Tooltip'
import type { WordPronunciationIconRef } from '@/components/WordPronunciationIcon'
import { WordPronunciationIcon } from '@/components/WordPronunciationIcon'
import { EXPLICIT_SPACE } from '@/constants'
import useKeySounds from '@/hooks/useKeySounds'
import { TypingContext, TypingStateActionType } from '@/pages/Typing/store'
import {
  currentChapterAtom,
  currentDictIdAtom,
  currentDictInfoAtom,
  isIgnoreCaseAtom,
  isLooseTypingAtom,
  isShowAnswerOnHoverAtom,
  isTextSelectableAtom,
  pronunciationIsOpenAtom,
  wordDictationConfigAtom,
} from '@/store'
import type { Word } from '@/typings'
import { CTRL, getUtcStringForMixpanel } from '@/utils'
import { recordWordAnswer, useSaveWordRecord } from '@/utils/db'
import { useAtomValue } from 'jotai'
import { useCallback, useContext, useEffect, useRef, useState } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import { useImmer } from 'use-immer'

const vowelLetters = ['A', 'E', 'I', 'O', 'U']

export default function WordComponent({ word, onFinish }: { word: Word; onFinish: () => void }) {
  // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
  const { state, dispatch } = useContext(TypingContext)!
  const [wordState, setWordState] = useImmer<WordState>(structuredClone(initialWordState))

  const wordDictationConfig = useAtomValue(wordDictationConfigAtom)
  const isTextSelectable = useAtomValue(isTextSelectableAtom)
  const isIgnoreCase = useAtomValue(isIgnoreCaseAtom)
  const isLooseTyping = useAtomValue(isLooseTypingAtom)
  const isShowAnswerOnHover = useAtomValue(isShowAnswerOnHoverAtom)
  const saveWordRecord = useSaveWordRecord()
  // const wordLogUploader = useMixPanelWordLogUploader(state)
  const [playKeySound, playBeepSound, playHintSound] = useKeySounds()
  const pronunciationIsOpen = useAtomValue(pronunciationIsOpenAtom)
  const [isHoveringWord, setIsHoveringWord] = useState(false)
  const currentLanguage = useAtomValue(currentDictInfoAtom).language
  const currentLanguageCategory = useAtomValue(currentDictInfoAtom).languageCategory
  const currentChapter = useAtomValue(currentChapterAtom)
  const currentDictId = useAtomValue(currentDictIdAtom)

  const [showTipAlert, setShowTipAlert] = useState(false)
  const wordPronunciationIconRef = useRef<WordPronunciationIconRef>(null)

  useEffect(() => {
    // run only when word changes
    let headword = ''
    try {
      headword = word.name.replace(new RegExp(' ', 'g'), EXPLICIT_SPACE)
      headword = headword.replace(new RegExp('…', 'g'), '..')
    } catch (e) {
      console.error('word.name is not a string', word)
      headword = ''
    }

    const newWordState = structuredClone(initialWordState)
    newWordState.displayWord = headword
    newWordState.letterStates = new Array(headword.length).fill('normal')
    newWordState.startTime = getUtcStringForMixpanel()
    newWordState.randomLetterVisible = headword.split('').map(() => Math.random() > 0.4)
    setWordState(newWordState)
  }, [word, setWordState])

  const updateInput = useCallback(
    (updateAction: WordUpdateAction) => {
      switch (updateAction.type) {
        case 'add': {
          const char = updateAction.value === ' ' ? EXPLICIT_SPACE : updateAction.value
          if (updateAction.value === ' ') {
            updateAction.event.preventDefault()
          }

          // 严格模式（qwerty-learner 原生）：先把字符收进 inputWord，交给下面的 effect 判定
          if (!isLooseTyping) {
            if (wordState.hasWrong) return
            setWordState((state) => {
              state.inputWord = state.inputWord + char
            })
            return
          }

          // 宽松模式：就地判定。
          // 打错时不前进——光标停在打错的那个字母上等你重打，已经打对的字母全部保留。
          const pos = wordState.inputWord.length
          const expected = wordState.displayWord[pos]
          if (expected == undefined) return

          const isEqual = isIgnoreCase ? char.toLowerCase() === expected.toLowerCase() : char === expected
          const isLastLetter = pos >= wordState.displayWord.length - 1

          if (isEqual) {
            setWordState((state) => {
              state.inputWord = state.inputWord + char
              state.letterStates[pos] = 'correct'
              state.letterTimeArray.push(Date.now())
              state.correctCount += 1

              if (isLastLetter) {
                state.isFinished = true
                state.endTime = getUtcStringForMixpanel()
              }
            })

            if (isLastLetter) {
              playHintSound()
            } else {
              playKeySound()
            }

            dispatch({ type: TypingStateActionType.REPORT_CORRECT_WORD })
          } else {
            playBeepSound()
            const nextLetterMistake = {
              ...wordState.letterMistake,
              [pos]: [...(wordState.letterMistake[pos] ?? []), char],
            }

            setWordState((state) => {
              state.letterStates[pos] = 'wrong'
              state.hasMadeInputWrong = true
              state.wrongCount += 1
              state.letterTimeArray = []
              state.letterMistake = nextLetterMistake
            })

            dispatch({ type: TypingStateActionType.REPORT_WRONG_WORD, payload: { letterMistake: nextLetterMistake } })

            if (currentChapter === 0 && state.chapterData.index === 0 && wordState.wrongCount >= 3) {
              setShowTipAlert(true)
            }
          }
          break
        }

        default:
          console.warn('unknown update type', updateAction)
      }
    },
    [
      wordState.hasWrong,
      wordState.inputWord,
      wordState.displayWord,
      wordState.letterMistake,
      wordState.wrongCount,
      isLooseTyping,
      isIgnoreCase,
      setWordState,
      dispatch,
      playKeySound,
      playBeepSound,
      playHintSound,
      currentChapter,
      state.chapterData.index,
    ],
  )

  const handleHoverWord = useCallback((checked: boolean) => {
    setIsHoveringWord(checked)
  }, [])

  useHotkeys(
    'tab',
    () => {
      handleHoverWord(true)
    },
    { enableOnFormTags: true, preventDefault: true },
    [],
  )

  useHotkeys(
    'tab',
    () => {
      handleHoverWord(false)
    },
    { enableOnFormTags: true, keyup: true, preventDefault: true },
    [],
  )
  useHotkeys(
    'ctrl+j',
    () => {
      if (state.isTyping) {
        wordPronunciationIconRef.current?.play()
      }
    },
    [state.isTyping],
    { enableOnFormTags: true, preventDefault: true },
  )

  useEffect(() => {
    if (wordState.inputWord.length === 0 && state.isTyping) {
      wordPronunciationIconRef.current?.play && wordPronunciationIconRef.current?.play()
    }
  }, [state.isTyping, wordState.inputWord.length, wordPronunciationIconRef.current?.play])

  const getLetterVisible = useCallback(
    (index: number) => {
      if (wordState.letterStates[index] === 'correct' || (isShowAnswerOnHover && isHoveringWord)) return true

      if (wordDictationConfig.isOpen) {
        if (wordDictationConfig.type === 'hideAll') return false

        const letter = wordState.displayWord[index]
        if (wordDictationConfig.type === 'hideVowel') {
          return vowelLetters.includes(letter.toUpperCase()) ? false : true
        }
        if (wordDictationConfig.type === 'hideConsonant') {
          return vowelLetters.includes(letter.toUpperCase()) ? true : false
        }
        if (wordDictationConfig.type === 'randomHide') {
          return wordState.randomLetterVisible[index]
        }
      }
      return true
    },
    [
      isHoveringWord,
      isShowAnswerOnHover,
      wordDictationConfig.isOpen,
      wordDictationConfig.type,
      wordState.displayWord,
      wordState.letterStates,
      wordState.randomLetterVisible,
    ],
  )

  useEffect(() => {
    // 宽松模式已在 updateInput 里就地判定（打错停在原字母上重打），不走这里。
    // 下面保留 qwerty-learner 原生的严格模式逻辑：打错即冻结，300ms 后整词重置。
    if (isLooseTyping) {
      return
    }

    const inputLength = wordState.inputWord.length
    if (wordState.hasWrong || inputLength === 0 || wordState.displayWord.length === 0) {
      return
    }

    const inputChar = wordState.inputWord[inputLength - 1]
    const correctChar = wordState.displayWord[inputLength - 1]
    let isEqual = false
    if (inputChar != undefined && correctChar != undefined) {
      isEqual = isIgnoreCase ? inputChar.toLowerCase() === correctChar.toLowerCase() : inputChar === correctChar
    }

    // 是否已经打到这个词的最后一个字母
    const isLastLetter = inputLength >= wordState.displayWord.length

    if (isEqual) {
      // 输入正确时
      setWordState((state) => {
        state.letterTimeArray.push(Date.now())
        state.correctCount += 1
        state.letterStates[inputLength - 1] = 'correct'

        if (isLastLetter) {
          // 完成输入时
          state.isFinished = true
          state.endTime = getUtcStringForMixpanel()
        }
      })

      if (isLastLetter) {
        playHintSound()
      } else {
        playKeySound()
      }

      dispatch({ type: TypingStateActionType.REPORT_CORRECT_WORD })
    } else {
      // 出错时
      playBeepSound()
      const nextLetterMistake = {
        ...wordState.letterMistake,
        [inputLength - 1]: [...(wordState.letterMistake[inputLength - 1] ?? []), inputChar as string],
      }

      setWordState((state) => {
        state.letterStates[inputLength - 1] = 'wrong'
        state.hasMadeInputWrong = true
        state.wrongCount += 1
        state.letterTimeArray = []
        state.letterMistake = nextLetterMistake
        // 严格模式：冻结输入，交给下面那个 effect 在 300ms 后重置整词
        state.hasWrong = true
      })

      dispatch({ type: TypingStateActionType.REPORT_WRONG_WORD, payload: { letterMistake: nextLetterMistake } })

      if (currentChapter === 0 && state.chapterData.index === 0 && wordState.wrongCount >= 3) {
        setShowTipAlert(true)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wordState.inputWord, isLooseTyping])

  useEffect(() => {
    // 严格模式：出错后 300ms 清空整词，从头重打
    // 宽松模式：不重置，保留标红结果继续往下打
    if (wordState.hasWrong && !isLooseTyping) {
      const timer = setTimeout(() => {
        setWordState((state) => {
          state.inputWord = ''
          state.letterStates = new Array(state.letterStates.length).fill('normal')
          state.hasWrong = false
        })
      }, 300)

      return () => {
        clearTimeout(timer)
      }
    }
  }, [wordState.hasWrong, isLooseTyping, setWordState])

  useEffect(() => {
    if (wordState.isFinished) {
      dispatch({ type: TypingStateActionType.SET_IS_SAVING_RECORD, payload: true })

      // wordLogUploader({
      //   headword: word.name,
      //   timeStart: wordState.startTime,
      //   timeEnd: wordState.endTime,
      //   countInput: wordState.correctCount + wordState.wrongCount,
      //   countCorrect: wordState.correctCount,
      //   countTypo: wordState.wrongCount,
      // })
      saveWordRecord({
        word: word.name,
        wrongCount: wordState.wrongCount,
        letterTimeArray: wordState.letterTimeArray,
        letterMistake: wordState.letterMistake,
      })

      // 艾宾浩斯：推进这个词的记忆阶段（打错任何一个字母即算答错）
      // source: 'typing' 会写 typedDate —— 「先认后拼」门禁靠它判断「今天认了但还没拼」
      void recordWordAnswer(currentDictId, word.name, wordState.wrongCount === 0, { source: 'typing' })

      onFinish()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wordState.isFinished])

  useEffect(() => {
    if (wordState.wrongCount >= 4) {
      dispatch({ type: TypingStateActionType.SET_IS_SKIP, payload: true })
    }
  }, [wordState.wrongCount, dispatch])

  /**
   * 当前该打的字母索引，-1 表示不高亮。
   *
   * 四个必须守住的边界：
   *   宽松模式打错 → 该位置是 'wrong'，不满足 === 'normal' → 保持红色，不会变成绿色下划线
   *   整词打完     → letterStates[len] 是 undefined → -1，不再高亮
   *   暂停 / 未开始 → state.isTyping 为 false → -1，避免和「按任意键开始」打架
   *   严格模式冻结 → hasWrong 为 true → -1
   */
  const activeIndex =
    state.isTyping && !wordState.hasWrong && !wordState.isFinished && wordState.letterStates[wordState.inputWord.length] === 'normal'
      ? wordState.inputWord.length
      : -1

  return (
    <>
      <InputHandler updateInput={updateInput} />
      <div
        lang={currentLanguageCategory !== 'code' ? currentLanguageCategory : 'en'}
        className="flex flex-col items-center justify-center pb-1 pt-4"
      >
        {['romaji', 'hapin'].includes(currentLanguage) && word.notation && <Notation notation={word.notation} />}
        <div
          className={`tooltip-info relative w-fit bg-transparent p-0 leading-normal shadow-none dark:bg-transparent ${
            wordDictationConfig.isOpen ? 'tooltip' : ''
          }`}
          data-tip="按 Tab 快捷键显示完整单词"
        >
          <div
            onMouseEnter={() => handleHoverWord(true)}
            onMouseLeave={() => handleHoverWord(false)}
            className={`flex items-center ${isTextSelectable && 'select-all'} justify-center ${wordState.hasWrong ? style.wrong : ''}`}
          >
            {wordState.displayWord.split('').map((t, index) => {
              return (
                <Letter
                  key={`${index}-${t}`}
                  letter={t}
                  visible={getLetterVisible(index)}
                  state={index === activeIndex ? 'active' : wordState.letterStates[index]}
                />
              )
            })}
          </div>
          {pronunciationIsOpen && (
            <div className="absolute -right-12 top-1/2 h-9 w-9 -translate-y-1/2 transform ">
              <Tooltip content={`快捷键${CTRL} + J`}>
                <WordPronunciationIcon word={word} lang={currentLanguage} ref={wordPronunciationIconRef} className="h-full w-full" />
              </Tooltip>
            </div>
          )}
        </div>
      </div>
      <TipAlert className="fixed bottom-10 right-3" show={showTipAlert} setShow={setShowTipAlert} />
    </>
  )
}
