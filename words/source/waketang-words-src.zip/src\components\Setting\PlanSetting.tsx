import { Row, Section, SliderRow } from './parts'
import { dailyNewAtom, dailyReviewMaxAtom, reviewOnlyAtom } from '@/store'
import { useAtom } from 'jotai'
import IconCheck from '~icons/tabler/check'

/**
 * 学习计划 —— 2026-10-06 新增。
 *
 * 这两个值（每日新词量 / 每日复习上限）以前**代码里根本没有地方能改**：
 * 今日页读 `dailyNewAtom` / `dailyReviewMaxAtom`，但没有任何界面写它们，
 * 想从 20 调到 10 只能改源码重新打包。现在补上。
 */

const NEW_PRESETS = [5, 10, 15, 20, 30, 50]

export default function PlanSetting() {
  const [dailyNew, setDailyNew] = useAtom(dailyNewAtom)
  const [dailyReviewMax, setDailyReviewMax] = useAtom(dailyReviewMaxAtom)
  const [reviewOnly, setReviewOnly] = useAtom(reviewOnlyAtom)

  return (
    <>
      <Section
        title="每日新词量"
        hint="每天排多少个新词进「选词记忆」。改完回到今日页立刻生效，不用重启。"
      >
        <SliderRow
          label="新词数量"
          value={dailyNew}
          min={5}
          max={50}
          step={5}
          onChange={setDailyNew}
          display={`${dailyNew} 个`}
        />
        {/* 常用档位做成一排快捷按钮，比拖滑杆准 */}
        <div className="flex flex-wrap gap-2 pl-0">
          {NEW_PRESETS.map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setDailyNew(n)}
              className={`rounded-full px-3 py-1 text-xs font-semibold transition-colors ${
                dailyNew === n
                  ? 'bg-[color:var(--c-brand-solid)] text-white'
                  : 'c-muted border border-[color:var(--c-line)] hover:bg-black/[0.04] dark:hover:bg-white/[0.06]'
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </Section>

      <Section title="每日复习上限" hint="到期复习词太多时，一天最多复习多少个，防止复习量滚雪球压垮人。">
        <SliderRow
          label="复习上限"
          value={dailyReviewMax}
          min={50}
          max={500}
          step={50}
          onChange={setDailyReviewMax}
          display={`${dailyReviewMax} 个`}
        />
      </Section>

      <Section title="今天只复习" hint="打开后今天不再安排新词，只清到期的复习词。今日页上也有同一个开关。">
        <Row
          label="只复习，不学新词"
          hint={reviewOnly ? '今天不排新词' : '正常排新词'}
        >
          <button
            type="button"
            role="checkbox"
            aria-checked={reviewOnly}
            onClick={() => setReviewOnly(!reviewOnly)}
            className="flex cursor-pointer select-none items-center gap-2"
          >
            <span className="checkbox" data-checked={reviewOnly}>
              {reviewOnly ? <IconCheck className="h-3 w-3" /> : null}
            </span>
            <span className="c-muted t-micro">{reviewOnly ? '已开启' : '已关闭'}</span>
          </button>
        </Row>
      </Section>

      <Section title="学习顺序（固定规则）" hint="这一条不可调，说明一下它是怎么走的。">
        <div className="c-muted t-sm glass rounded-xl px-4 py-3 leading-relaxed">
          新词必须先在<b className="c-ink-soft">选词记忆</b>里<b className="c-ink-soft">答对</b>，才会进入
          <b className="c-ink-soft">拼写练习</b>；选错的词不算通过，下次还会重新排进选词记忆。
          <br />
          复习词以前认过，直接就可以拼写，不用重认。
        </div>
      </Section>
    </>
  )
}
