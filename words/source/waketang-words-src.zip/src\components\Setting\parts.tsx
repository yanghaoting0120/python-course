import * as Slider from '@radix-ui/react-slider'
import { Switch } from '@headlessui/react'

/**
 * 设置页共用的几个小组件。
 *
 * 原来四个面板各自引 `index.module.css`，用的是 `text-gray-600` / `gap-10` / `pb-40`
 * 那套老样式，和全站的设计系统对不上。抽成这几个之后：
 *   · 字号、颜色、间距全部走 token
 *   · 开关统一用 `.switch`（全站一套），不再用原来的 `.switch-root`
 *   · 五个面板的排版天然一致
 */

export function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section className="mb-6 last:mb-2">
      <h3 className="c-ink t-sm font-bold">{title}</h3>
      {hint ? <p className="c-muted t-micro mt-1 leading-relaxed">{hint}</p> : null}
      <div className="mt-3 space-y-3">{children}</div>
    </section>
  )
}

/** 一行：左边标签（可带小字说明），右边控件 */
export function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex min-w-0 flex-col">
        <span className="c-ink-soft t-sm font-semibold">{label}</span>
        {hint ? <span className="c-faint t-micro leading-snug">{hint}</span> : null}
      </div>
      <div className="flex shrink-0 items-center gap-2.5">{children}</div>
    </div>
  )
}

/** 全站统一的胶囊开关 */
export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label?: string
}) {
  return (
    <Switch checked={checked} onChange={onChange} className="switch" aria-label={label}>
      <span aria-hidden="true" className="switch-thumb-dot" />
    </Switch>
  )
}

/** 开/关状态小胶囊，让"现在是开还是关"一眼可见 */
export function StateChip({ on, onText = '开', offText = '关' }: { on: boolean; onText?: string; offText?: string }) {
  return <span className={`badge ${on ? 'badge-brand' : 'badge-neutral'}`}>{on ? onText : offText}</span>
}

/** 一行滑杆：左边标签，右边滑杆 + 数值 */
export function SliderRow({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
  disabled,
}: {
  label: string
  value: number
  min: number
  max: number
  step: number
  onChange: (v: number) => void
  /** 右侧显示的文本 */
  display: string
  disabled?: boolean
}) {
  return (
    <div className="flex items-center gap-4">
      <span className={`t-sm w-20 shrink-0 font-semibold ${disabled ? 'c-faint' : 'c-ink-soft'}`}>{label}</span>
      <Slider.Root
        value={[value]}
        min={min}
        max={max}
        step={step}
        className="slider"
        onValueChange={(v) => onChange(v[0])}
        disabled={disabled}
      >
        <Slider.Track>
          <Slider.Range />
        </Slider.Track>
        <Slider.Thumb />
      </Slider.Root>
      <span className="c-muted t-micro w-14 shrink-0 text-right tabular-nums">{display}</span>
    </div>
  )
}
