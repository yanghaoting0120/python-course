import { TypingContext, TypingStateActionType } from '../../store'
import WordCard from './WordCard'
import Drawer from '@/components/Drawer'
import { currentChapterAtom, currentDictInfoAtom, isReviewModeAtom } from '@/store'
import { Dialog } from '@headlessui/react'
import * as ScrollArea from '@radix-ui/react-scroll-area'
import { atom, useAtom, useAtomValue } from 'jotai'
import { useContext } from 'react'
import IconX from '~icons/tabler/x'

const currentDictTitle = atom((get) => {
  const isReviewMode = get(isReviewModeAtom)

  if (isReviewMode) {
    return `${get(currentDictInfoAtom).name} 错题复习`
  } else {
    return `${get(currentDictInfoAtom).name} 第 ${get(currentChapterAtom) + 1} 章`
  }
})

/** 单词列表抽屉的开关（页头按钮与抽屉本体共用这个状态） */
const isWordListOpenAtom = atom(false)

/**
 * 页头上的「单词列表」入口。
 *
 * 原来这是一个 `fixed left-0` 贴屏幕最左侧悬浮的浅绿把手，Tooltip 还是英文 "List"，
 * 词卡被遮挡时看着像外挂补丁（评审 B2-5）。现在收进页头，与其它按钮同款。
 */
export function WordListTrigger() {
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const { dispatch } = useContext(TypingContext)!
  const [, setOpen] = useAtom(isWordListOpenAtom)

  return (
    <button
      type="button"
      className="btn-secondary btn-sm whitespace-nowrap"
      onClick={() => {
        setOpen(true)
        dispatch({ type: TypingStateActionType.SET_IS_TYPING, payload: false })
      }}
    >
      单词列表
    </button>
  )
}

export default function WordList() {
  // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
  const { state } = useContext(TypingContext)!
  const [isOpen, setIsOpen] = useAtom(isWordListOpenAtom)
  const currentDictTitleValue = useAtomValue(currentDictTitle)

  function closeModal() {
    setIsOpen(false)
  }

  return (
    <Drawer open={isOpen} onClose={closeModal} classNames="bg-stone-50 dark:bg-gray-900">
      <Dialog.Title as="h3" className="flex items-center justify-between p-4 text-lg font-medium leading-6 dark:text-gray-50">
        {currentDictTitleValue}
        <IconX onClick={closeModal} className="cursor-pointer" />
      </Dialog.Title>
      <ScrollArea.Root className="flex-1 select-none overflow-y-auto ">
        <ScrollArea.Viewport className="h-full w-full px-3">
          <div className="flex h-full w-full flex-col gap-1">
            {state.chapterData.words?.map((word, index) => {
              return <WordCard word={word} key={`${word.name}_${index}`} isActive={state.chapterData.index === index} />
            })}
          </div>
        </ScrollArea.Viewport>
        <ScrollArea.Scrollbar className="flex touch-none select-none bg-transparent " orientation="vertical"></ScrollArea.Scrollbar>
      </ScrollArea.Root>
    </Drawer>
  )
}
