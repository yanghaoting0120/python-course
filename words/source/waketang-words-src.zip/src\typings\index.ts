export * from './resource'

export type PronunciationType = 'us' | 'uk' | 'romaji' | 'zh' | 'ja' | 'de' | 'hapin' | 'kk' | 'id'
export type PhoneticType = 'us' | 'uk' | 'romaji' | 'zh' | 'ja' | 'de' | 'hapin' | 'kk' | 'id'
export type LanguageType = 'en' | 'romaji' | 'zh' | 'ja' | 'code' | 'de' | 'kk' | 'hapin' | 'id'
export type LanguageCategoryType = 'en' | 'ja' | 'de' | 'code' | 'kk' | 'id'

type Pronunciation2PhoneticMap = Record<PronunciationType, PhoneticType>

export const PRONUNCIATION_PHONETIC_MAP: Pronunciation2PhoneticMap = {
  us: 'us',
  uk: 'uk',
  romaji: 'romaji',
  zh: 'zh',
  ja: 'ja',
  de: 'de',
  hapin: 'hapin',
  kk: 'kk',
  id: 'id',
}

/** 一条例句（普通例句 / 词组，均为英文+中文） */
export type WordSentence = {
  en: string
  cn: string
}

/** 真题例句（带年份、试卷、题型） */
export type ExamSentence = {
  en: string
  cn?: string
  level?: string
  year?: string
  paper?: string
  type?: string
}

/** 同根词分组 */
export type RelWordGroup = {
  pos: string
  words: { w: string; cn: string }[]
}

/** 近义词分组 */
export type SynoGroup = {
  pos: string
  cn: string
  words: string[]
}

/** 真题选择题 */
export type QuizItem = {
  question: string
  choices: string[]
  /** 正确选项下标（0 起） */
  answerIndex: number
  explain: string
}

export type Word = {
  name: string
  trans: string[]
  usphone: string
  ukphone: string
  notation?: string

  // —— 蛙课堂背单词新增：以下字段可选，来自四六级富数据 ——
  /** 普通例句 */
  sentences?: WordSentence[]
  /** 常用词组 */
  phrases?: WordSentence[]
  /** 真题例句 */
  examSentences?: ExamSentence[]
  /** 词源 / 助记法文本（词根词缀拆解） */
  etymology?: string
  /** 同根词 */
  relWords?: RelWordGroup[]
  /** 近义词 */
  synos?: SynoGroup[]
  /** 真题选择题（用于「学完即测」） */
  exam?: QuizItem[]
}

export type WordWithIndex = Word & {
  // 在 chapter 中的原始索引
  index: number
}

export type InfoPanelType = 'donate' | 'vsc' | 'community' | 'redBook'

export type InfoPanelState = {
  [key in InfoPanelType]: boolean
}

export type LoopWordTimesOption = 1 | 3 | 5 | 8 | typeof Number.MAX_SAFE_INTEGER

export type WordDictationType = 'hideAll' | 'hideVowel' | 'hideConsonant' | 'randomHide'
/**
 * 标记用户是手动打开默写模式，还是通过点击 resultScreen 中的默写本章按钮打开的
 *
 * 预期行为是，在进入下一章节时，如果是手动打开的默写模式，则保持设定
 * 如果是通过点击 resultScreen 中的默写本章按钮打开的，则关闭默写模式
 */
export type WordDictationOpenBy = 'user' | 'auto'
