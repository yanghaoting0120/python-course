import atomForConfig from './atomForConfig'
import { reviewInfoAtom } from './reviewInfoAtom'
import { DISMISS_START_CARD_DATE_KEY, defaultFontSizeConfig } from '@/constants'
import { idDictionaryMap } from '@/resources/dictionary'
import { correctSoundResources, keySoundResources, wrongSoundResources } from '@/resources/soundResource'
import type {
  Dictionary,
  InfoPanelState,
  LoopWordTimesOption,
  PhoneticType,
  PronunciationType,
  Word,
  WordDictationOpenBy,
  WordDictationType,
} from '@/typings'
import type { ReviewRecord } from '@/utils/db/record'
import { atom } from 'jotai'
import { atomWithStorage } from 'jotai/utils'

export const currentDictIdAtom = atomWithStorage('currentDict', 'cet4')
export const currentDictInfoAtom = atom<Dictionary>((get) => {
  const id = get(currentDictIdAtom)
  let dict = idDictionaryMap[id]
  // 如果 dict 不存在，则返回 cet4. Typing 中会检查 DictId 是否存在，如果不存在则会重置为 cet4
  if (!dict) {
    dict = idDictionaryMap.cet4
  }
  return dict
})

export const currentChapterAtom = atomWithStorage('currentChapter', 0)

export const loopWordConfigAtom = atomForConfig<{ times: LoopWordTimesOption }>('loopWordConfig', {
  times: 1,
})

export const keySoundsConfigAtom = atomForConfig('keySoundsConfig', {
  isOpen: true,
  isOpenClickSound: true,
  volume: 1,
  resource: keySoundResources[0],
})

export const hintSoundsConfigAtom = atomForConfig('hintSoundsConfig', {
  isOpen: true,
  volume: 1,
  isOpenWrongSound: true,
  isOpenCorrectSound: true,
  wrongResource: wrongSoundResources[0],
  correctResource: correctSoundResources[0],
})

export const pronunciationConfigAtom = atomForConfig('pronunciation', {
  isOpen: true,
  volume: 1,
  type: 'us' as PronunciationType,
  name: '美音',
  isLoop: false,
  isTransRead: false,
  transVolume: 1,
  rate: 1,
})

export const fontSizeConfigAtom = atomForConfig('fontsize', defaultFontSizeConfig)

export const pronunciationIsOpenAtom = atom((get) => get(pronunciationConfigAtom).isOpen)

export const pronunciationIsTransReadAtom = atom((get) => get(pronunciationConfigAtom).isTransRead)

export const randomConfigAtom = atomForConfig('randomConfig', {
  isOpen: false,
})

export const isShowPrevAndNextWordAtom = atomWithStorage('isShowPrevAndNextWord', true)

export const isIgnoreCaseAtom = atomWithStorage('isIgnoreCase', true)

/**
 * 宽松打字模式
 * - true（默认）：打错时该字母标红，光标停在原地等你重打这个字母；已经打对的字母全部保留，
 *   不会整词清空重来。打错过的词仍会计入错词本。
 * - false：qwerty-learner 原生行为——打错立刻整词清空，300ms 后从头重打
 */
export const isLooseTypingAtom = atomWithStorage('isLooseTyping', true)

// ─────────────────────────────────────────────────────────────
//  蛙课堂背单词：艾宾浩斯学习计划
// ─────────────────────────────────────────────────────────────

/** 每日新词量 */
export const dailyNewAtom = atomWithStorage('dailyNew', 20)

/** 每日复习上限（防止复习量滚雪球压垮人） */
export const dailyReviewMaxAtom = atomWithStorage('dailyReviewMax', 200)

/** 今天只复习、不学新词 */
export const reviewOnlyAtom = atomWithStorage('reviewOnly', false)

/**
 * 今日会话里的一条词。
 *
 * isReview  这次是「复习旧词」还是「学新词」
 * canType   **能不能进拼写练习** —— 「先认后拼」门禁（用户 2026-10-06 拍板）：
 *           新词必须先在选词记忆里**答对**，canType 才会变成 true。
 *           复习词有记录，直接就是 true。
 *
 * ⚠️ canType 是会话快照的一部分。在选词记忆里答对时，页面会就地把它改成 true，
 *    这样结束页的「接着去拼写」才能立刻拼刚认过的这批词。
 */
export type TodaySessionWord = Word & { isReview: boolean; canType: boolean }

/**
 * 今日学习会话。
 * 由「今日」首页按艾宾浩斯计划生成（复习词在前、新词在后），
 * 打字页消费它来作为本次要打的词表；打完后清空。
 */
export const todaySessionAtom = atom<{ words: TodaySessionWord[] } | null>(null)

export const isShowAnswerOnHoverAtom = atomWithStorage('isShowAnswerOnHover', true)

// 默认打开：背单词时经常要把单词/释义复制出去查词。
// body 上有 user-select:none 防止边打字边误选，这个开关控制单词区域是否可选。
export const isTextSelectableAtom = atomWithStorage('isTextSelectable', true)

export const reviewModeInfoAtom = reviewInfoAtom({
  isReviewMode: false,
  reviewRecord: undefined as ReviewRecord | undefined,
})
export const isReviewModeAtom = atom((get) => get(reviewModeInfoAtom).isReviewMode)

export const phoneticConfigAtom = atomForConfig('phoneticConfig', {
  isOpen: true,
  type: 'us' as PhoneticType,
})

export const isOpenDarkModeAtom = atomWithStorage('isOpenDarkModeAtom', window.matchMedia('(prefers-color-scheme: dark)').matches)

export const isShowSkipAtom = atom(false)

export const isInDevModeAtom = atom(false)

export const infoPanelStateAtom = atom<InfoPanelState>({
  donate: false,
  vsc: false,
  community: false,
  redBook: false,
})

export const wordDictationConfigAtom = atomForConfig('wordDictationConfig', {
  isOpen: false,
  type: 'hideAll' as WordDictationType,
  openBy: 'auto' as WordDictationOpenBy,
})

export const dismissStartCardDateAtom = atomWithStorage<Date | null>(DISMISS_START_CARD_DATE_KEY, null)

// Enhanced version promotion popup state
export const hasSeenEnhancedPromotionAtom = atomWithStorage('hasSeenEnhancedPromotion', false)

// for dev test
//   dismissStartCardDateAtom = atom<Date | null>(new Date())
