import { getUTCUnixTimestamp } from '../index'
import type { Word } from '@/typings'

export interface IWordRecord {
  word: string
  timeStamp: number
  // 正常章节为 dictKey, 其他功能则为对应的类型
  dict: string
  // 用户可能是在 错题/其他类似组件中 进行的练习则为 null, start from 0
  chapter: number | null
  // 正确次数中输入每个字母的时间差，可以据此计算出总时间
  timing: number[]
  // 出错的次数
  wrongCount: number
  // 每个字母被错误输入成什么, index 为字母的索引, 数组内为错误的 e.key
  mistakes: LetterMistakes
}

export interface LetterMistakes {
  // 每个字母被错误输入成什么, index 为字母的索引, 数组内为错误的 e.key
  [index: number]: string[]
}

export class WordRecord implements IWordRecord {
  word: string
  timeStamp: number
  dict: string
  chapter: number | null
  timing: number[]
  wrongCount: number
  mistakes: LetterMistakes

  constructor(word: string, dict: string, chapter: number | null, timing: number[], wrongCount: number, mistakes: LetterMistakes) {
    this.word = word
    this.timeStamp = getUTCUnixTimestamp()
    this.dict = dict
    this.chapter = chapter
    this.timing = timing
    this.wrongCount = wrongCount
    this.mistakes = mistakes
  }

  get totalTime() {
    return this.timing.reduce((acc, curr) => acc + curr, 0)
  }
}

export interface IChapterRecord {
  // 正常章节为 dictKey, 其他功能则为对应的类型
  dict: string
  // 在错题场景中为 -1
  chapter: number | null
  timeStamp: number
  // 单位为 s，章节的记录没必要到毫秒级
  time: number
  // 正确按键次数，输对一个字母即记录
  correctCount: number
  // 错误的按键次数。 出错会清空整个输入，但只记录一次错误
  wrongCount: number
  // 用户输入的单词总数，可能会使用循环等功能使输入总数大于 20
  wordCount: number
  // 一次打对未犯错的单词列表, 可以和 wordNumber 对比得出出错的单词 indexes
  correctWordIndexes: number[]
  // 章节总单词数
  wordNumber: number
  // 单词 record 的 id 列表
  wordRecordIds: number[]
}

export class ChapterRecord implements IChapterRecord {
  dict: string
  chapter: number | null
  timeStamp: number
  time: number
  correctCount: number
  wrongCount: number
  wordCount: number
  correctWordIndexes: number[]
  wordNumber: number
  wordRecordIds: number[]

  constructor(
    dict: string,
    chapter: number | null,
    time: number,
    correctCount: number,
    wrongCount: number,
    wordCount: number,
    correctWordIndexes: number[],
    wordNumber: number,
    wordRecordIds: number[],
  ) {
    this.dict = dict
    this.chapter = chapter
    this.timeStamp = getUTCUnixTimestamp()
    this.time = time
    this.correctCount = correctCount
    this.wrongCount = wrongCount
    this.wordCount = wordCount
    this.correctWordIndexes = correctWordIndexes
    this.wordNumber = wordNumber
    this.wordRecordIds = wordRecordIds
  }

  get wpm() {
    return Math.round((this.wordCount / this.time) * 60)
  }

  get inputAccuracy() {
    return Math.round((this.correctCount / this.correctCount + this.wrongCount) * 100)
  }

  get wordAccuracy() {
    return Math.round((this.correctWordIndexes.length / this.wordNumber) * 100)
  }
}

export interface IReviewRecord {
  id?: number
  dict: string
  // 当前练习进度
  index: number
  // 创建时间
  createTime: number
  // 是否已经完成
  isFinished: boolean
  // 单词列表, 根据复习算法生成和修改，可能会有重复值
  words: Word[]
}

export class ReviewRecord implements IReviewRecord {
  id?: number
  dict: string
  index: number
  createTime: number
  isFinished: boolean
  words: Word[]

  constructor(dict: string, words: Word[]) {
    this.dict = dict
    this.index = 0
    this.createTime = getUTCUnixTimestamp()
    this.words = words
    this.isFinished = false
  }
}

export interface IRevisionDictRecord {
  dict: string
  revisionIndex: number
  createdTime: number
}

export class RevisionDictRecord implements IRevisionDictRecord {
  dict: string
  revisionIndex: number
  createdTime: number

  constructor(dict: string, revisionIndex: number, createdTime: number) {
    this.dict = dict
    this.revisionIndex = revisionIndex
    this.createdTime = createdTime
  }
}

export interface IRevisionWordRecord {
  word: string
  timeStamp: number
  dict: string
  errorCount: number
}

export class RevisionWordRecord implements IRevisionWordRecord {
  word: string
  timeStamp: number
  dict: string
  errorCount: number

  constructor(word: string, dict: string, errorCount: number) {
    this.word = word
    this.timeStamp = getUTCUnixTimestamp()
    this.dict = dict
    this.errorCount = errorCount
  }
}

/**
 * 单词 memory 记录 —— 蛙课堂背单词的艾宾浩斯调度状态。
 *
 * 与 WordRecord 的区别：
 *   WordRecord   是「日志」，每打一次字就追加一条，用来做统计和错题分析。
 *   MemoryRecord 是「状态」，每个词在每本词书里只有一条，记录它记到第几阶段、
 *                下次什么时候该复习。调度器只读这张表。
 */
export interface IMemoryRecord {
  id?: number
  /** 词书 id */
  dict: string
  /** 单词原文，作为词书内的唯一键 */
  word: string
  /** 记忆阶段 = 已通过的复习次数；0 表示刚学完；>= 5 表示已掌握 */
  stage: number
  /** 是否已掌握（退出日常队列） */
  mastered: boolean
  /** 下次复习日期 YYYY-MM-DD；已掌握时为空串 */
  dueDate: string
  /** 首次学习日期 YYYY-MM-DD */
  firstLearnDate: string
  /** 最近一次作答日期 YYYY-MM-DD */
  lastReviewDate: string
  /** 累计答对次数 */
  correct: number
  /** 累计答错次数 */
  wrong: number
  /** 是否进过生词本（答错过或手动标记） */
  stubborn: boolean
  /**
   * 通过「选词记忆」的日期 YYYY-MM-DD；'' = 还没通过。
   *
   * 这是「先认后拼」门禁的钥匙：**只有 recalledDate 非空的词才允许进拼写练习**。
   * 规则由用户 2026-10-06 拍板：
   *   · 必须**答对**才算通过（选词记忆里选错的词不算）
   *   · 门禁是一次性的 —— 通过了就永远可拼，复习词不用每天重认
   */
  recalledDate: string
  /** 最近一次**拼写**作答的日期 YYYY-MM-DD；'' = 没拼过。用来判断「今天认了但还没拼」 */
  typedDate: string
}

export class MemoryRecord implements IMemoryRecord {
  id?: number
  dict: string
  word: string
  stage: number
  mastered: boolean
  dueDate: string
  firstLearnDate: string
  lastReviewDate: string
  correct: number
  wrong: number
  stubborn: boolean
  recalledDate: string
  typedDate: string

  constructor(
    dict: string,
    word: string,
    stage: number,
    mastered: boolean,
    dueDate: string,
    firstLearnDate: string,
    lastReviewDate: string,
    correct: number,
    wrong: number,
    stubborn: boolean,
    /** 后加的两个字段给了默认值，老调用点不用改 */
    recalledDate = '',
    typedDate = '',
  ) {
    this.dict = dict
    this.word = word
    this.stage = stage
    this.mastered = mastered
    this.dueDate = dueDate
    this.firstLearnDate = firstLearnDate
    this.lastReviewDate = lastReviewDate
    this.correct = correct
    this.wrong = wrong
    this.stubborn = stubborn
    this.recalledDate = recalledDate
    this.typedDate = typedDate
  }
}
