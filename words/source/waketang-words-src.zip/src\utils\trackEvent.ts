/**
 * 蛙课堂背单词：本地自用工具，不向任何第三方发送统计/埋点数据。
 *
 * 原版通过 Vercel Analytics 与 Google Analytics (gtag) 上报事件。
 * 这里改为空实现，调用点保持不变，方便将来需要对账或改回。
 */

export const trackPromotionEvent = (_event: string, _properties: Record<string, string>) => {
  // 有意留空：不外发
}
