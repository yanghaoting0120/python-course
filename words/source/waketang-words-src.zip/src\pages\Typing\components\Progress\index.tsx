import { TypingContext } from '../../store'
import { useContext, useEffect, useState } from 'react'

export default function Progress({ className }: { className?: string }) {
  // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
  const { state } = useContext(TypingContext)!
  const [progress, setProgress] = useState(0)
  const [phase, setPhase] = useState(0)

  const colorSwitcher: { [key: number]: string } = {
    0: 'bg-brand-200 dark:bg-brand-300',
    1: 'bg-brand-300 dark:bg-brand-400',
    2: 'bg-brand-400 dark:bg-brand-500',
  }

  useEffect(() => {
    const newProgress = Math.floor((state.chapterData.index / state.chapterData.words.length) * 100)
    setProgress(newProgress)
    const colorPhase = Math.floor(newProgress / 33.4)
    setPhase(colorPhase)
  }, [state.chapterData.index, state.chapterData.words.length])

  return (
    // 原来这里是 w-1/4（25%），与页头、卡片、底部统计条宽度都不一致，
    // 1920 下一眼能看出没对齐。现在撑满统一容器。
    <div className={`relative w-full pt-1 ${className}`}>
      <div className="mb-4 flex h-1.5 overflow-hidden rounded-full bg-brand-100 text-xs transition-all duration-300 dark:bg-brand-200">
        <div
          style={{ width: `${progress}%` }}
          className={`flex flex-col justify-center whitespace-nowrap rounded-full text-center text-white shadow-none transition-all duration-300 ${
            colorSwitcher[phase] ?? 'bg-brand-200 dark:bg-brand-300'
          }`}
        ></div>
      </div>
    </div>
  )
}
