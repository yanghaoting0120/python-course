import type { Word } from '@/typings'

/**
 * 词库的「按需加载」。
 *
 * 背景（2026-10-06）：今日页要算「今天该背哪些词、哪些到期了」，必须知道**整本词书**有哪些词；
 * 但一本 CET-4 的完整数据是 4366 KB（带例句、词根词缀、真题…），
 * 而蛙课堂服务器在新加坡、实测链路只有 40–95 KB/s —— 首屏要等 3 分钟。
 *
 * 所以每本词书额外产出两份东西（`tools/split-dicts.mjs` 生成，原文件保持不动）：
 *
 *   dicts/<id>.plan.json     每个词只有 { name, trans }，用来算计划和抽干扰项
 *                            CET-4: 4366 KB → 256 KB（gzip 后约 60 KB）
 *
 *   dicts/<id>/p00.json …    完整词对象，每片 128 个词（CET-4 共 21 片，平均 208 KB）
 *                            今天的会话只有 20–40 个词，命中 1–2 片就够
 *
 * ⚠️ plan 数组的顺序与完整词库**完全一致**（切的时候没排序没过滤），
 *    所以「名字在 plan 里的下标」就能反推它落在第几片。
 */

/** 每片的词数，必须与 tools/split-dicts.mjs 里的 CHUNK_SIZE 一致 */
export const CHUNK_SIZE = 128

/** 由词库主地址推出「计划索引」地址：/dicts/cet4.json → /dicts/cet4.plan.json */
export function planUrl(dictUrl: string): string {
  return dictUrl.replace(/\.json$/, '.plan.json')
}

/** 由词库主地址推出第 n 片地址：/dicts/cet4.json + 3 → /dicts/cet4/p03.json */
export function chunkUrl(dictUrl: string, n: number): string {
  return dictUrl.replace(/\.json$/, `/p${String(n).padStart(2, '0')}.json`)
}

async function getJson<T>(url: string): Promise<T> {
  const r = await fetch(url)
  if (!r.ok) throw new Error(`读取失败 ${r.status}：${url}`)
  return (await r.json()) as T
}

// 计划索引和分片都缓存在内存里：同一本词书来回切页面不用重复下
const planCache = new Map<string, Promise<Word[]>>()
const chunkCache = new Map<string, Promise<Word[]>>()

/**
 * 取某本词书的「计划索引」。
 *
 * 返回的对象只有 name / trans，音标是空串 —— 够算计划和抽干扰项，
 * **不要拿它去渲染词卡**（词卡要用 fetchWords() 取回完整数据）。
 */
export function fetchPlan(dictUrl: string): Promise<Word[]> {
  let p = planCache.get(dictUrl)
  if (!p) {
    p = getJson<Word[]>(planUrl(dictUrl))
    planCache.set(dictUrl, p)
  }
  return p
}

function fetchChunk(dictUrl: string, n: number): Promise<Word[]> {
  const key = `${dictUrl}#${n}`
  let p = chunkCache.get(key)
  if (!p) {
    p = getJson<Word[]>(chunkUrl(dictUrl, n))
    chunkCache.set(key, p)
  }
  return p
}

/**
 * 按名字取回**完整**词对象（含音标、词根词缀、例句…）。
 *
 * 只会下载这些词命中的那几个分片。今天的会话是「按顺序取的新词 + 零星到期的复习词」，
 * 通常命中 1–2 片；就算复习词散得开，也比整本 4366 KB 小得多。
 *
 * @param names 想要的词，顺序会被保留；找不到的词直接丢掉（不报错）
 */
export async function fetchWords(dictUrl: string, names: string[]): Promise<Word[]> {
  if (names.length === 0) return []

  const plan = await fetchPlan(dictUrl)
  const indexOf = new Map<string, number>()
  plan.forEach((w, i) => indexOf.set(w.name, i))

  const chunks = new Set<number>()
  for (const n of names) {
    const i = indexOf.get(n)
    if (i !== undefined) chunks.add(Math.floor(i / CHUNK_SIZE))
  }

  const lists = await Promise.all(Array.from(chunks).map((n) => fetchChunk(dictUrl, n)))
  const byName = new Map<string, Word>()
  for (const list of lists) for (const w of list) byName.set(w.name, w)

  return names.map((n) => byName.get(n)).filter((w): w is Word => Boolean(w))
}
