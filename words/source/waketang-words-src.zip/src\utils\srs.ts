/**
 * 艾宾浩斯复习调度（固定间隔版）
 *
 * 蛙课堂背单词的核心记忆模型，与 UI 解耦，纯函数，便于单独验证。
 *
 * 阶段与间隔的对应关系：
 *
 *   stage 0  刚学完，当天不复习，次日首次复习
 *   stage 0 --答对--> stage 1，1 天后复习
 *   stage 1 --答对--> stage 2，2 天后复习
 *   stage 2 --答对--> stage 3，4 天后复习
 *   stage 3 --答对--> stage 4，7 天后复习
 *   stage 4 --答对--> stage 5，15 天后复习
 *   stage 5 --答对--> 已掌握，退出日常队列
 *
 * 即复习间隔依次为 1 / 2 / 4 / 7 / 15 天。
 * 答错则回退两档并次日重来（回退一档惩罚太轻，回退到底又太狠）。
 */

import type { Word } from '@/typings'

/** 各阶段的复习间隔（天） */
export const SRS_INTERVALS = [1, 2, 4, 7, 15]

/**
 * 达到该阶段即视为已掌握。
 *
 * 阶段含义 = 已通过的复习次数：
 *   stage 0  刚学完（当天不复习，次日首次复习）
 *   stage 1  已通过第 1 次复习
 *   stage 2  已通过第 2 次复习
 *   stage 3  已通过第 3 次复习
 *   stage 4  已通过第 4 次复习
 *   stage 5  已通过第 5 次复习 → 掌握，退出日常队列
 *
 * 复习间隔由「通过后所处的新阶段」决定：
 *   学完 --1天--> 第1次 --2天--> 第2次 --4天--> 第3次 --7天--> 第4次 --15天--> 第5次 → 掌握
 */
export const MASTERED_STAGE = SRS_INTERVALS.length // 5

/** 答错时回退的档数 */
export const WRONG_FALLBACK = 2

// ── 日期工具（一律用本地时区的 YYYY-MM-DD 字符串，避免时区错位）──

/** 本地时区的今天，YYYY-MM-DD */
export function todayStr(date: Date = new Date()): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

/** 在 YYYY-MM-DD 基础上加 n 天 */
export function addDays(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number)
  const dt = new Date(y, m - 1, d)
  dt.setDate(dt.getDate() + days)
  return todayStr(dt)
}

/** 两个 YYYY-MM-DD 之间相差的天数（b - a） */
export function daysBetween(a: string, b: string): number {
  const [ay, am, ad] = a.split('-').map(Number)
  const [by, bm, bd] = b.split('-').map(Number)
  const ta = new Date(ay, am - 1, ad).getTime()
  const tb = new Date(by, bm - 1, bd).getTime()
  return Math.round((tb - ta) / 86400000)
}

// ── 阶段推进 ──

export function isMasteredStage(stage: number): boolean {
  return stage >= MASTERED_STAGE
}

/** 处于阶段 n 时，到下一次复习的间隔天数（n 为 1..4，对应 2/4/7/15 天） */
export function intervalForStage(stage: number): number {
  return SRS_INTERVALS[Math.min(Math.max(stage, 0), SRS_INTERVALS.length - 1)]
}

export type AnswerResult = {
  stage: number
  mastered: boolean
  /** 下次复习日期；已掌握时为 null */
  dueDate: string | null
}

/**
 * 一次作答之后的新记忆状态。
 *
 * @param stage      作答前的阶段
 * @param correct    本次是否答对
 * @param today      作答日期，默认今天
 */
export function applyAnswer(stage: number, correct: boolean, today: string = todayStr()): AnswerResult {
  if (correct) {
    const next = stage + 1
    if (isMasteredStage(next)) {
      return { stage: next, mastered: true, dueDate: null }
    }
    // ⚠️ 必须用「新阶段」取间隔：首次复习通过后应隔 2 天。
    //    若用旧阶段（0）会取到 1 天，间隔序列会变成 1,1,2,4,7,15（已由 tools/test-srs.mjs 抓到过）。
    return { stage: next, mastered: false, dueDate: addDays(today, intervalForStage(next)) }
  }

  const next = Math.max(0, stage - WRONG_FALLBACK)
  return { stage: next, mastered: false, dueDate: addDays(today, 1) }
}

/** 新学一个词时的初始记忆状态：stage 0，次日首次复习 */
export function initialMemory(today: string = todayStr()): AnswerResult {
  return { stage: 0, mastered: false, dueDate: addDays(today, SRS_INTERVALS[0]) }
}

/**
 * 今天这一次作答，要不要推进/回退档位？
 *
 * 「选词记忆」和「拼写练习」是两条并列的路，同一天很可能都碰到同一个词。
 * 如果两次都推进档位，这个词一天就跳了两档，1/2/4/7/15 的复习节奏会被打乱。
 * 所以规则是：**同一天同一个词只处理一次推进**。
 *
 *   · 答错 → 永远照常处理（回退两档 + 进生词本）。错就是错，不能因为今天记过一次就免罚。
 *   · 答对 → 看当天有没有记过。已经记过就跳过，不再推进。
 *
 * @param lastReviewDate 该词最近一次作答日期（YYYY-MM-DD）
 * @param correct        本次是否答对
 * @param today          本次作答日期
 */
export function shouldAdvanceToday(lastReviewDate: string, correct: boolean, today: string = todayStr()): boolean {
  if (!correct) return true
  return lastReviewDate !== today
}

/**
 * 计算连续打卡天数。
 *
 * 从今天（若今天还没学，则从昨天）开始往前逐日回溯，看这些日期是否都出现过。
 * 只要有连续的天数就累加，断掉即停。
 *
 * @param dateStrs 学习过的日期集合（YYYY-MM-DD，可有重复）
 */
export function computeStreak(dateStrs: string[], today: string = todayStr()): number {
  const studied = new Set(dateStrs.filter(Boolean))
  if (studied.size === 0) return 0

  // 今天还没开始学不算断签，从昨天接着数
  let cursor = studied.has(today) ? today : addDays(today, -1)
  if (!studied.has(cursor)) return 0

  let streak = 0
  while (studied.has(cursor)) {
    streak++
    cursor = addDays(cursor, -1)
    if (streak > 3650) break // 防御性上限
  }
  return streak
}

// ── 今日队列 ──

/** 调度器需要的记忆状态（与 Dexie 表结构对应的最小子集） */
export type MemoryState = {
  word: string
  stage: number
  dueDate: string
  mastered: boolean
  /** 通过选词记忆的日期；'' = 明确没通过；undefined = 门禁上线前的老数据 */
  recalledDate?: string
  /** 最近一次拼写的日期；'' / undefined = 没拼过 */
  typedDate?: string
  /** 首次学习日期，用来给「上次没认过的词」排先后 */
  firstLearnDate?: string
}

/**
 * 「先认后拼」门禁：这个词允许进拼写练习了吗？（用户 2026-10-06 拍板）
 *
 * recalledDate 的三种取值，含义必须分清：
 *   'YYYY-MM-DD'  已在选词记忆里**答对**过 → 放行
 *   ''            选词记忆里选错了 → 拦住，要重新认
 *   undefined     门禁规则上线**之前**学的老数据 → 按「以前认过就算」放行
 *
 * 所以判据是 `!== ''`，不是真值判断 —— 用 `Boolean()` 会把老数据一起拦掉。
 */
export function hasPassedRecall(m: { recalledDate?: string }): boolean {
  return m.recalledDate !== ''
}

export type TodayPlanOptions = {
  /** 每日新词上限 */
  dailyNew: number
  /** 每日复习上限 */
  dailyReviewMax: number
  /** 今天只复习、不学新词 */
  reviewOnly: boolean
  /** 覆盖「今天」，便于测试 */
  today?: string
}

export type TodayPlan = {
  /** 今日要复习的词（已按到期先后排序并截断到上限）—— 有记录，直接进拼写 */
  reviewWords: Word[]
  /**
   * 「选词记忆」的队列 = 还没通过选词记忆的词。
   *
   * 两拨：
   *   a) 上次在选词记忆里选错、还没通过的（先还欠的账）
   *   b) 词书里全新的词
   * 合起来不超过 dailyNew 个。
   * ⚠️ 这批词**不允许**进拼写练习 —— 先认后拼。
   */
  newWords: Word[]
  /**
   * 今天通过了选词记忆、但还没在拼写里打过的词。
   * 「认完接着拼」要拼的就是这批（加上 reviewWords）。
   */
  readyToTypeWords: Word[]
  /** 到期复习总数（截断前的真实数量） */
  dueTotal: number
  /** 是否发生了截断（到期数超过上限） */
  truncated: boolean
  /** 是否积压严重，应提示先清复习 */
  backlog: boolean
  /** 词库总词数 */
  totalWords: number
  /** 已掌握词数 */
  masteredWords: number
  /** 已学过的词数（有记忆记录即算） */
  learnedWords: number
}

/**
 * 生成今日学习计划。
 *
 * @param allWords 当前词书的全部单词
 * @param memory   该词书已有的记忆状态
 */
export function buildTodayPlan(allWords: Word[], memory: MemoryState[], options: TodayPlanOptions): TodayPlan {
  const today = options.today ?? todayStr()
  const byName = new Map(allWords.map((w) => [w.name, w]))
  const memoryByWord = new Map(memory.map((m) => [m.word, m]))

  // 1. 到期复习：未掌握且 dueDate <= 今天，按到期日升序（拖得最久的先复习）
  const dueAll = memory
    .filter((m) => !m.mastered && m.dueDate <= today)
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate))

  const dueSlice = dueAll.slice(0, Math.max(0, options.dailyReviewMax))
  const reviewWords = dueSlice.map((m) => byName.get(m.word)).filter((w): w is Word => Boolean(w))

  // 2. 选词记忆队列：还没通过门禁的词
  const budget = options.reviewOnly ? 0 : Math.max(0, options.dailyNew)

  //   a) 有记录但没通过的（上次选错了）—— 欠的先还，按首次学习日升序
  const retryRecall = memory
    .filter((m) => !m.mastered && !hasPassedRecall(m))
    .sort((a, b) => (a.firstLearnDate ?? '').localeCompare(b.firstLearnDate ?? ''))
    .slice(0, budget)
    .map((m) => byName.get(m.word))
    .filter((w): w is Word => Boolean(w))

  //   b) 词书里全新的词（一条记录都没有），把名额补满
  const freshNew = allWords.filter((w) => !memoryByWord.has(w.name)).slice(0, Math.max(0, budget - retryRecall.length))

  const newWords = [...retryRecall, ...freshNew]

  // 3. 今天认过了、还没拼的 —— 「认完接着拼」拼的就是这批
  const readyToTypeWords = memory
    .filter((m) => !m.mastered && m.recalledDate === today && m.typedDate !== today)
    .map((m) => byName.get(m.word))
    .filter((w): w is Word => Boolean(w))

  const masteredWords = memory.filter((m) => m.mastered).length

  return {
    reviewWords,
    newWords,
    readyToTypeWords,
    dueTotal: dueAll.length,
    truncated: dueAll.length > dueSlice.length,
    backlog: dueAll.length > options.dailyReviewMax * 2,
    totalWords: allWords.length,
    masteredWords,
    learnedWords: memory.length,
  }
}
