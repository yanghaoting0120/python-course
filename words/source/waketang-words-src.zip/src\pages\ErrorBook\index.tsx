import DropdownExport from './DropdownExport'
import ErrorRow from './ErrorRow'
import type { ISortType } from './HeadWrongNumber'
import HeadWrongNumber from './HeadWrongNumber'
import Pagination, { ITEM_PER_PAGE } from './Pagination'
import RowDetail from './RowDetail'
import { currentRowDetailAtom } from './store'
import type { groupedWordRecords } from './type'
import Header from '@/components/Header'
import Setting from '@/components/Setting'
import { currentDictIdAtom } from '@/store'
import { db, useDeleteWordRecord, useMemoryRecords } from '@/utils/db'
import type { WordRecord } from '@/utils/db/record'
import { MASTERED_STAGE, SRS_INTERVALS } from '@/utils/srs'
import * as ScrollArea from '@radix-ui/react-scroll-area'
import IconTrophy from '~icons/tabler/trophy'
import { useAtomValue } from 'jotai'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

/**
 * 错词本。
 *
 * 评审 B6：
 *   B6-1  空状态没有任何提示（表头下面一片白）→ 补统一 EmptyState，并在无数据时隐藏分页
 *   B6-1b 分页「1 / 0」不合法 → Pagination 内已修（总页数下限 1 + 边界禁用）
 *   B6-2  提示语中英混排且在最右上角 → 改中文小字，移到表头左侧
 *   B6-3  「词典」列信息量极低 → 换成「阶段」（该词排到哪一档复习）
 *   B6-4  「导出」是页头最亮的元素 → 降为次要按钮（见 DropdownExport）
 */

export function ErrorBook() {
  const [groupedRecords, setGroupedRecords] = useState<groupedWordRecords[]>([])
  const [currentPage, setCurrentPage] = useState(1)
  const totalPages = useMemo(() => Math.ceil(groupedRecords.length / ITEM_PER_PAGE), [groupedRecords.length])
  const [sortType, setSortType] = useState<ISortType>('asc')
  const navigate = useNavigate()
  const currentRowDetail = useAtomValue(currentRowDetailAtom)
  const { deleteWordRecord } = useDeleteWordRecord()
  const [reload, setReload] = useState(false)

  const dictId = useAtomValue(currentDictIdAtom)
  const memory = useMemoryRecords(dictId)

  /** 词 → 复习阶段文字 */
  const stageMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const m of memory) {
      if (m.mastered || m.stage >= MASTERED_STAGE) map.set(m.word, '已掌握')
      else map.set(m.word, `${SRS_INTERVALS[Math.min(Math.max(m.stage, 0), SRS_INTERVALS.length - 1)]} 天档`)
    }
    return map
  }, [memory])

  const onBack = useCallback(() => {
    navigate('/')
  }, [navigate])

  const setPage = useCallback(
    (page: number) => {
      if (page < 1 || page > Math.max(1, totalPages)) return
      setCurrentPage(page)
    },
    [totalPages],
  )

  const setSort = useCallback(
    (sortType: ISortType) => {
      setSortType(sortType)
      setPage(1)
    },
    [setPage],
  )

  const sortedRecords = useMemo(() => {
    if (sortType === 'none') return groupedRecords
    return [...groupedRecords].sort((a, b) => {
      if (sortType === 'asc') {
        return a.wrongCount - b.wrongCount
      } else {
        return b.wrongCount - a.wrongCount
      }
    })
  }, [groupedRecords, sortType])

  const renderRecords = useMemo(() => {
    const start = (currentPage - 1) * ITEM_PER_PAGE
    const end = start + ITEM_PER_PAGE
    return sortedRecords.slice(start, end)
  }, [currentPage, sortedRecords])

  useEffect(() => {
    db.wordRecords
      .where('wrongCount')
      .above(0)
      .toArray()
      .then((records) => {
        const groups: groupedWordRecords[] = []

        records.forEach((record) => {
          let group = groups.find((g) => g.word === record.word && g.dict === record.dict)
          if (!group) {
            group = { word: record.word, dict: record.dict, records: [], wrongCount: 0 }
            groups.push(group)
          }
          group.records.push(record as WordRecord)
        })

        groups.forEach((group) => {
          group.wrongCount = group.records.reduce((acc, cur) => {
            acc += cur.wrongCount
            return acc
          }, 0)
        })

        setGroupedRecords(groups)
      })
  }, [reload])

  const handleDelete = async (word: string, dict: string) => {
    await deleteWordRecord(word, dict)
    setReload((prev) => !prev)
  }

  const isEmpty = groupedRecords.length === 0

  return (
    <>
      <div className={`flex h-screen w-full flex-col items-center ${currentRowDetail ? 'blur-sm' : ''}`}>
        <Header>
          <Link className="btn-secondary btn-sm" to="/">
            返回今日
          </Link>
          <Setting />
        </Header>

        <div className="container-app flex min-h-0 flex-1 flex-col pb-6">
          {isEmpty ? (
            <div className="glass empty-state mx-auto mt-16 w-full max-w-md rounded-2xl">
              <span className="empty-state-icon">
                <IconTrophy className="h-7 w-7" />
              </span>
              <p className="empty-state-title">还没有错词</p>
              <p className="empty-state-desc">继续保持。打错过的词会自动出现在这里。</p>
              <Link className="my-btn-primary mt-1" to="/">
                去学习
              </Link>
            </div>
          ) : (
            <>
              {/* B6-2：提示移到表头左侧、改中文小字 */}
              <div className="mb-3 flex items-center gap-3">
                <h2 className="c-ink t-h2">错词本</h2>
                <span className="c-faint t-micro">点击单词可查看详情</span>
                <span className="c-faint t-micro ml-auto">共 {groupedRecords.length} 个词</span>
              </div>

              <div className="glass flex w-full items-center justify-between rounded-xl px-6 py-3">
                <span className="c-muted t-micro basis-2/12">单词</span>
                <span className="c-muted t-micro basis-6/12">释义</span>
                <HeadWrongNumber className="basis-1/12" sortType={sortType} setSortType={setSort} />
                <span className="c-muted t-micro basis-2/12">阶段</span>
                <DropdownExport renderRecords={sortedRecords} />
              </div>

              <ScrollArea.Root className="min-h-0 flex-1 overflow-y-auto pt-4">
                <ScrollArea.Viewport className="h-full">
                  <div className="flex flex-col gap-2.5">
                    {renderRecords.map((record) => (
                      <ErrorRow
                        key={`${record.dict}-${record.word}`}
                        record={record}
                        stageText={stageMap.get(record.word)}
                        onDelete={() => handleDelete(record.word, record.dict)}
                      />
                    ))}
                  </div>
                </ScrollArea.Viewport>
                <ScrollArea.Scrollbar className="flex touch-none select-none bg-transparent" orientation="vertical"></ScrollArea.Scrollbar>
              </ScrollArea.Root>

              {/* B6-1：有数据时才显示分页 */}
              {totalPages > 1 ? (
                <div className="flex justify-center pt-3">
                  <Pagination page={currentPage} setPage={setPage} totalPages={totalPages} />
                </div>
              ) : null}
            </>
          )}
        </div>
      </div>
      {currentRowDetail && <RowDetail currentRowDetail={currentRowDetail} allRecords={sortedRecords} />}
    </>
  )
}
