import { LoadingWordUI } from './LoadingWordUI'
import useGetWord from './hooks/useGetWord'
import { currentRowDetailAtom } from './store'
import type { groupedWordRecords } from './type'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { idDictionaryMap } from '@/resources/dictionary'
import { recordErrorBookAction } from '@/utils'
import { useSetAtom } from 'jotai'
import type { FC } from 'react'
import { useCallback } from 'react'
import DeleteIcon from '~icons/weui/delete-filled'

type IErrorRowProps = {
  record: groupedWordRecords
  onDelete: () => void
  /**
   * 复习阶段文字（评审 B6-3）。
   * 原来这一列显示「词典」—— 本项目只有 24 本词书、且主要是 CET-4，
   * 这一列几乎没有信息量。换成"当前阶段（1/2/4/7/15 天档位）"才有用。
   */
  stageText?: string
}

const ErrorRow: FC<IErrorRowProps> = ({ record, onDelete, stageText }) => {
  const setCurrentRowDetail = useSetAtom(currentRowDetailAtom)
  const dictInfo = idDictionaryMap[record.dict]
  const { word, isLoading, hasError } = useGetWord(record.word, dictInfo)

  const onClick = useCallback(() => {
    setCurrentRowDetail(record)
    recordErrorBookAction('detail')
  }, [record, setCurrentRowDetail])

  return (
    <li
      className="glass glass-interactive flex w-full cursor-pointer items-center justify-between rounded-xl px-6 py-3"
      onClick={onClick}
    >
      <span className="c-ink t-sm basis-2/12 break-normal font-semibold">{record.word}</span>
      <span className="c-soft t-sm basis-6/12 break-normal">
        {word ? word.trans.join('；') : <LoadingWordUI isLoading={isLoading} hasError={hasError} />}
      </span>
      <span className="c-soft t-sm basis-1/12 break-normal pl-8 tabular-nums">{record.wrongCount}</span>
      <span className="c-muted t-sm basis-2/12 break-normal">{stageText ?? '—'}</span>
      <span
        className="c-faint basis-1/12 break-normal transition-colors hover:text-[color:var(--c-danger-text)]"
        onClick={(e) => {
          e.stopPropagation()
          onDelete()
        }}
      >
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <DeleteIcon />
            </TooltipTrigger>
            <TooltipContent>
              {/* C13：原来这里是英文 "Delete Records" */}
              <p>删除这条记录</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </span>
    </li>
  )
}

export default ErrorRow
