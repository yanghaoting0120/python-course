import Layout from '../../components/Layout'
import { DictChapterButton } from './components/DictChapterButton'
import PronunciationSwitcher from './components/PronunciationSwitcher'
import ResultScreen from './components/ResultScreen'
import Setting from '@/components/Setting'
import Speed from './components/Speed'
import StartButton from './components/StartButton'
import Switcher from './components/Switcher'
import WordList, { WordListTrigger } from './components/WordList'
import WordPanel from './components/WordPanel'
import { useConfetti } from './hooks/useConfetti'
import { useWordList } from './hooks/useWordList'
import { TypingContext, TypingStateActionType, initialState, typingReducer } from './store'
import Header from '@/components/Header'
import { idDictionaryMap } from '@/resources/dictionary'
import { currentChapterAtom, currentDictIdAtom, isReviewModeAtom, randomConfigAtom, reviewModeInfoAtom, todaySessionAtom } from '@/store'
import { IsDesktop, isLegal } from '@/utils'
import { useSaveChapterRecord } from '@/utils/db'
import { useMixPanelChapterLogUploader } from '@/utils/mixpanel'
import { useAtom, useAtomValue, useSetAtom } from 'jotai'
import type React from 'react'
import { useCallback, useEffect, useState } from 'react'
import { useImmerReducer } from 'use-immer'
import { Link } from 'react-router-dom'

const App: React.FC = () => {
  const [state, dispatch] = useImmerReducer(typingReducer, structuredClone(initialState))
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const { words } = useWordList()

  const [currentDictId, setCurrentDictId] = useAtom(currentDictIdAtom)
  const setCurrentChapter = useSetAtom(currentChapterAtom)
  const randomConfig = useAtomValue(randomConfigAtom)
  const chapterLogUploader = useMixPanelChapterLogUploader(state)
  const saveChapterRecord = useSaveChapterRecord()

  const reviewModeInfo = useAtomValue(reviewModeInfoAtom)
  const isReviewMode = useAtomValue(isReviewModeAtom)
  const setTodaySession = useSetAtom(todaySessionAtom)

  useEffect(() => {
    // 检测用户设备
    if (!IsDesktop()) {
      setTimeout(() => {
        alert(
          '蛙课堂背单词需要键盘输入，建议使用电脑浏览器访问。如果你用的是 iPad 等平板，可以外接键盘使用。',
        )
      }, 500)
    }
  }, [])

  // 在组件挂载和currentDictId改变时，检查当前字典是否存在，如果不存在，则将其重置为默认值
  useEffect(() => {
    const id = currentDictId
    if (!(id in idDictionaryMap)) {
      setCurrentDictId('cet4')
      setCurrentChapter(0)
      return
    }
  }, [currentDictId, setCurrentChapter, setCurrentDictId])

  const skipWord = useCallback(() => {
    dispatch({ type: TypingStateActionType.SKIP_WORD })
  }, [dispatch])

  useEffect(() => {
    const onBlur = () => {
      dispatch({ type: TypingStateActionType.SET_IS_TYPING, payload: false })
    }
    window.addEventListener('blur', onBlur)

    return () => {
      window.removeEventListener('blur', onBlur)
    }
  }, [dispatch])

  useEffect(() => {
    state.chapterData.words?.length > 0 ? setIsLoading(false) : setIsLoading(true)
  }, [state.chapterData.words])

  useEffect(() => {
    if (!state.isTyping) {
      const onKeyDown = (e: KeyboardEvent) => {
        if (!isLoading && e.key !== 'Enter' && (isLegal(e.key) || e.key === ' ') && !e.altKey && !e.ctrlKey && !e.metaKey) {
          e.preventDefault()
          dispatch({ type: TypingStateActionType.SET_IS_TYPING, payload: true })
        }
      }
      window.addEventListener('keydown', onKeyDown)

      return () => window.removeEventListener('keydown', onKeyDown)
    }
  }, [state.isTyping, isLoading, dispatch])

  useEffect(() => {
    if (words !== undefined) {
      const initialIndex = isReviewMode && reviewModeInfo.reviewRecord?.index ? reviewModeInfo.reviewRecord.index : 0

      dispatch({
        type: TypingStateActionType.SETUP_CHAPTER,
        payload: { words, shouldShuffle: randomConfig.isOpen, initialIndex },
      })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [words])

  useEffect(() => {
    // 当用户完成章节后且完成 word Record 数据保存，记录 chapter Record 数据,
    if (state.isFinished && !state.isSavingRecord) {
      chapterLogUploader()
      saveChapterRecord(state)
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.isFinished, state.isSavingRecord])

  useEffect(() => {
    // 启动计时器
    let intervalId: number
    if (state.isTyping) {
      intervalId = window.setInterval(() => {
        dispatch({ type: TypingStateActionType.TICK_TIMER })
      }, 1000)
    }
    return () => clearInterval(intervalId)
  }, [state.isTyping, dispatch])

  useConfetti(state.isFinished)

  // 打完今日计划不再自动跳走。
  // 原来会跳到 /quiz（学完即测），但那个页面导航栏里没有入口，
  // 等于把「选择题」藏在了必须打完全部词之后 —— 已改成独立的 /recall（选词记忆），
  // 从今日页直接进。这里只保留结果屏，由用户自己决定下一步。

  return (
    <TypingContext.Provider value={{ state: state, dispatch }}>
      {state.isFinished && <ResultScreen />}
      <Layout>
        <Header>
          {/* 第 2 批：六个同款描边小按钮挤一行，视觉噪音大。
              不改抽屉（用户明确说过不要抽屉），只在「去哪」和「干什么」之间加一道细分隔线。 */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {/* 导航组：换地方 */}
            <Link className="btn-secondary btn-sm whitespace-nowrap" to="/" onClick={() => setTodaySession(null)}>
              今日
            </Link>
            <DictChapterButton />
            <PronunciationSwitcher />

            <span className="mx-1 hidden h-5 w-px bg-[color:var(--c-line)] md:inline-block" aria-hidden />

            {/* 操作组：对当前这一轮做点什么 */}
            <WordListTrigger />
            {state.isShowSkip && (
              <button className="btn-secondary btn-sm whitespace-nowrap" onClick={skipWord} type="button">
                跳过此词
              </button>
            )}
            {/* 设置：原来藏在「更多」面板最底部一个 26px 的小齿轮里，只有图标没有文字。
                现在直接摆在工具栏上，一眼能看到。 */}
            <Setting />
            <StartButton isLoading={isLoading} />
            <Switcher />
          </div>
        </Header>
        {/* 统一容器：页头、词卡、进度条、底部统计条从此共用同一个宽度 */}
        <div className="container-app flex h-full flex-1 flex-col items-center pb-5">
          <div className="flex h-full w-full flex-col">
            {/* ⚠️ 这里原来是 `flex ... items-center`：交叉轴居中会让 WordPanel 不拉伸，
                词卡只占内容高度，词卡和底部统计条之间空出一大截。
                改成 flex-col，让 WordPanel 作为 flex 子项撑满剩余高度。 */}
            <div className="flex w-full flex-grow flex-col">
              {isLoading ? (
                <div className="flex flex-1 items-center justify-center">
                  <div
                    className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid  border-brand-400 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
                    role="status"
                  ></div>
                </div>
              ) : (
                !state.isFinished && <WordPanel />
              )}
            </div>
            <Speed />
          </div>
        </div>
      </Layout>
      <WordList />
    </TypingContext.Provider>
  )
}

export default App
