import { currentChapterAtom, currentDictInfoAtom, isReviewModeAtom } from '@/store'
import range from '@/utils/range'
import { Popover } from '@headlessui/react'
import { useAtom, useAtomValue } from 'jotai'
import { NavLink } from 'react-router-dom'
import IconCheck from '~icons/tabler/check'
import IconChevronDown from '~icons/tabler/chevron-down'

/**
 * 词书 + 章节入口。
 *
 * 原版是两个分开的纯文字按钮（「CET-4」和「第 1 章」），
 * 都没有 white-space: nowrap，容器一挤就折成两行
 * （截图里出现过 "CET-" / "4" 和 "第 1" / "章"）。
 * 这里合并成一个按钮 + 弹出面板：按钮上永远是一行，章节在面板里滚动选。
 */
export const DictChapterButton = () => {
  const currentDictInfo = useAtomValue(currentDictInfoAtom)
  const [currentChapter, setCurrentChapter] = useAtom(currentChapterAtom)
  const chapterCount = currentDictInfo.chapterCount
  const isReviewMode = useAtomValue(isReviewModeAtom)

  return (
    <Popover className="relative">
      <Popover.Button className="btn-secondary btn-sm whitespace-nowrap">
        {currentDictInfo.name}
        {isReviewMode ? ' · 错题复习' : ` · 第 ${currentChapter + 1} 章`}
        <IconChevronDown className="h-4 w-4" />
      </Popover.Button>

      <Popover.Panel className="glass-strong absolute left-0 z-40 mt-2 w-60 rounded-2xl p-2.5 shadow-xl">
        {!isReviewMode && (
          <>
            <div className="c-faint px-2.5 pb-1 pt-1 text-[11px] font-bold tracking-wider">选择章节</div>
            <div className="max-h-72 overflow-y-auto pr-1">
              {range(0, chapterCount, 1).map((index) => {
                const selected = index === currentChapter
                return (
                  <button
                    key={index}
                    type="button"
                    onClick={() => setCurrentChapter(index)}
                    className={`flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-left text-sm transition-colors ${
                      selected ? 'c-brand font-bold' : 'c-soft hover:bg-black/[0.05] dark:hover:bg-white/[0.07]'
                    }`}
                  >
                    <span className="whitespace-nowrap">第 {index + 1} 章</span>
                    {selected ? <IconCheck className="h-4 w-4" /> : null}
                  </button>
                )
              })}
            </div>
          </>
        )}

        <div className="mt-2 border-t border-[color:var(--c-line)] pt-2">
          <NavLink
            to="/gallery"
            className="c-brand block rounded-lg px-2.5 py-1.5 text-sm font-bold transition-colors hover:bg-black/[0.05] dark:hover:bg-white/[0.07]"
          >
            换词书 / 查看全部词库
          </NavLink>
        </div>
      </Popover.Panel>
    </Popover>
  )
}
