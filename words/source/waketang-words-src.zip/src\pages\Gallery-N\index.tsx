import DictionaryGroup from './CategoryDicts'
import { LanguageTabSwitcher } from './LanguageTabSwitcher'
import Header from '@/components/Header'
import Layout from '@/components/Layout'
import Setting from '@/components/Setting'
import { dictionaries } from '@/resources/dictionary'
import { currentDictInfoAtom } from '@/store'
import type { Dictionary, LanguageCategoryType } from '@/typings'
import groupBy, { groupByDictTags } from '@/utils/groupBy'
import * as ScrollArea from '@radix-ui/react-scroll-area'
import { useAtomValue } from 'jotai'
import { createContext, useCallback, useEffect, useMemo } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import { Link, useNavigate } from 'react-router-dom'
import type { Updater } from 'use-immer'
import { useImmer } from 'use-immer'

/**
 * 词库页。
 *
 * 评审 B4 的三处清理：
 *   B4-1 删掉 pl-20（80px 左空槽，原分类导航被注释后留下的）、
 *        删掉 pt-[20rem]（320px 空白带）与那段占满屏的版权长文（改一行 12px 说明）
 *   B4-2 移除「寻找更多词典」——它会打开原作者的商业站 qwertylearner.ai，
 *        与"本地自用、切断外链"的原则冲突，而且本项目只有 24 本词书，没有实际用途
 *   B4-3 补上统一页头（原来本页是六个页面里唯一没有 logo / 没有全局导航的）
 */

export type GalleryState = {
  currentLanguageTab: LanguageCategoryType
}

const initialGalleryState: GalleryState = {
  currentLanguageTab: 'en',
}

export const GalleryContext = createContext<{
  state: GalleryState
  setState: Updater<GalleryState>
} | null>(null)

export default function GalleryPage() {
  const [galleryState, setGalleryState] = useImmer<GalleryState>(initialGalleryState)
  const navigate = useNavigate()
  const currentDictInfo = useAtomValue(currentDictInfoAtom)

  const { groupedByCategoryAndTag } = useMemo(() => {
    const currentLanguageCategoryDicts = dictionaries.filter((dict) => dict.languageCategory === galleryState.currentLanguageTab)
    const groupedByCategory = Object.entries(groupBy(currentLanguageCategoryDicts, (dict) => dict.category))
    const groupedByCategoryAndTag = groupedByCategory.map(
      ([category, dicts]) => [category, groupByDictTags(dicts)] as [string, Record<string, Dictionary[]>],
    )

    return {
      groupedByCategoryAndTag,
    }
  }, [galleryState.currentLanguageTab])

  const onBack = useCallback(() => {
    navigate('/')
  }, [navigate])

  useHotkeys('enter,esc', onBack, { preventDefault: true })

  useEffect(() => {
    if (currentDictInfo) {
      setGalleryState((state) => {
        state.currentLanguageTab = currentDictInfo.languageCategory
      })
    }
  }, [currentDictInfo, setGalleryState])

  return (
    <Layout>
      <GalleryContext.Provider value={{ state: galleryState, setState: setGalleryState }}>
        <Header>
          <Link className="btn-secondary btn-sm" to="/">
            返回今日
          </Link>
          <Setting />
        </Header>

        <div className="container-app flex min-h-0 flex-1 flex-col overflow-y-auto pb-10">
          <div className="mb-5 flex items-center justify-between">
            <LanguageTabSwitcher />
          </div>

          <ScrollArea.Root className="min-h-0 flex-1 overflow-y-auto">
            <ScrollArea.Viewport className="h-full w-full">
              {/* 不用 items-start：那会让分组只有内容宽度，卡片网格没法自己居中 */}
              <div className="flex flex-col gap-8 pr-1">
                {groupedByCategoryAndTag.map(([category, groupeByTag]) => (
                  <DictionaryGroup key={category} groupedDictsByTag={groupeByTag} />
                ))}
              </div>

              <p className="c-faint t-micro pb-6 pt-10 text-center">词库数据来自 kajweb 开源词表，仅供个人学习使用。</p>
            </ScrollArea.Viewport>
            <ScrollArea.Scrollbar className="flex touch-none select-none bg-transparent" orientation="vertical"></ScrollArea.Scrollbar>
          </ScrollArea.Root>
        </div>
      </GalleryContext.Provider>
    </Layout>
  )
}
