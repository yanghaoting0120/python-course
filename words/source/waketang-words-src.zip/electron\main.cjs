/**
 * 蛙课堂背单词 · Electron 主进程
 *
 * 为什么不用 file:// 直接加载 build/index.html：
 *   Chromium 在 file:// 下会把页面 origin 视作 null，fetch 相对路径一律被拦，
 *   结果是词库 json（dicts/*.json）和发音音频都读不出来。
 *   所以这里注册一个自有协议 app://，由主进程按需把文件喂给渲染进程，
 *   这样 fetch('./dicts/cet4.json') 能正常工作，localStorage / IndexedDB 也有稳定 origin。
 */
const { app, BrowserWindow, Menu, dialog, protocol, net, screen, shell } = require('electron')
const fs = require('node:fs')
const path = require('node:path')
const { pathToFileURL } = require('node:url')

const APP_SCHEME = 'app'
const APP_HOST = 'local'
const APP_ORIGIN = `${APP_SCHEME}://${APP_HOST}`
const DIST_DIR = path.join(__dirname, '..', 'build')
const ICON_FILE = path.join(__dirname, '..', 'build-assets', 'icon.ico')

// 自定义协议必须在 app ready 之前登记成「特权协议」，
// 否则 fetch / 流式响应 / 安全上下文这几项能力不会被授予。
protocol.registerSchemesAsPrivileged([
  {
    scheme: APP_SCHEME,
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      stream: true,
      codeCache: true,
    },
  },
])

// 学习记录存在这里（Dexie / IndexedDB）。固定成 ASCII 目录名，
// 免得中文路径在某些环节出岔子；一旦改名，历史记录就读不到了。
app.setPath('userData', path.join(app.getPath('appData'), 'waketang-words'))
app.setAppUserModelId('com.waketang.words')

// 单实例：重复双击只聚焦已有窗口。开两个进程会同时抢同一个 IndexedDB，容易损坏记录。
if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  app.on('second-instance', () => {
    const win = BrowserWindow.getAllWindows()[0]
    if (!win) return
    if (win.isMinimized()) win.restore()
    win.focus()
  })
}

/** 把 app:// 请求映射到 build/ 目录下的真实文件，找不到就回退 index.html（支持前端路由刷新） */
function handleAppRequest(request) {
  let pathname
  try {
    pathname = decodeURIComponent(new URL(request.url).pathname)
  } catch {
    return new Response('Bad Request', { status: 400 })
  }

  if (pathname === '' || pathname === '/') pathname = '/index.html'

  const filePath = path.resolve(DIST_DIR, `.${pathname}`)
  // 目录穿越防护：解析后必须还在 build/ 里面
  if (filePath !== DIST_DIR && !filePath.startsWith(DIST_DIR + path.sep)) {
    return new Response('Forbidden', { status: 403 })
  }

  let target = filePath
  if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
    target = path.join(DIST_DIR, 'index.html')
  }
  if (!fs.existsSync(target)) return new Response('Not Found', { status: 404 })

  return net.fetch(pathToFileURL(target).toString())
}

function createWindow() {
  // 这台机器是 150% 缩放，1280 逻辑像素已经等于整块屏幕的物理宽度，
  // 直接写死尺寸会变成「一开就是全屏」。所以按可用工作区算，留一点边距。
  const { workAreaSize } = screen.getPrimaryDisplay()
  const width = Math.min(1280, Math.round(workAreaSize.width * 0.94))
  const height = Math.min(860, Math.round(workAreaSize.height * 0.94))

  const win = new BrowserWindow({
    width,
    height,
    minWidth: Math.min(1024, width),
    minHeight: Math.min(660, height),
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#ffffff',
    title: '蛙课堂背单词',
    ...(fs.existsSync(ICON_FILE) ? { icon: ICON_FILE } : {}),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      // 打字页会用到 <audio>，默认就是 true，这里只是写明白
      autoplayPolicy: 'no-user-gesture-required',
    },
  })

  // 先把窗口藏起来，等首屏渲染好再显示，避免白屏闪一下
  win.once('ready-to-show', () => win.show())

  // 站内链接在应用内跳，外部链接一律丢给系统浏览器，别在应用窗口里打开
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url)
    return { action: 'deny' }
  })
  win.webContents.on('will-navigate', (event, url) => {
    if (url.startsWith(APP_ORIGIN)) return
    event.preventDefault()
    if (/^https?:/i.test(url)) shell.openExternal(url)
  })

  // 没有菜单栏，所以快捷键得自己接：F12 / Ctrl+Shift+I 开发者工具，
  // F5 / Ctrl+R 刷新，Ctrl + / - / 0 缩放界面（背单词看久了想放大字号时能用）
  win.webContents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return
    const key = input.key
    const ctrl = input.control || input.meta
    const lower = key.length === 1 ? key.toLowerCase() : key

    if (key === 'F12' || (ctrl && input.shift && lower === 'i')) {
      win.webContents.toggleDevTools()
      event.preventDefault()
    } else if (key === 'F5' || (ctrl && lower === 'r')) {
      win.webContents.reload()
      event.preventDefault()
    } else if (ctrl && (key === '=' || key === '+')) {
      win.webContents.setZoomLevel(Math.min(win.webContents.getZoomLevel() + 0.5, 4))
      event.preventDefault()
    } else if (ctrl && key === '-') {
      win.webContents.setZoomLevel(Math.max(win.webContents.getZoomLevel() - 0.5, -3))
      event.preventDefault()
    } else if (ctrl && key === '0') {
      win.webContents.setZoomLevel(0)
      event.preventDefault()
    }
  })

  win.loadURL(`${APP_ORIGIN}/`)
  return win
}

app.whenReady().then(() => {
  // 无菜单栏，界面更干净（原默认菜单里的功能都由上面的快捷键接管）
  Menu.setApplicationMenu(null)

  if (!fs.existsSync(path.join(DIST_DIR, 'index.html'))) {
    dialog.showErrorBox(
      '蛙课堂背单词启动失败',
      `找不到前端产物：\n${path.join(DIST_DIR, 'index.html')}\n\n请先在项目目录执行 pnpm build，再重新打包。`,
    )
    app.quit()
    return
  }

  protocol.handle(APP_SCHEME, handleAppRequest)
  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  app.quit()
})
