import type { Word } from '@/typings'
import shuffle from '@/utils/shuffle'

/**
 * 选词记忆的出题器（纯函数，便于单独验算）。
 *
 * 一个词一道题，题型三种：
 *
 *   en2zh  看英文选中文 —— 题干是单词，四个选项是中文释义
 *   zh2en  看中文选英文 —— 题干是中文释义，四个选项是英文单词
 *   exam   四六级真题句子题（词库里自带，带解析）—— 有就优先用原题
 *
 * en2zh / zh2en 按顺序**交替出现**，一个词只考一个方向，
 * 免得同一轮里全在认英文或全在认中文。
 *
 * 干扰项一律从**同一本词书**里随机抽，并排除「释义前两个字和正确项相同」的词——
 * 否则选项看起来像同义词，题目会变得没法答（评审 B3-4①）。
 */

export type RecallKind = 'en2zh' | 'zh2en' | 'exam'

export type RecallQuestion = {
  word: Word
  kind: RecallKind
  /** 题干 */
  prompt: string
  /** 题干下方的小字（真题用不上，留给提示） */
  hint?: string
  choices: string[]
  answerIndex: number
  explain: string
}

/** 取释义的前两个字，用来判断两个选项是不是"看起来像同义词" */
const head2 = (s: string) => s.slice(0, 2)

/** 从候选里随机抽 n 个，排除与正确项重复、以及释义前两字撞车的 */
function pickDistractors(candidates: Word[], correct: string, take: number, field: 'trans' | 'name'): string[] {
  const seen = new Set<string>([correct])
  const out: string[] = []
  for (const w of shuffle(candidates)) {
    const text = (field === 'trans' ? (w.trans[0] ?? '') : w.name).trim()
    if (!text || seen.has(text)) continue
    // 释义前两字相同的不要：选「取消」时旁边站一个「撤销」，这题就废了
    if (field === 'trans' && head2(text) === head2(correct)) continue
    seen.add(text)
    out.push(text)
    if (out.length >= take) break
  }
  return out
}

/** 找这个词自带的真题选择题（选项数和答案下标都得合法） */
function findExamQuestion(w: Word) {
  return (w.exam ?? []).find((e) => e.choices.length >= 2 && e.answerIndex >= 0 && e.answerIndex < e.choices.length)
}

/**
 * @param words 本轮要考的词（今日新词）
 * @param pool  当前词书的全部单词，用来抽干扰项
 */
export function buildRecallQuestions(words: Word[], pool: Word[]): RecallQuestion[] {
  const out: RecallQuestion[] = []
  let flip = false

  for (const w of words) {
    // 1) 真题优先
    const real = findExamQuestion(w)
    if (real) {
      out.push({
        word: w,
        kind: 'exam',
        prompt: real.question,
        choices: real.choices,
        answerIndex: real.answerIndex,
        explain: real.explain,
      })
      continue
    }

    const zh = (w.trans[0] ?? '').trim()
    if (!zh) continue

    const others = pool.filter((x) => x.name !== w.name)
    const en2zh = !flip

    if (en2zh) {
      const distractors = pickDistractors(others, zh, 3, 'trans')
      if (distractors.length < 3) continue
      const choices = shuffle([zh, ...distractors])
      out.push({
        word: w,
        kind: 'en2zh',
        prompt: w.name,
        choices,
        answerIndex: choices.indexOf(zh),
        explain: '',
      })
    } else {
      const distractors = pickDistractors(others, w.name, 3, 'name')
      if (distractors.length < 3) continue
      const choices = shuffle([w.name, ...distractors])
      out.push({
        word: w,
        kind: 'zh2en',
        prompt: zh,
        choices,
        answerIndex: choices.indexOf(w.name),
        explain: '',
      })
    }

    flip = !flip
  }

  return out
}

export const KIND_LABEL: Record<RecallKind, string> = {
  en2zh: '看英文选中文',
  zh2en: '看中文选英文',
  exam: '真题',
}
