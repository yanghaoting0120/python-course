import { TypingContext, TypingStateActionType } from '../../store'
import type { TypingState } from '../../store/type'
import PrevAndNextWord from '../PrevAndNextWord'
import Phonetic from './components/Phonetic'
import Translation from './components/Translation'
import WordComponent from './components/Word'
import WordDetailPanel from '@/components/WordDetailPanel'
import { usePrefetchPronunciationSound } from '@/hooks/usePronunciation'
import { isReviewModeAtom, isShowPrevAndNextWordAtom, loopWordConfigAtom, phoneticConfigAtom, reviewModeInfoAtom } from '@/store'
import type { Word } from '@/typings'
import { useAtomValue, useSetAtom } from 'jotai'
import { useCallback, useContext, useMemo, useState } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'

export default function WordPanel() {
  // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
  const { state, dispatch } = useContext(TypingContext)!
  const phoneticConfig = useAtomValue(phoneticConfigAtom)
  const isShowPrevAndNextWord = useAtomValue(isShowPrevAndNextWordAtom)
  const [wordComponentKey, setWordComponentKey] = useState(0)
  const [currentWordExerciseCount, setCurrentWordExerciseCount] = useState(0)
  const { times: loopWordTimes } = useAtomValue(loopWordConfigAtom)
  const currentWord = state.chapterData.words[state.chapterData.index]
  const nextWord = state.chapterData.words[state.chapterData.index + 1] as Word | undefined

  const setReviewModeInfo = useSetAtom(reviewModeInfoAtom)
  const isReviewMode = useAtomValue(isReviewModeAtom)

  const prevIndex = useMemo(() => {
    const newIndex = state.chapterData.index - 1
    return newIndex < 0 ? 0 : newIndex
  }, [state.chapterData.index])
  const nextIndex = useMemo(() => {
    const newIndex = state.chapterData.index + 1
    return newIndex > state.chapterData.words.length - 1 ? state.chapterData.words.length - 1 : newIndex
  }, [state.chapterData.index, state.chapterData.words.length])

  usePrefetchPronunciationSound(nextWord?.name)

  const reloadCurrentWordComponent = useCallback(() => {
    setWordComponentKey((old) => old + 1)
  }, [])

  const updateReviewRecord = useCallback(
    (state: TypingState) => {
      setReviewModeInfo((old) => ({
        ...old,
        reviewRecord: old.reviewRecord ? { ...old.reviewRecord, index: state.chapterData.index } : undefined,
      }))
    },
    [setReviewModeInfo],
  )

  const onFinish = useCallback(() => {
    if (state.chapterData.index < state.chapterData.words.length - 1 || currentWordExerciseCount < loopWordTimes - 1) {
      // 用户完成当前单词
      if (currentWordExerciseCount < loopWordTimes - 1) {
        setCurrentWordExerciseCount((old) => old + 1)
        dispatch({ type: TypingStateActionType.LOOP_CURRENT_WORD })
        reloadCurrentWordComponent()
      } else {
        setCurrentWordExerciseCount(0)
        if (isReviewMode) {
          dispatch({
            type: TypingStateActionType.NEXT_WORD,
            payload: {
              updateReviewRecord,
            },
          })
        } else {
          dispatch({ type: TypingStateActionType.NEXT_WORD })
        }
      }
    } else {
      // 用户完成当前章节
      dispatch({ type: TypingStateActionType.FINISH_CHAPTER })
      if (isReviewMode) {
        setReviewModeInfo((old) => ({ ...old, reviewRecord: old.reviewRecord ? { ...old.reviewRecord, isFinished: true } : undefined }))
      }
    }
  }, [
    state.chapterData.index,
    state.chapterData.words.length,
    currentWordExerciseCount,
    loopWordTimes,
    dispatch,
    reloadCurrentWordComponent,
    isReviewMode,
    updateReviewRecord,
    setReviewModeInfo,
  ])

  const onSkipWord = useCallback(
    (type: 'prev' | 'next') => {
      if (type === 'prev') {
        dispatch({ type: TypingStateActionType.SKIP_2_WORD_INDEX, newIndex: prevIndex })
      }

      if (type === 'next') {
        dispatch({ type: TypingStateActionType.SKIP_2_WORD_INDEX, newIndex: nextIndex })
      }
    },
    [dispatch, prevIndex, nextIndex],
  )

  useHotkeys(
    'Ctrl + Shift + ArrowLeft',
    (e) => {
      e.preventDefault()
      onSkipWord('prev')
    },
    { preventDefault: true },
  )

  useHotkeys(
    'Ctrl + Shift + ArrowRight',
    (e) => {
      e.preventDefault()
      onSkipWord('next')
    },
    { preventDefault: true },
  )
  const [isShowTranslation, setIsHoveringTranslation] = useState(false)

  const handleShowTranslation = useCallback((checked: boolean) => {
    setIsHoveringTranslation(checked)
  }, [])

  useHotkeys(
    'tab',
    () => {
      handleShowTranslation(true)
    },
    { enableOnFormTags: true, preventDefault: true },
    [],
  )

  useHotkeys(
    'tab',
    () => {
      handleShowTranslation(false)
    },
    { enableOnFormTags: true, keyup: true, preventDefault: true },
    [],
  )

  const shouldShowTranslation = useMemo(() => {
    return isShowTranslation || state.isTransVisible
  }, [isShowTranslation, state.isTransVisible])

  return (
    // 不要用 Tailwind 的 container：它按断点取 max-width，比外层 container-app 窄，
    // 会把内容再缩一道，导致词卡左边缘和页头 logo 对不齐。
    <div className="grid min-h-0 w-full flex-1 grid-cols-1 gap-3.5 pb-1 md:grid-cols-[minmax(0,1fr)_19rem]">
      {/* ── 左列：进度 → 上下词预览 → 词卡 ──
          第 2 批把「第 N / M 个词」从卡片角落里的一行灰小字，提成卡片上方
          带进度条的一行；上下词预览也收进左列，不再横跨整屏飘在助记栏上方。 */}
      {currentWord && (
        <div className="flex min-h-0 flex-col gap-3">
          <div className="flex shrink-0 items-center gap-3">
            <span className="c-ink-soft t-sm font-bold tabular-nums">
              第 {state.chapterData.index + 1} / {state.chapterData.words.length} 个词
            </span>
            <div className="progress-track progress-sm min-w-0 flex-1">
              <div
                className="progress-fill"
                style={{ width: `${Math.round((state.chapterData.index / Math.max(1, state.chapterData.words.length)) * 100)}%` }}
              />
            </div>
          </div>

          {/* 上一个 / 下一个词预览。
              ⚠️ 原来这里写死 h-12（48px），但预览是「单词(24px) + 释义(20px)」两行、约 58px，
              溢出的部分正好被助记栏的玻璃背景盖住 —— 表现就是下一个词的释义被切掉一半。
              改成自适应高度，内容完整撑开。 */}
          {isShowPrevAndNextWord && state.isTyping && (
            <div className="flex shrink-0 items-start justify-between">
              <PrevAndNextWord type="prev" />
              <PrevAndNextWord type="next" />
            </div>
          )}

          <div className="glass-strong relative flex min-h-[15rem] flex-1 flex-col items-center justify-center rounded-2xl px-8 py-6">
            <div className="relative flex w-full justify-center">
              <div className="relative">
                <WordComponent word={currentWord} onFinish={onFinish} key={wordComponentKey} />
                {phoneticConfig.isOpen && <Phonetic word={currentWord} />}
                <Translation
                  trans={currentWord.trans.join('；')}
                  showTrans={shouldShowTranslation}
                  onMouseEnter={() => handleShowTranslation(true)}
                  onMouseLeave={() => handleShowTranslation(false)}
                />
              </div>
            </div>

            {/* B2-7：原来遮罩是 bg-white/55 + 18.4px/800 字重的提示，比单词本身还抢眼，
                而且遮住了用户"先看这个词"的权利。现在遮罩降到 35%，
                提示改成底部一枚小胶囊，不挡单词。 */}
            {!state.isTyping && (
              <div className="absolute inset-0 z-10 flex items-end justify-center rounded-2xl bg-white/35 pb-7 dark:bg-gray-900/40">
                <span className="badge badge-brand animate-pulse px-3 py-1">按任意键{state.timerData.time ? '继续' : '开始'}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── 右列：助记（与左列顶部对齐、等高）── */}
      {currentWord && (
        <div className="min-h-0 max-h-[22rem] md:max-h-none">
          {/* 换词时用 key 强制重挂载，避免上一词的滚动位置串到下一词 */}
          <WordDetailPanel key={currentWord.name} word={currentWord} />
        </div>
      )}
    </div>
  )
}
