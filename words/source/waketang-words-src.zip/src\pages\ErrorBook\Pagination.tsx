import type { FC } from 'react'
import { useCallback } from 'react'
import NextIcon from '~icons/ooui/next-ltr'
import PrevIcon from '~icons/ooui/next-rtl'

type IPaginationProps = {
  className?: string
  page: number
  setPage: (page: number) => void
  totalPages: number
}

export const ITEM_PER_PAGE = 20

/**
 * 分页控件。
 *
 * 评审 B6-1b：原来翻页按钮**没有 disabled 态** —— 在第 1 页还能点"上一页"、
 * 在最后一页还能点"下一页"；而且没有数据时会显示 `1 / 0` 这种不合法状态。
 * 现在：首/末页禁用对应按钮，总页数下限为 1。
 */
const Pagination: FC<IPaginationProps> = ({ className, page, setPage, totalPages }) => {
  const safeTotal = Math.max(1, totalPages)
  const canPrev = page > 1
  const canNext = page < safeTotal

  const nextPage = useCallback(() => {
    if (canNext) setPage(page + 1)
  }, [canNext, page, setPage])

  const prevPage = useCallback(() => {
    if (canPrev) setPage(page - 1)
  }, [canPrev, page, setPage])

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <button
        type="button"
        className={`btn-secondary btn-sm ${canPrev ? '' : 'cursor-not-allowed opacity-40'}`}
        onClick={prevPage}
        disabled={!canPrev}
        aria-label="上一页"
      >
        <PrevIcon />
      </button>
      <span className="c-soft t-sm tabular-nums">{`${page} / ${safeTotal}`}</span>
      <button
        type="button"
        className={`btn-secondary btn-sm ${canNext ? '' : 'cursor-not-allowed opacity-40'}`}
        onClick={nextPage}
        disabled={!canNext}
        aria-label="下一页"
      >
        <NextIcon />
      </button>
    </div>
  )
}

export default Pagination
