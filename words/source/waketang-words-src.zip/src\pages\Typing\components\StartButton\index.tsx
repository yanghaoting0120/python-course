import { TypingContext, TypingStateActionType } from '../../store'
import { randomConfigAtom } from '@/store'
import { autoUpdate, offset, useFloating, useHover, useInteractions } from '@floating-ui/react'
import { useAtomValue } from 'jotai'
import { useCallback, useContext, useState } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'

/**
 * 工具栏上的「开始 / 暂停」主按钮。
 *
 * 2026-10-06 改：原来鼠标停上去会**同时**冒出两样东西 ——
 *   上面一个「开始（Enter）」提示框（而且被窗口顶边切掉，看不见字），
 *   下面一个「重新开始」按钮（还盖住右边助记栏的顶部）。
 * 现在合成**一个悬停面板**：上面一行快捷键提示，下面一个「重新开始」按钮。
 * 面板用 glass-strong + 阴影，盖住内容时看起来是"浮在上面的一层"，而不是零散的两块。
 */
export default function StartButton({ isLoading }: { isLoading: boolean }) {
  // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
  const { state, dispatch } = useContext(TypingContext)!
  const randomConfig = useAtomValue(randomConfigAtom)

  const onToggleIsTyping = useCallback(() => {
    !isLoading && dispatch({ type: TypingStateActionType.TOGGLE_IS_TYPING })
  }, [isLoading, dispatch])

  const onClickRestart = useCallback(() => {
    dispatch({ type: TypingStateActionType.REPEAT_CHAPTER, shouldShuffle: randomConfig.isOpen })
  }, [dispatch, randomConfig.isOpen])

  useHotkeys('enter', onToggleIsTyping, { enableOnFormTags: true, preventDefault: true }, [onToggleIsTyping])

  const [isShowPanel, setIsShowPanel] = useState(false)
  const { refs, context } = useFloating({
    open: isShowPanel,
    onOpenChange: setIsShowPanel,
    whileElementsMounted: autoUpdate,
    middleware: [offset(6)],
  })
  const hoverButton = useHover(context)
  const { getReferenceProps, getFloatingProps } = useInteractions([hoverButton])

  const label = state.isTyping ? '暂停' : '开始'

  return (
    <div ref={refs.setReference} {...getReferenceProps()} className="relative">
      <button
        className={`${state.isTyping ? 'btn-secondary' : 'my-btn-primary'} btn-sm whitespace-nowrap`}
        type="button"
        onClick={onToggleIsTyping}
        aria-label={label}
      >
        {label}
      </button>

      {isShowPanel && (
        <div
          className="glass-strong z-40 flex w-max flex-col items-center gap-2 rounded-xl px-3 py-2.5 shadow-xl"
          ref={refs.setFloating}
          style={{ position: 'absolute', left: '50%', top: '100%', transform: 'translateX(-50%)', marginTop: 6 }}
          {...getFloatingProps()}
        >
          <span className="c-faint t-micro whitespace-nowrap">{label}（Enter）</span>
          <button className="btn-secondary btn-sm whitespace-nowrap" type="button" onClick={onClickRestart} aria-label="重新开始">
            重新开始
          </button>
        </div>
      )}
    </div>
  )
}
