import type { PropsWithChildren } from 'react'
import type React from 'react'

/**
 * 全站页头。
 *
 * 2026-10-05 用户要求：去掉左上角的青蛙图标，只留「蛙课堂 · 背单词」文字。
 * 窗口标题栏本来就写着应用名，页面里再摆一个大图标确实重复。
 * （assets/logo.png 仍然保留，只是不再在这里引用。）
 */
const Header: React.FC<PropsWithChildren> = ({ children }) => {
  return (
    <header className="container-app z-20 py-3.5">
      {/* 断点用 md 而不是 lg：本机有 DPI 缩放，浏览器 CSS 视口不到 1024，
          用 lg 会一直是「品牌居中 + 工具换行」的竖排，标题左边缘没法与内容对齐。 */}
      <div className="flex w-full flex-col items-center justify-between space-y-2 md:flex-row md:space-y-0">
        <h1 className="c-brand t-h2">蛙课堂 · 背单词</h1>
        {/* 不再给按钮套一层玻璃盒子：按钮本身已经有描边和厚度，
            外面再包一层边框会显得脏。按钮就让它独立站着。 */}
        <nav className="flex w-auto content-center items-center justify-end gap-2">{children}</nav>
      </div>
    </header>
  )
}

export default Header
