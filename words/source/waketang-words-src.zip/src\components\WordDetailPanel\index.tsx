import WordDetailBody from '@/components/WordDetailBody'
import { WordPronunciationIcon } from '@/components/WordPronunciationIcon'
import type { Word } from '@/typings'

/**
 * 右侧常驻的「助记 / 答案」栏。
 *
 * 打字页和选词记忆页共用同一个外壳，区别只在内容：
 *   · 打字页        —— 只显示助记（词根词缀 / 同根词 / 例句）
 *   · 选词记忆·词卡 —— 只显示助记
 *   · 选词记忆·答题 —— 顶部多一块「单词 + 音标 + 发音 + 释义」（showWordHead），
 *                      相当于把答案连同语料一起摆在右边，左边专心做题
 *
 * 面板本身 `overflow-y-auto`：内容长了在**面板内部**滚，整页不动。
 */

export default function WordDetailPanel({
  word,
  lang = 'en',
  title = '助记',
  placeholder,
  showWordHead = false,
  notice,
}: {
  /** 不传表示暂无内容，显示 placeholder */
  word?: Word
  lang?: string
  title?: string
  /** 没有内容时的一句话 */
  placeholder?: string
  /** 是否在顶部显示「单词 + 音标 + 发音 + 释义」 */
  showWordHead?: boolean
  /** 正文最上面的一条提示（例如真题的解析），跟内容一起滚 */
  notice?: React.ReactNode
}) {
  return (
    <aside className="glass flex h-full min-h-0 flex-col overflow-hidden rounded-2xl">
      <header className="flex shrink-0 items-baseline justify-between gap-2 border-b border-[color:var(--c-line-soft)] px-4 py-2.5">
        <h3 className="c-ink t-sm font-bold">{title}</h3>
        {word ? <span className="c-faint t-micro truncate">{word.name}</span> : null}
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3.5">
        {!word ? (
          <p className="c-muted t-sm leading-relaxed">{placeholder ?? '暂无语料 · 先记住它'}</p>
        ) : (
          <div className="space-y-3">
            {notice ? <div className="alert alert-info">{notice}</div> : null}
            {showWordHead ? (
              <div className="border-b border-[color:var(--c-line-soft)] pb-3">
                <div className="flex items-center gap-2">
                  <span className="c-ink text-2xl font-extrabold leading-none tracking-tight">{word.name}</span>
                  <WordPronunciationIcon word={word} lang={lang} className="h-5 w-5" />
                </div>
                {word.usphone ? <p className="c-muted t-micro mt-1.5">AmE: [{word.usphone}]</p> : null}
                <div className="mt-2 space-y-0.5">
                  {word.trans.map((t, i) => (
                    <p key={i} className="c-ink-soft t-sm leading-snug">
                      {t}
                    </p>
                  ))}
                </div>
              </div>
            ) : null}

            <WordDetailBody word={word} />
          </div>
        )}
      </div>
    </aside>
  )
}
