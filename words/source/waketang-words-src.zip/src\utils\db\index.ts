import type { IChapterRecord, IMemoryRecord, IReviewRecord, IRevisionDictRecord, IWordRecord, LetterMistakes } from './record'
import { ChapterRecord, MemoryRecord, ReviewRecord, WordRecord } from './record'
import { TypingContext, TypingStateActionType } from '@/pages/Typing/store'
import type { TypingState } from '@/pages/Typing/store/type'
import { currentChapterAtom, currentDictIdAtom, isReviewModeAtom } from '@/store'
import { applyAnswer, initialMemory, shouldAdvanceToday, todayStr } from '@/utils/srs'
import type { Table } from 'dexie'
import Dexie from 'dexie'
import { useLiveQuery } from 'dexie-react-hooks'
import { useAtomValue } from 'jotai'
import { useCallback, useContext } from 'react'

class RecordDB extends Dexie {
  wordRecords!: Table<IWordRecord, number>
  chapterRecords!: Table<IChapterRecord, number>
  reviewRecords!: Table<IReviewRecord, number>

  // 蛙课堂背单词新增：每个词的艾宾浩斯记忆状态
  memoryRecords!: Table<IMemoryRecord, number>

  revisionDictRecords!: Table<IRevisionDictRecord, number>
  revisionWordRecords!: Table<IWordRecord, number>

  constructor() {
    super('RecordDB')
    this.version(1).stores({
      wordRecords: '++id,word,timeStamp,dict,chapter,errorCount,[dict+chapter]',
      chapterRecords: '++id,timeStamp,dict,chapter,time,[dict+chapter]',
    })
    this.version(2).stores({
      wordRecords: '++id,word,timeStamp,dict,chapter,wrongCount,[dict+chapter]',
      chapterRecords: '++id,timeStamp,dict,chapter,time,[dict+chapter]',
    })
    this.version(3).stores({
      wordRecords: '++id,word,timeStamp,dict,chapter,wrongCount,[dict+chapter]',
      chapterRecords: '++id,timeStamp,dict,chapter,time,[dict+chapter]',
      reviewRecords: '++id,dict,createTime,isFinished',
    })
    // v4：艾宾浩斯记忆状态表。&[dict+word] 是唯一复合索引，
    //     保证「同一本词书里的同一个词」只有一条记录。
    this.version(4).stores({
      wordRecords: '++id,word,timeStamp,dict,chapter,wrongCount,[dict+chapter]',
      chapterRecords: '++id,timeStamp,dict,chapter,time,[dict+chapter]',
      reviewRecords: '++id,dict,createTime,isFinished',
      memoryRecords: '++id,&[dict+word],dict,word,dueDate,stage,mastered',
    })
    // v5：「先认后拼」门禁要的两列（recalledDate / typedDate）。
    //     两列都不建索引（查询一律先按 dict 取出来再在内存里筛），所以 stores 与 v4 相同。
    //     老数据是门禁规则之前学的，按用户定的「以前认过就算」全部放行 ——
    //     把 recalledDate 回填成 firstLearnDate，而不是留空让它们被打回去重认。
    this.version(5)
      .stores({
        wordRecords: '++id,word,timeStamp,dict,chapter,wrongCount,[dict+chapter]',
        chapterRecords: '++id,timeStamp,dict,chapter,time,[dict+chapter]',
        reviewRecords: '++id,dict,createTime,isFinished',
        memoryRecords: '++id,&[dict+word],dict,word,dueDate,stage,mastered',
      })
      .upgrade((tx) =>
        tx
          .table('memoryRecords')
          .toCollection()
          .modify((r: IMemoryRecord) => {
            if (r.recalledDate === undefined) r.recalledDate = r.firstLearnDate || ''
            if (r.typedDate === undefined) r.typedDate = ''
          }),
      )
  }
}

export const db = new RecordDB()

db.wordRecords.mapToClass(WordRecord)
db.chapterRecords.mapToClass(ChapterRecord)
db.reviewRecords.mapToClass(ReviewRecord)
db.memoryRecords.mapToClass(MemoryRecord)

export function useSaveChapterRecord() {
  const currentChapter = useAtomValue(currentChapterAtom)
  const isRevision = useAtomValue(isReviewModeAtom)
  const dictID = useAtomValue(currentDictIdAtom)

  const saveChapterRecord = useCallback(
    (typingState: TypingState) => {
      const {
        chapterData: { correctCount, wrongCount, userInputLogs, wordCount, words, wordRecordIds },
        timerData: { time },
      } = typingState
      const correctWordIndexes = userInputLogs.filter((log) => log.correctCount > 0 && log.wrongCount === 0).map((log) => log.index)

      const chapterRecord = new ChapterRecord(
        dictID,
        isRevision ? -1 : currentChapter,
        time,
        correctCount,
        wrongCount,
        wordCount,
        correctWordIndexes,
        words.length,
        wordRecordIds ?? [],
      )
      db.chapterRecords.add(chapterRecord)
    },
    [currentChapter, dictID, isRevision],
  )

  return saveChapterRecord
}

export type WordKeyLogger = {
  letterTimeArray: number[]
  letterMistake: LetterMistakes
}

export function useSaveWordRecord() {
  const isRevision = useAtomValue(isReviewModeAtom)
  const currentChapter = useAtomValue(currentChapterAtom)
  const dictID = useAtomValue(currentDictIdAtom)

  const { dispatch } = useContext(TypingContext) ?? {}

  const saveWordRecord = useCallback(
    async ({
      word,
      wrongCount,
      letterTimeArray,
      letterMistake,
    }: {
      word: string
      wrongCount: number
      letterTimeArray: number[]
      letterMistake: LetterMistakes
    }) => {
      const timing = []
      for (let i = 1; i < letterTimeArray.length; i++) {
        const diff = letterTimeArray[i] - letterTimeArray[i - 1]
        timing.push(diff)
      }

      const wordRecord = new WordRecord(word, dictID, isRevision ? -1 : currentChapter, timing, wrongCount, letterMistake)

      let dbID = -1
      try {
        dbID = await db.wordRecords.add(wordRecord)
      } catch (e) {
        console.error(e)
      }
      if (dispatch) {
        dbID > 0 && dispatch({ type: TypingStateActionType.ADD_WORD_RECORD_ID, payload: dbID })
        dispatch({ type: TypingStateActionType.SET_IS_SAVING_RECORD, payload: false })
      }
    },
    [currentChapter, dictID, dispatch, isRevision],
  )

  return saveWordRecord
}

export function useDeleteWordRecord() {
  const deleteWordRecord = useCallback(async (word: string, dict: string) => {
    try {
      const deletedCount = await db.wordRecords.where({ word, dict }).delete()
      return deletedCount
    } catch (error) {
      console.error(`删除单词记录时出错：`, error)
    }
  }, [])

  return { deleteWordRecord }
}

// ─────────────────────────────────────────────────────────────
//  蛙课堂背单词：艾宾浩斯记忆状态读写
// ─────────────────────────────────────────────────────────────

/**
 * 读取某本词书的全部记忆状态。
 * 用 useLiveQuery，所以任何写入都会自动触发界面刷新。
 */
export function useMemoryRecords(dict: string): MemoryRecord[] {
  return useLiveQuery(() => db.memoryRecords.where('dict').equals(dict).toArray(), [dict], [] as MemoryRecord[])
}

/**
 * 记录一次作答，推进该词的艾宾浩斯阶段。
 *
 * 同一天同一个词只推进一次（方案 A）：
 * 「选词记忆」和「拼写练习」是并列的两条路，同一天可能都答对同一个词。
 * 两次都推进的话，这个词一天跳两档，1/2/4/7/15 的节奏就乱了。
 * 所以当天已经记过、这次又答对时直接返回；答错永远照常惩罚。
 *
 * @param dict     词书 id
 * @param word     单词原文
 * @param correct  本次是否答对（打错任何一个字母即算答错）
 * @param opts.source   'recall' = 选词记忆；'typing' = 拼写练习。
 *                      决定写 recalledDate 还是 typedDate —— 「先认后拼」门禁靠这两列判定。
 * @param opts.stubborn 是否手动标记为「不认识」，会永久留在生词本
 */
export async function recordWordAnswer(
  dict: string,
  word: string,
  correct: boolean,
  opts: { source?: 'recall' | 'typing'; stubborn?: boolean } = {},
): Promise<void> {
  const { source, stubborn = false } = opts
  const today = todayStr()
  try {
    const existing = await db.memoryRecords.where('[dict+word]').equals([dict, word]).first()

    // 本次作答要写进哪一列（门禁钥匙）：
    //   选词记忆**答对** → 通过门禁，写 recalledDate
    //   拼写作答         → 写 typedDate（用来判断「今天认了但还没拼」）
    const recalledDate = source === 'recall' && correct ? today : undefined
    const typedDate = source === 'typing' ? today : undefined

    if (!existing) {
      // 第一次见到这个词：初始化成 stage 0，次日首次复习
      const init = initialMemory(today)
      await db.memoryRecords.add(
        new MemoryRecord(
          dict,
          word,
          init.stage,
          init.mastered,
          init.dueDate ?? '',
          today,
          today,
          correct ? 1 : 0,
          correct ? 0 : 1,
          stubborn || !correct,
          // ⚠️ 选词记忆答错时这里写 ''（不是 undefined）——
          //    空串 = 「明确没通过」，undefined = 门禁上线前的老数据（视为已通过）。
          recalledDate ?? '',
          typedDate ?? '',
        ),
      )
      return
    }

    // 当天已经记过一次、这次又答对 → 不重复推进档位。
    // 但门禁钥匙仍然要写：同一个词完全可能今天先拼写、再去做选词记忆。
    if (!shouldAdvanceToday(existing.lastReviewDate, correct, today)) {
      const patch: Partial<IMemoryRecord> = {}
      if (stubborn && !existing.stubborn) patch.stubborn = true
      if (recalledDate && existing.recalledDate !== recalledDate) patch.recalledDate = recalledDate
      if (typedDate && existing.typedDate !== typedDate) patch.typedDate = typedDate
      if (Object.keys(patch).length > 0) {
        await db.memoryRecords.update(existing.id as number, patch)
      }
      return
    }

    const result = applyAnswer(existing.stage, correct, today)
    await db.memoryRecords.update(existing.id as number, {
      stage: result.stage,
      mastered: result.mastered,
      dueDate: result.dueDate ?? '',
      lastReviewDate: today,
      correct: existing.correct + (correct ? 1 : 0),
      wrong: existing.wrong + (correct ? 0 : 1),
      stubborn: existing.stubborn || stubborn || !correct,
      ...(recalledDate ? { recalledDate } : {}),
      ...(typedDate ? { typedDate } : {}),
    })
  } catch (error) {
    console.error('记录记忆状态时出错：', error)
  }
}

/** 把某个词移出生词本（stage 和复习计划保持不变） */
export async function clearWordStubborn(dict: string, word: string): Promise<void> {
  try {
    const existing = await db.memoryRecords.where('[dict+word]').equals([dict, word]).first()
    if (existing) {
      await db.memoryRecords.update(existing.id as number, { stubborn: false })
    }
  } catch (error) {
    console.error('更新生词本状态时出错：', error)
  }
}

/**
 * 把某个词加入生词本（不影响 stage 和复习计划）。
 * 选择题测试答错时用它，避免和打字阶段的阶段推进重复计算。
 */
export async function markWordStubborn(dict: string, word: string): Promise<void> {
  try {
    const existing = await db.memoryRecords.where('[dict+word]').equals([dict, word]).first()
    if (existing) {
      if (!existing.stubborn) {
        await db.memoryRecords.update(existing.id as number, { stubborn: true })
      }
      return
    }
    // 还没有记忆记录的词（没在打字阶段出现过），补一条初始记录
    const today = todayStr()
    const init = initialMemory(today)
    await db.memoryRecords.add(
      new MemoryRecord(dict, word, init.stage, init.mastered, init.dueDate ?? '', today, today, 0, 1, true),
    )
  } catch (error) {
    console.error('标记生词本时出错：', error)
  }
}

/** 清空某本词书的全部记忆状态（慎用） */
export async function resetMemoryRecords(dict: string): Promise<number> {
  return db.memoryRecords.where('dict').equals(dict).delete()
}
