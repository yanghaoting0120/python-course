import type { Word } from '@/typings'

/**
 * 单词的「助记」内容 —— 词根词缀 / 同根词 / 近义词 / 例句 / 真题例句。
 *
 * 从打字页右侧的 WordDetailPanel 里抽出来，让**打字页**和**选词记忆页**共用同一份渲染，
 * 免得两处各写一遍、改一处忘一处。
 *
 * 数据来自四六级富词库（kajweb 那份，经 tools/build-app-dicts.mjs 转换）：
 *   etymology     词源或助记法原文
 *   relWords      同根词（按词性分组）
 *   synos         近义词
 *   sentences     普通例句
 *   examSentences 真题例句（带年份、题型）
 *
 * 覆盖率不是 100%（CET-4 约 68%、CET-6 约 78% 的词有词源），
 * 毫无内容的词显示一句占位说明，不留空白。
 */

function Section({ title, children, last }: { title: string; children: React.ReactNode; last?: boolean }) {
  return (
    <section className={last ? '' : 'border-b border-[color:var(--c-line-soft)] pb-3'}>
      <h4 className="c-muted t-micro mb-1.5 tracking-wide">{title}</h4>
      <div className="c-soft t-sm leading-relaxed">{children}</div>
    </section>
  )
}

export default function WordDetailBody({ word, maxSentences = 3 }: { word: Word; maxSentences?: number }) {
  const etymology = (word.etymology ?? '').trim()
  const relWords = (word.relWords ?? []).flatMap((g) => g.words.map((w) => ({ pos: g.pos, ...w })))
  const synos = (word.synos ?? []).flatMap((g) => g.words.map((w) => ({ w })))
  const sentences = word.sentences ?? []
  const examSentences = word.examSentences ?? []

  const isEmpty = !etymology && relWords.length === 0 && synos.length === 0 && sentences.length === 0 && examSentences.length === 0

  return (
    <div className="space-y-3">
      {isEmpty ? <p className="c-muted t-sm leading-relaxed">暂无语料 · 先记住它</p> : null}

      {/* 词根词缀是这里最有价值的信息 —— 做成高亮块（浅绿底 + 左侧品牌绿竖条），
          而不是和「近义词」长得一模一样（评审 B2-6）。 */}
      {etymology ? (
        <section className="relative rounded-xl py-2.5 pl-3.5 pr-3" style={{ backgroundColor: 'var(--c-brand-soft)' }}>
          <span className="absolute bottom-2.5 left-0 top-2.5 w-[3px] rounded-full bg-[color:var(--c-brand)]" />
          <h4 className="c-brand t-micro mb-1.5 tracking-wide">词根词缀 / 助记</h4>
          <p className="c-ink-soft t-sm whitespace-pre-wrap leading-relaxed">{etymology}</p>
        </section>
      ) : null}

      {relWords.length > 0 ? (
        <Section title="同根词" last={synos.length === 0 && sentences.length === 0 && examSentences.length === 0}>
          <div className="flex flex-wrap gap-x-3 gap-y-1">
            {relWords.map((w, i) => (
              <span key={`${w.w}-${i}`} className="whitespace-nowrap">
                {w.pos ? <span className="c-faint t-micro mr-1 italic">{w.pos}.</span> : null}
                <span className="c-ink font-semibold">{w.w}</span>
                {w.cn ? <span className="c-muted t-micro ml-1">{w.cn}</span> : null}
              </span>
            ))}
          </div>
        </Section>
      ) : null}

      {synos.length > 0 ? (
        <Section title="近义词" last={sentences.length === 0 && examSentences.length === 0}>
          <div className="flex flex-wrap gap-x-3 gap-y-1">
            {synos.slice(0, 10).map((s, i) => (
              <span key={`${s.w}-${i}`} className="c-ink whitespace-nowrap font-semibold">
                {s.w}
              </span>
            ))}
          </div>
        </Section>
      ) : null}

      {sentences.length > 0 ? (
        <Section title="例句" last={examSentences.length === 0}>
          <ul className="space-y-2">
            {sentences.slice(0, maxSentences).map((s, i) => (
              <li key={i}>
                <p className="c-soft">{s.en}</p>
                {/* 中文翻译原来用 c-faint（#afafaf 仅 2.19:1，读不清），提到 c-muted */}
                {s.cn ? <p className="c-muted t-sm">{s.cn}</p> : null}
              </li>
            ))}
          </ul>
        </Section>
      ) : null}

      {examSentences.length > 0 ? (
        <Section title="真题例句" last>
          <ul className="space-y-2">
            {examSentences.slice(0, maxSentences).map((s, i) => (
              <li key={i}>
                <p className="c-soft">{s.en}</p>
                {/* 年份/题型原来是纯灰小字，信息被浪费 —— 改成徽章 */}
                {s.year || s.type ? (
                  <span className="badge badge-neutral mt-1">
                    {s.year} {s.type}
                  </span>
                ) : null}
              </li>
            ))}
          </ul>
        </Section>
      ) : null}
    </div>
  )
}
