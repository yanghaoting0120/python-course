import DictDetail from './DictDetail'
import { useDictStats } from './hooks/useDictStats'
import bookCover from '@/assets/book-cover.png'
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import useIntersectionObserver from '@/hooks/useIntersectionObserver'
import { currentDictIdAtom } from '@/store'
import type { Dictionary } from '@/typings'
import { calcChapterCount } from '@/utils'
import * as Progress from '@radix-ui/react-progress'
import { useAtomValue } from 'jotai'
import { useMemo, useRef } from 'react'

interface Props {
  dictionary: Dictionary
}

export default function DictionaryComponent({ dictionary }: Props) {
  const currentDictID = useAtomValue(currentDictIdAtom)

  const divRef = useRef<HTMLDivElement>(null)
  const entry = useIntersectionObserver(divRef, {})
  const isVisible = !!entry?.isIntersecting
  const dictStats = useDictStats(dictionary.id, isVisible)
  const chapterCount = useMemo(() => calcChapterCount(dictionary.length), [dictionary.length])
  const isSelected = currentDictID === dictionary.id
  const progress = useMemo(
    () => (dictStats ? Math.ceil((dictStats.exercisedChapterCount / chapterCount) * 100) : 0),
    [dictStats, chapterCount],
  )

  return (
    <Dialog>
      <DialogTrigger asChild>
        <div
          ref={divRef}
          className={`glass glass-interactive group relative flex h-36 w-80 cursor-pointer items-center justify-center overflow-hidden rounded-2xl p-4 text-left focus:outline-none ${
            isSelected ? 'border-2 !border-[color:var(--c-brand)] bg-[color:var(--c-brand-soft)]' : ''
          }`}
          role="button"
          // onClick={onClick}
        >
          <div className="relative ml-1 mt-2 flex h-full w-full flex-col items-start justify-start">
            {/* 选中态不再把文字刷白 —— 亮绿底 + 白字只有 2.09:1，「选中反而更难读」，
                视觉层级被反转。改成浅绿底 + 绿描边 + 右上角绿勾，文字保持深色。 */}
            <h1 className="mb-1.5 text-xl font-semibold c-ink group-hover:text-[color:var(--c-brand-text)] dark:text-gray-200">
              {dictionary.name}
            </h1>
            <TooltipProvider>
              <Tooltip delayDuration={400}>
                <TooltipTrigger asChild>
                  {/* 顺手修掉类名笔误：textdelayDuration-gray-600（原文多了 textdelayDuration-） */}
                  <p className="mb-1 max-w-full truncate whitespace-nowrap c-soft">
                    {dictionary.description}
                  </p>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{`${dictionary.description}`}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <p className="mb-0.5 font-bold c-soft">{dictionary.length} 词</p>
            <div className="flex w-full items-center gap-2 pt-2">
              {/* B4-6：进度条常驻（0% 也画出来）并带百分比 ——
                  原来只有 progress > 0 才显示，没学过的书完全看不出"学到哪了" */}
              <div className="progress-track progress-sm flex-1">
                <div className="progress-fill" style={{ width: `${progress}%` }} />
              </div>
              <span className="c-faint t-micro w-7 text-right tabular-nums">{progress}%</span>
              <img src={bookCover} className="absolute bottom-3 right-3 w-14 opacity-20" />
              {isSelected && (
                <span className="absolute right-3 top-3 z-10 flex h-6 w-6 items-center justify-center rounded-full bg-[color:var(--c-brand)] text-sm font-bold text-white shadow-sm">
                  ✓
                </span>
              )}
            </div>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="w-[60rem] max-w-none !rounded-[20px]">
        <DictDetail dictionary={dictionary} />
      </DialogContent>
    </Dialog>
  )
}
