import React from 'react'

const InfoBox: React.FC<InfoBoxProps> = ({ info, description }) => {
  return (
    <div className="flex flex-1 flex-col items-center justify-center">
      <span className="c-ink w-4/5 border-b border-[color:var(--c-line)] pb-1.5 text-center text-lg font-bold tabular-nums">
        {info}
      </span>
      <span className="c-muted t-micro pt-1.5">{description}</span>
    </div>
  )
}

export default React.memo(InfoBox)

export type InfoBoxProps = {
  info: string
  description: string
}
