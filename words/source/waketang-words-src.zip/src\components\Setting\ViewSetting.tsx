import { Section, SliderRow } from './parts'
import { defaultFontSizeConfig } from '@/constants'
import { fontSizeConfigAtom } from '@/store'
import { useAtom } from 'jotai'
import { useCallback } from 'react'

/** 显示设置 —— 字号。排版已改走全站统一的 Section/SliderRow。 */
export default function ViewSetting() {
  const [fontSizeConfig, setFontsizeConfig] = useAtom(fontSizeConfigAtom)

  const onResetFontSize = useCallback(() => {
    setFontsizeConfig({ ...defaultFontSizeConfig })
  }, [setFontsizeConfig])

  return (
    <>
      <Section title="字体大小" hint="只影响打字页的单词与释义；整个界面的缩放可以用 Ctrl + / − / 0。">
        <SliderRow
          label="外语字体"
          value={fontSizeConfig.foreignFont}
          min={20}
          max={96}
          step={4}
          onChange={(v) => setFontsizeConfig((p) => ({ ...p, foreignFont: v }))}
          display={`${fontSizeConfig.foreignFont}px`}
        />
        <SliderRow
          label="中文字体"
          value={fontSizeConfig.translateFont}
          min={14}
          max={60}
          step={4}
          onChange={(v) => setFontsizeConfig((p) => ({ ...p, translateFont: v }))}
          display={`${fontSizeConfig.translateFont}px`}
        />
      </Section>

      <button className="btn-secondary btn-sm" type="button" onClick={onResetFontSize} title="恢复默认字号">
        恢复默认字号
      </button>
    </>
  )
}
