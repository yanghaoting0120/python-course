import { TypingContext, TypingStateActionType } from '../../store'
import AnalysisButton from '../AnalysisButton'
import ErrorBookButton from '../ErrorBookButton'
import HandPositionIllustration from '../HandPositionIllustration'
import LoopWordSwitcher from '../LoopWordSwitcher'
import SoundSwitcher from '../SoundSwitcher'
import WordDictationSwitcher from '../WordDictationSwitcher'
import { isOpenDarkModeAtom, loopWordConfigAtom, wordDictationConfigAtom } from '@/store'
import { CTRL } from '@/utils'
import { Popover } from '@headlessui/react'
import { useAtom, useAtomValue } from 'jotai'
import { useContext } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import IconChevronDown from '~icons/tabler/chevron-down'
import IconMoon from '~icons/heroicons/moon-solid'
import IconSun from '~icons/heroicons/sun-solid'
import IconLanguage from '~icons/tabler/language'
import IconLanguageOff from '~icons/tabler/language-off'

/**
 * 打字页工具栏的「更多」入口。
 *
 * 原版把 9 个功能全摊成一排无标签图标，全部等权、全靠猜。
 * 这里改成：常用功能留在工具栏，其余收进这个面板，每项带文字标签。
 *
 * 评审 B2-8：面板原来 288px 偏窄，而且**每行没有状态可见性** ——
 * 开关是纯图标，不开面板就不知道当前是开还是关。
 * 现在加宽到 320px，并在每行右侧显示真实状态。
 */

/** 状态小胶囊：让"当前是开还是关"一眼可见（B2-8） */
function StateChip({ on, onText = '开', offText = '关' }: { on: boolean; onText?: string; offText?: string }) {
  return <span className={`badge ${on ? 'badge-brand' : 'badge-neutral'}`}>{on ? onText : offText}</span>
}

/** 设置行：左边文字，右边状态 + 控件 */
function Row({ label, hint, state, control }: { label: string; hint?: string; state?: React.ReactNode; control: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl px-2.5 py-2 transition-colors hover:bg-black/[0.04] dark:hover:bg-white/[0.06]">
      <div className="flex min-w-0 flex-col">
        <span className="c-soft t-sm whitespace-nowrap font-semibold">{label}</span>
        {hint ? <span className="c-faint t-micro whitespace-nowrap">{hint}</span> : null}
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {state}
        {control}
      </div>
    </div>
  )
}

function GroupTitle({ children }: { children: React.ReactNode }) {
  return <div className="c-faint t-micro px-2.5 pb-1 pt-3 tracking-wider">{children}</div>
}

export default function Switcher() {
  const [isOpenDarkMode, setIsOpenDarkMode] = useAtom(isOpenDarkModeAtom)
  const wordDictationConfig = useAtomValue(wordDictationConfigAtom)
  const loopWordConfig = useAtomValue(loopWordConfigAtom)
  const { state, dispatch } = useContext(TypingContext) ?? {}

  const changeTransVisibleState = () => {
    if (dispatch) {
      dispatch({ type: TypingStateActionType.TOGGLE_TRANS_VISIBLE })
    }
  }

  useHotkeys(
    'ctrl+shift+v',
    () => {
      changeTransVisibleState()
    },
    { enableOnFormTags: true, preventDefault: true },
    [],
  )

  const transVisible = Boolean(state?.isTransVisible)
  const loopTimes = loopWordConfig.times
  const loopLabel = loopTimes === Number.MAX_SAFE_INTEGER ? '∞' : `×${loopTimes}`

  return (
    <Popover className="relative">
      <Popover.Button className="btn-secondary btn-sm whitespace-nowrap">
        更多
        <IconChevronDown className="h-4 w-4" />
      </Popover.Button>

      <Popover.Panel className="glass-strong absolute right-0 z-40 mt-2 w-80 rounded-2xl p-2.5 shadow-xl">
        <GroupTitle>学习</GroupTitle>
        <Row label="默写模式" hint={`${CTRL} + V`} state={<StateChip on={wordDictationConfig.isOpen} />} control={<WordDictationSwitcher />} />
        <Row
          label="显示中文释义"
          hint={`${CTRL} + Shift + V`}
          state={<StateChip on={transVisible} />}
          control={
            <button
              className={`btn-ghost btn-sm ${transVisible ? 'c-brand' : ''}`}
              type="button"
              onClick={(e) => {
                changeTransVisibleState()
                e.currentTarget.blur()
              }}
              aria-label={`开关释义显示（${CTRL} + Shift + V）`}
            >
              {transVisible ? <IconLanguage className="icon" /> : <IconLanguageOff className="icon" />}
            </button>
          }
        />
        <Row label="单词循环" state={<StateChip on={loopTimes > 1} onText={loopLabel} offText="×1" />} control={<LoopWordSwitcher />} />

        <GroupTitle>外观与音效</GroupTitle>
        <Row
          label="深色模式"
          state={<StateChip on={isOpenDarkMode} />}
          control={
            <button
              className={`btn-ghost btn-sm ${isOpenDarkMode ? 'c-brand' : ''}`}
              type="button"
              onClick={(e) => {
                setIsOpenDarkMode((old) => !old)
                e.currentTarget.blur()
              }}
              aria-label="开关深色模式"
            >
              {isOpenDarkMode ? <IconMoon className="icon" /> : <IconSun className="icon" />}
            </button>
          }
        />
        <Row label="按键音效" control={<SoundSwitcher />} />
        <Row label="指法图示" control={<HandPositionIllustration />} />

        <GroupTitle>数据</GroupTitle>
        <Row label="错题本" control={<ErrorBookButton />} />
        <Row label="练习统计" control={<AnalysisButton />} />
      </Popover.Panel>
    </Popover>
  )
}
