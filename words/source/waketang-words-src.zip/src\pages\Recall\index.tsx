import Header from '@/components/Header'
import WordDetailPanel from '@/components/WordDetailPanel'
import { WordPronunciationIcon } from '@/components/WordPronunciationIcon'
import type { WordPronunciationIconRef } from '@/components/WordPronunciationIcon'
import { currentDictIdAtom, currentDictInfoAtom, todaySessionAtom } from '@/store'
import type { Word } from '@/typings'
import { recordWordAnswer } from '@/utils/db'
import { planUrl } from '@/utils/dictPlan'
import { useAtomValue, useSetAtom } from 'jotai'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { RefObject } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import useSWR from 'swr'
import { KIND_LABEL, buildRecallQuestions } from './buildQuestions'
import IconCards from '~icons/tabler/cards'

/**
 * 选词记忆 —— 与「拼写练习」并列的一条路。
 *
 * 定位：**今天新词的第一次见面**。所以每个词先给一张词卡（单词 + 释义 + 发音 + 词根词缀）
 * 看一眼，再出一道选择题。不是考试，是认脸。
 *
 * 复习词不进来 —— 那些词已经见过了，直接去拼写页上手打更有效率。
 *
 * 版面是**左右两栏、整页不滚动**（用户明确要求）：
 *   左栏 = 题卡（词卡那一屏就是单词本身，答题那一屏是题干 + 选项）
 *   右栏 = 答案 / 助记。答完立刻在右边给出这个词的完整词卡，
 *          左边只管做题 —— 不用往下滚才能看到答案。
 *
 * 记分规则（方案 A）：答对/答错都写进艾宾浩斯记录，但**同一天同一个词只推进一次**，
 * 所以这里答对之后再去拼写页答对，不会一天跳两档。详见 utils/srs.ts 的 shouldAdvanceToday。
 *
 * 答错的节奏与答对的**故意不一样**：
 *   · 答对 → 900ms 自动进下一词（看久了反而分心）
 *   · 答错 → 不自动跳，等你看完右边的词卡，点「知道了，继续」才走
 */

/** 答对后自动进入下一词的等待时间 */
const DELAY_CORRECT = 900

type Phase = 'card' | 'quiz'

export default function RecallPage() {
  const navigate = useNavigate()
  const dictInfo = useAtomValue(currentDictInfoAtom)
  const dictId = useAtomValue(currentDictIdAtom)
  const session = useAtomValue(todaySessionAtom)
  const setSession = useSetAtom(todaySessionAtom)

  // 干扰项从这里抽：只要 name + trans[0]，用「轻量索引」就够，
  // 不必为了抽干扰项把整本 4366 KB 的词库拖下来（详见 utils/dictPlan.ts）
  const { data: allWords } = useSWR<Word[]>(planUrl(dictInfo.url), (u: string) => fetch(u).then((r) => r.json()))

  // 只取会话里**还没通过选词记忆**的词（canType=false）。
  // ⚠️ 进页面时用 useState 定一次就不再变：
  //    答对时会把会话里这个词的 canType 改成 true（好让「接着去拼写」立刻能拼到它），
  //    如果题目列表直接从会话派生，列表会在答题中途缩水、index 全乱。
  const [queue] = useState(() => (session ? session.words.filter((w) => !w.canType) : []))
  const questions = useMemo(
    () => (allWords && queue.length > 0 ? buildRecallQuestions(queue, allWords) : []),
    [queue, allWords],
  )

  const [index, setIndex] = useState(0)
  const [phase, setPhase] = useState<Phase>('card')
  const [picked, setPicked] = useState<number | null>(null)
  const [correctCount, setCorrectCount] = useState(0)
  const [wrongWords, setWrongWords] = useState<Word[]>([])
  const timerRef = useRef<number | null>(null)
  const pronunciationRef = useRef<WordPronunciationIconRef>(null)

  useEffect(() => {
    return () => {
      if (timerRef.current !== null) window.clearTimeout(timerRef.current)
    }
  }, [])

  const question = questions[index]
  const isDone = questions.length > 0 && index >= questions.length

  const goNext = useCallback(() => {
    setPicked(null)
    setPhase('card')
    setIndex((v) => v + 1)
  }, [])

  const choose = useCallback(
    (choiceIndex: number) => {
      if (picked !== null || !question) return
      setPicked(choiceIndex)

      const isRight = choiceIndex === question.answerIndex
      if (isRight) {
        setCorrectCount((v) => v + 1)
        // 答对 = 通过「先认后拼」门禁。就地更新会话里的 canType，
        // 这样结束页的「接着去拼写」立刻就能拼到刚认过的这批词。
        setSession((s) =>
          s ? { words: s.words.map((w) => (w.name === question.word.name ? { ...w, canType: true } : w)) } : s,
        )
      } else {
        setWrongWords((v) => [...v, question.word])
      }
      // source: 'recall' 决定写 recalledDate（只有答对才写）
      void recordWordAnswer(dictId, question.word.name, isRight, { source: 'recall' })

      if (isRight) {
        timerRef.current = window.setTimeout(goNext, DELAY_CORRECT)
      }
    },
    [picked, question, dictId, goNext, setSession],
  )

  // 键盘：词卡页回车出题；答题页 1/2/3/4 选；答错后回车继续
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (!question) return

      if (phase === 'card') {
        if (e.key === 'Enter') {
          e.preventDefault()
          setPhase('quiz')
        } else if (e.key === ' ') {
          // 空格重放发音；只在词卡页给 —— 答题页给发音等于送答案（尤其「看中文选英文」）
          e.preventDefault()
          pronunciationRef.current?.play()
        }
        return
      }

      if (picked === null) {
        const n = Number(e.key)
        if (Number.isInteger(n) && n >= 1 && n <= question.choices.length) {
          e.preventDefault()
          choose(n - 1)
        }
        return
      }

      // 答错时停在原地等你看完右边
      if (e.key === 'Enter' && picked !== question.answerIndex) {
        e.preventDefault()
        goNext()
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [choose, question, phase, picked, goNext])

  // ── 没有可记的词 ──
  if (!session || (allWords && questions.length === 0)) {
    const noSession = !session
    return (
      <div className="flex h-full w-full flex-col items-center overflow-y-auto">
        <Header>
          <Link className="btn-secondary btn-sm" to="/">
            返回今日
          </Link>
        </Header>
        <div className="glass empty-state mx-auto mt-16 w-full max-w-md rounded-2xl">
          <span className="empty-state-icon">
            <IconCards className="h-7 w-7" />
          </span>
          <p className="empty-state-title">{noSession ? '还没有今天的学习计划' : '今天没有新词要记'}</p>
          <p className="empty-state-desc">
            {noSession ? '先去今日页生成今天的计划，再回来选词记忆。' : '今天的新词已经学完了，或者你开了「只复习」。'}
          </p>
          <Link className="my-btn-primary mt-2" to="/">
            去今日页
          </Link>
        </div>
      </div>
    )
  }

  // ── 全部记完 ──
  if (isDone) {
    const total = questions.length
    const accuracy = total > 0 ? Math.round((correctCount / total) * 100) : 0
    /** 会话里现在可拼写的词（复习词 + 刚刚答对通过门禁的） */
    const typableCount = session ? session.words.filter((w) => w.canType).length : 0
    return (
      <div className="h-full w-full overflow-y-auto">
        <div className="flex min-h-full flex-col items-center">
          <Header>
            <Link className="btn-secondary btn-sm" to="/" onClick={() => setSession(null)}>
              返回今日
            </Link>
          </Header>

          <main className="container-app flex flex-1 flex-col justify-center pb-12">
            <h2 className="c-ink t-h1 text-center">这一轮认完了</h2>
            <p className="c-muted t-sm mt-1 text-center">认得脸还不够，得能默写出来才算记住。</p>

            <div className="mx-auto mt-5 flex w-full max-w-3xl gap-3">
              <div className="glass flex flex-1 flex-col items-center rounded-xl px-4 py-4">
                <span className="text-[1.9rem] font-extrabold tabular-nums text-[color:var(--c-brand-text)]">{correctCount}</span>
                <span className="c-soft t-sm font-semibold">一次选对</span>
              </div>
              <div className="glass flex flex-1 flex-col items-center rounded-xl px-4 py-4">
                <span className="text-[1.9rem] font-extrabold tabular-nums text-[color:var(--c-danger-text)]">
                  {total - correctCount}
                </span>
                <span className="c-soft t-sm font-semibold">选错</span>
              </div>
              <div className="glass flex flex-1 flex-col items-center rounded-xl px-4 py-4">
                <span className="text-[1.9rem] font-extrabold tabular-nums text-[color:var(--c-info-text)]">{accuracy}%</span>
                <span className="c-soft t-sm font-semibold">正确率</span>
              </div>
            </div>

            {wrongWords.length > 0 ? (
              <div className="glass mx-auto mt-5 w-full max-w-3xl rounded-xl px-5 py-4">
                <h3 className="c-ink t-sm mb-2 font-bold">选错的词（没通过，下次还要再认一遍）</h3>
                <div className="flex flex-wrap gap-x-5 gap-y-2">
                  {wrongWords.map((w, i) => (
                    <span key={`${w.name}-${i}`} className="t-sm">
                      <span className="font-semibold text-[color:var(--c-danger-text)]">{w.name}</span>
                      <span className="c-muted ml-1.5">{w.trans[0]}</span>
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <p className="c-muted t-sm mt-5 text-center">全部一次选对，漂亮 🎉</p>
            )}

            {typableCount === 0 ? (
              <p className="c-muted t-sm mt-6 text-center">
                这一轮没有词通过，拼写练习暂时没有可拼的词 —— 再认一遍就能进拼写了。
              </p>
            ) : null}

            <div className="mt-7 flex justify-center gap-3">
              {/* 这里**不**清 session：接着去拼写要打的正是刚刚认过的那批词。
                  没认过（canType=false）的词会被拼写页自己滤掉，所以点了也不会漏。 */}
              {typableCount > 0 ? (
                <button type="button" className="my-btn-primary btn-lg" onClick={() => navigate('/typing')}>
                  接着去拼写 · {typableCount} 个词 →
                </button>
              ) : null}
              <button
                type="button"
                className="btn-secondary"
                onClick={() => {
                  setSession(null)
                  navigate('/')
                }}
              >
                返回今日
              </button>
            </div>
          </main>
        </div>
      </div>
    )
  }

  if (!question) {
    return (
      <div className="flex h-full w-full flex-col items-center">
        <Header />
        <div className="container-app mt-8 space-y-4">
          <div className="skeleton h-6 w-40" />
          <div className="skeleton h-64 w-full" />
        </div>
      </div>
    )
  }

  const progressPct = Math.round((index / questions.length) * 100)
  const answered = picked !== null
  const isWrongPicked = answered && picked !== question.answerIndex
  const isCardStep = phase === 'card'

  return (
    <div className="flex h-full w-full flex-col overflow-y-auto">
      <Header>
        <Link className="btn-secondary btn-sm" to="/" onClick={() => setSession(null)}>
          退出
        </Link>
      </Header>

      <div className="container-app flex min-h-0 flex-1 flex-col pb-5">
        {/* 进度 */}
        <div className="mb-1 flex w-full shrink-0 items-baseline justify-between">
          <span className="c-muted t-sm tabular-nums">
            第 {index + 1} / {questions.length} 个新词
          </span>
          <span className="c-muted t-sm tabular-nums">一次选对 {correctCount}</span>
        </div>
        <div className="progress-track progress-sm mb-4 w-full shrink-0">
          <div className="progress-fill" style={{ width: `${progressPct}%` }} />
        </div>

        {/* ── 左右两栏：左＝题卡，右＝答案/助记 ──
            答完立刻在右边给出完整词卡，左边专心做题，整页不用滚。 */}
        <div className="grid min-h-0 flex-1 grid-cols-1 gap-3.5 md:grid-cols-[minmax(0,1fr)_19rem]">
          {/* 左栏 */}
          <div className="flex min-h-0 flex-col">
            {isCardStep ? (
              <CardStep
                word={question.word}
                dictLanguage={dictInfo.language}
                pronunciationRef={pronunciationRef}
                onNext={() => setPhase('quiz')}
              />
            ) : (
              <QuizStep
                question={question}
                picked={picked}
                isWrongPicked={isWrongPicked}
                onChoose={choose}
                onContinue={goNext}
              />
            )}
          </div>

          {/* 右栏：答题前只给一句提示，答完（对错都算）换成完整词卡 */}
          <div className="min-h-0 max-h-[22rem] md:max-h-none">
            {isCardStep || answered ? (
              <WordDetailPanel
                key={`${question.word.name}-${isCardStep ? 'card' : 'answer'}`}
                word={question.word}
                lang={dictInfo.language}
                title={isCardStep ? '助记' : '答案'}
                showWordHead={!isCardStep}
                notice={
                  isWrongPicked && question.kind === 'exam' && question.explain ? (
                    /* ⚠️ 必须包一层 span：.alert 是 flex 容器，
                       裸文本 + <strong> + 文本会各自变成独立 flex 项，被挤成一列一列的字。 */
                    <span>
                      正确答案是 <strong>{question.choices[question.answerIndex]}</strong> · {question.explain}
                    </span>
                  ) : null
                }
              />
            ) : (
              <WordDetailPanel title="答案" placeholder="选完这里会出现这个词的完整词卡。" />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

/** 左栏·第 1 步：词卡 —— 先认脸，再出题 */
function CardStep({
  word,
  dictLanguage,
  pronunciationRef,
  onNext,
}: {
  word: Word
  dictLanguage: string
  pronunciationRef: RefObject<WordPronunciationIconRef>
  onNext: () => void
}) {
  return (
    <div className="glass-strong flex min-h-0 flex-1 flex-col items-center justify-center rounded-2xl px-8 py-6">
      <div className="flex items-center gap-3">
        <h2 className="c-ink text-[3rem] font-extrabold leading-none tracking-tight">{word.name}</h2>
        <WordPronunciationIcon ref={pronunciationRef} word={word} lang={dictLanguage} className="h-8 w-8" />
      </div>

      {word.usphone ? <p className="c-muted t-sm mt-2.5">AmE: [{word.usphone}]</p> : null}

      <div className="mt-4 space-y-1 text-center">
        {word.trans.map((t, i) => (
          <p key={i} className="c-ink-soft leading-relaxed">
            {t}
          </p>
        ))}
      </div>

      <div className="mt-8 flex flex-col items-center gap-2">
        <button type="button" className="my-btn-primary btn-lg" onClick={onNext}>
          记住了，出题
        </button>
        <span className="c-faint t-micro">按回车也可以 · 空格重放发音</span>
      </div>
    </div>
  )
}

/** 左栏·第 2 步：题干 + 四个选项 */
function QuizStep({
  question,
  picked,
  isWrongPicked,
  onChoose,
  onContinue,
}: {
  question: ReturnType<typeof buildRecallQuestions>[number]
  picked: number | null
  isWrongPicked: boolean
  onChoose: (i: number) => void
  onContinue: () => void
}) {
  const isEn2Zh = question.kind === 'en2zh'

  return (
    <div className="flex min-h-0 flex-1 flex-col justify-center">
      <div className="mb-2 flex items-center gap-2">
        <span className={`badge ${question.kind === 'exam' ? 'badge-brand' : 'badge-info'}`}>          {KIND_LABEL[question.kind]}
        </span>
        {picked === null ? <span className="c-faint t-micro">按 1 / 2 / 3 / 4 作答</span> : null}
      </div>

      {/* 题干 */}
      <div className="glass-strong shrink-0 rounded-2xl px-6 py-6">
        <p
          className={`c-ink text-center leading-relaxed ${
            isEn2Zh ? 'text-[2.4rem] font-extrabold leading-none tracking-tight' : question.kind === 'zh2en' ? 'text-2xl font-bold' : 'text-lg'
          }`}
        >
          {question.prompt}
        </p>
      </div>

      {/* 选项 */}
      <div className="mt-3 flex flex-col gap-2.5">
        {question.choices.map((choice, i) => {
          const isAnswer = i === question.answerIndex
          const isPicked = picked === i
          let cls = 'glass glass-interactive c-ink w-full rounded-2xl px-5 py-3.5 text-left'
          if (picked !== null) {
            if (isAnswer) {
              cls =
                'w-full rounded-2xl border-2 border-[color:var(--c-brand)] bg-[color:var(--c-brand-soft)] px-5 py-3.5 text-left font-semibold text-[color:var(--c-brand-text)]'
            } else if (isPicked) {
              cls =
                'w-full rounded-2xl border-2 border-[color:var(--c-danger)] bg-[rgba(217,44,44,0.08)] px-5 py-3.5 text-left text-[color:var(--c-danger-text)]'
            } else {
              cls = 'glass c-faint w-full rounded-2xl px-5 py-3.5 text-left opacity-55'
            }
          }
          return (
            <button key={`${choice}-${i}`} type="button" className={cls} onClick={() => onChoose(i)} disabled={picked !== null}>
              <span className="c-faint mr-3 inline-flex h-6 w-6 items-center justify-center rounded-lg border-2 border-[color:var(--c-line)] text-xs font-bold dark:border-gray-600">
                {i + 1}
              </span>
              {choice}
            </button>
          )
        })}
      </div>

      {/* 答错时把「继续」放在左栏底部；答案本身在右栏 */}
      {isWrongPicked ? (
        <div className="mt-5 flex flex-col items-center gap-2">
          <button type="button" className="my-btn-primary" onClick={onContinue}>
            知道了，继续
          </button>
          <span className="c-faint t-micro">按回车也可以 · 答案在右边</span>
        </div>
      ) : null}
    </div>
  )
}
