import { TypingContext, TypingStateActionType } from '@/pages/Typing/store'
import AdvancedSetting from './AdvancedSetting'
import DataSetting from './DataSetting'
import PlanSetting from './PlanSetting'
import SoundSetting from './SoundSetting'
import ViewSetting from './ViewSetting'
import { Dialog, Tab, Transition } from '@headlessui/react'
import classNames from 'classnames'
import { Fragment, useContext, useState } from 'react'
import IconAdjustmentsHorizontal from '~icons/tabler/adjustments-horizontal'
import IconCalendarStats from '~icons/tabler/calendar-stats'
import IconDatabaseCog from '~icons/tabler/database-cog'
import IconEar from '~icons/tabler/ear'
import IconPalette from '~icons/tabler/palette'
import IconSettings from '~icons/tabler/settings'
import IconX from '~icons/tabler/x'

/**
 * 设置。
 *
 * 2026-10-06 重做：
 *   · **入口**：原来藏在打字页「更多」面板最底部的那个 26×26px 小齿轮里（只有图标没有文字）。
 *     现在工具栏上直接放一个带文字的「设置」按钮。
 *   · **外观**：原来是原版的 stone/gray 配色（`bg-stone-50` / `text-neutral-500`），
 *     和全站的设计系统完全对不上。现在全部走 token（glass-strong 面板 + 品牌绿选中态）。
 *   · **内容**：多了「学习计划」一组 —— 每日新词量 / 每日复习上限以前**没有任何界面能改**。
 */

const TABS = [
  { name: '学习计划', icon: IconCalendarStats },
  { name: '音效设置', icon: IconEar },
  { name: '高级设置', icon: IconAdjustmentsHorizontal },
  { name: '显示设置', icon: IconPalette },
  { name: '数据设置', icon: IconDatabaseCog },
]

export default function Setting() {
  const [isOpen, setIsOpen] = useState(false)
  const { dispatch } = useContext(TypingContext) ?? {}

  function closeModal() {
    setIsOpen(false)
  }

  function openModal() {
    setIsOpen(true)
    if (dispatch) {
      // 打开设置时先暂停打字，免得在弹窗里敲键盘把词打了
      dispatch({ type: TypingStateActionType.SET_IS_TYPING, payload: false })
    }
  }

  return (
    <>
      <button className="btn-secondary btn-sm whitespace-nowrap" type="button" onClick={openModal} title="打开设置">
        <IconSettings className="h-4 w-4" />
        设置
      </button>

      <Transition appear show={isOpen} as={Fragment}>
        <Dialog as="div" className="relative z-50" onClose={closeModal}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-200"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-150"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black/40 backdrop-blur-[2px]" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-200"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-150"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="glass-strong flex w-full max-w-3xl flex-col overflow-hidden rounded-2xl">
                  <header className="flex shrink-0 items-center justify-between border-b border-[color:var(--c-line-soft)] px-5 py-3">
                    <h2 className="c-ink t-h2">设置</h2>
                    <button className="btn-ghost btn-sm" type="button" onClick={closeModal} title="关闭" aria-label="关闭设置">
                      <IconX className="h-4 w-4" />
                    </button>
                  </header>

                  <Tab.Group vertical>
                    <div className="flex h-[26rem] min-h-0">
                      <Tab.List className="flex w-44 shrink-0 flex-col gap-1 border-r border-[color:var(--c-line-soft)] p-2.5">
                        {TABS.map(({ name, icon: Icon }) => (
                          <Tab
                            key={name}
                            className={({ selected }) =>
                              classNames(
                                'flex items-center gap-2.5 rounded-lg px-3 py-2 text-left t-sm font-semibold outline-none transition-colors',
                                selected
                                  ? 'bg-[color:var(--c-brand-soft)] text-[color:var(--c-brand-text)]'
                                  : 'c-muted hover:bg-black/[0.04] dark:hover:bg-white/[0.06]',
                              )
                            }
                          >
                            <Icon className="h-4 w-4 shrink-0" />
                            {name}
                          </Tab>
                        ))}
                      </Tab.List>

                      {/* 面板内部自己滚，弹窗高度固定不变 */}
                      <Tab.Panels className="min-h-0 flex-1">
                        {[PlanSetting, SoundSetting, AdvancedSetting, ViewSetting, DataSetting].map((Panel, i) => (
                          <Tab.Panel key={i} className="h-full overflow-y-auto px-5 py-4 outline-none">
                            <Panel />
                          </Tab.Panel>
                        ))}
                      </Tab.Panels>
                    </div>
                  </Tab.Group>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </>
  )
}
