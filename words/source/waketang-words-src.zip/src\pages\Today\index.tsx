import Header from '@/components/Header'
import Setting from '@/components/Setting'
import { currentDictIdAtom, currentDictInfoAtom, dailyNewAtom, dailyReviewMaxAtom, reviewOnlyAtom, todaySessionAtom } from '@/store'
import type { TodaySessionWord } from '@/store'
import type { Word } from '@/typings'
import { db, useMemoryRecords } from '@/utils/db'
import { fetchWords, planUrl } from '@/utils/dictPlan'
import { buildTodayPlan, computeStreak, todayStr } from '@/utils/srs'
import { useLiveQuery } from 'dexie-react-hooks'
import { useAtom, useAtomValue, useSetAtom } from 'jotai'
import { useCallback, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import useSWR from 'swr'
import IconCheck from '~icons/tabler/check'
import IconChevronDown from '~icons/tabler/chevron-down'

/**
 * 今日 —— 蛙课堂背单词的首页。
 *
 * 打开程序先看到今天该背什么：多少词到期该复习（遗忘曲线排的）、今天安排多少新词、
 * 连续打卡多少天、词书学到哪了。点「开始学习」才带着这份计划进打字页。
 */

/**
 * 数据卡。
 *
 * 评审 B1-1：原来三个数字分别是蓝 / 绿 / 黑 —— 同一层级的信息用三种颜色，
 * 颜色在这里没有统一语义，只是噪音。
 * 现在：**数字一律深色**，含义靠左侧色条区分（第 2 批把色条改成通高 4px）。
 */
function StatCard({ value, label, hint, rail }: { value: number; label: string; hint?: string; rail: string }) {
  return (
    <div className="glass stat-card">
      <span className="stat-card-rail" style={{ backgroundColor: rail }} />
      <span className="c-ink text-[2.1rem] font-extrabold leading-none tabular-nums">{value}</span>
      <span className="c-soft mt-1.5 text-[13px] font-semibold">{label}</span>
      {hint ? <span className="c-faint mt-0.5 text-[11px]">{hint}</span> : null}
    </div>
  )
}

/** 最近 7 天的学习量（用打字记录聚合，给首页下半屏一点"学习轨迹"感） */
function useWeekActivity() {
  const since = useMemo(() => Math.floor(Date.now() / 1000) - 7 * 86400, [])
  const records = useLiveQuery(() => db.wordRecords.where('timeStamp').above(since).toArray(), [since], [])
  return useMemo(() => {
    const days: { date: string; label: string; count: number }[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      const key = todayStr(d)
      days.push({ date: key, label: '日一二三四五六'[d.getDay()], count: 0 })
    }
    const index = new Map(days.map((d) => [d.date, d]))
    for (const r of records) {
      const key = todayStr(new Date(r.timeStamp * 1000))
      const hit = index.get(key)
      if (hit) hit.count += 1
    }
    return days
  }, [records])
}

export default function TodayPage() {
  const navigate = useNavigate()
  const dictInfo = useAtomValue(currentDictInfoAtom)
  const dictId = useAtomValue(currentDictIdAtom)
  const dailyNew = useAtomValue(dailyNewAtom)
  const dailyReviewMax = useAtomValue(dailyReviewMaxAtom)
  const [reviewOnly, setReviewOnly] = useAtom(reviewOnlyAtom)
  const setSession = useSetAtom(todaySessionAtom)
  const [showRules, setShowRules] = useState(false)

  // ── 算计划只用「轻量索引」，不整本下词库 ──
  // 整本 CET-4 是 4366 KB，算「今天该背哪些词」根本用不上那么多字段；
  // 索引只有 256 KB（gzip 约 60 KB），在慢链路上差好几分钟。详见 utils/dictPlan.ts。
  const { data: planWords, isLoading, error } = useSWR<Word[]>(planUrl(dictInfo.url), (u: string) => fetch(u).then((r) => r.json()))
  const memory = useMemoryRecords(dictId)
  const week = useWeekActivity()

  const plan = useMemo(() => {
    if (!planWords) return null
    return buildTodayPlan(planWords, memory, { dailyNew, dailyReviewMax, reviewOnly })
  }, [planWords, memory, dailyNew, dailyReviewMax, reviewOnly])

  const streak = useMemo(() => computeStreak(memory.map((m) => m.lastReviewDate)), [memory])
  const stubbornCount = useMemo(() => memory.filter((m) => m.stubborn).length, [memory])

  const reviewCount = plan?.reviewWords.length ?? 0
  const newCount = plan?.newWords.length ?? 0
  const readyCount = plan?.readyToTypeWords.length ?? 0
  /** 可拼写的词 = 到期复习 + 今天已认过还没拼的。没认过的新词进不来（先认后拼） */
  const typeCount = reviewCount + readyCount

  /** 今天计划里要碰到的全部词名（顺序：复习 → 已认待拼 → 待认） */
  const sessionNames = useMemo(
    () =>
      plan
        ? [
            ...plan.reviewWords.map((w) => w.name),
            ...plan.readyToTypeWords.map((w) => w.name),
            ...plan.newWords.map((w) => w.name),
          ]
        : [],
    [plan],
  )

  // 只把这几百个词命中的那 1–2 片完整数据取回来（含音标、词根词缀、例句）
  const { data: fullWords } = useSWR<Word[]>(
    sessionNames.length > 0 ? ['hydrate', dictInfo.url, sessionNames.join('|')] : null,
    () => fetchWords(dictInfo.url, sessionNames),
  )
  const wordByName = useMemo(() => new Map((fullWords ?? []).map((w) => [w.name, w])), [fullWords])
  /** 词卡还没准备好的话，开始按钮先别让点 —— 否则进去会出现空词表 */
  const isReady = sessionNames.length > 0 && wordByName.size >= sessionNames.length

  const start = useCallback(
    (target: '/recall' | '/typing') => {
      if (!plan || !isReady) return
      if (target === '/recall' ? newCount === 0 : typeCount === 0) return

      // 会话里带着今天全部三类词，各自标记能不能拼：
      //   · 复习词                isReview=true  canType=true
      //   · 今天认过、还没拼的     isReview=false canType=true
      //   · 还没认过的（待认）     isReview=false canType=false  ← 门禁拦的就是这批
      // 选词记忆页只挑 canType=false 的做；拼写页只挑 canType=true 的做。
      // 顺序不能乱：复习 → 已认待拼 → 待认。
      const pick = (names: string[], isReview: boolean, canType: boolean): TodaySessionWord[] =>
        names
          .map((n) => wordByName.get(n))
          .filter((w): w is Word => Boolean(w))
          .map((w) => ({ ...w, isReview, canType }))

      const words: TodaySessionWord[] = [
        ...pick(
          plan.reviewWords.map((w) => w.name),
          true,
          true,
        ),
        ...pick(
          plan.readyToTypeWords.map((w) => w.name),
          false,
          true,
        ),
        ...pick(
          plan.newWords.map((w) => w.name),
          false,
          false,
        ),
      ]
      setSession({ words })
      navigate(target)
    },
    [plan, isReady, newCount, typeCount, wordByName, setSession, navigate],
  )

  const dateText = useMemo(
    () => new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' }),
    [],
  )

  const learnedPct = plan && plan.totalWords > 0 ? Math.round((plan.learnedWords / plan.totalWords) * 100) : 0
  const weekMax = Math.max(1, ...week.map((d) => d.count))

  return (
    <div className="flex h-full w-full flex-col items-center overflow-y-auto">
      <Header>
        <Link className="btn-secondary btn-sm" to="/gallery">
          词库
        </Link>
        <Link className="btn-secondary btn-sm" to="/analysis">
          统计
        </Link>
        <Link className="btn-secondary btn-sm" to="/error-book">
          错词本
        </Link>
        {/* 设置：打开程序第一眼就能看到，不用先钻进打字页 */}
        <Setting />
      </Header>

      {/* justify-center：内容不满一屏时在剩余空间里垂直居中，
          不再全堆在上半屏、下半屏一大片空。内容超高时 flex-1 自然撑开，不会截断。 */}
      <main className="container-app flex flex-1 flex-col items-center justify-center pb-10">
        {/* 问候条：日期 + 连续打卡合成一条，不再是两行孤零零的灰字 */}
        <div className="greet-bar">
          <span className="c-ink-soft t-sm font-semibold">{dateText}</span>
          {streak > 0 ? (
            <span className="badge badge-brand">🔥 连续打卡 {streak} 天</span>
          ) : (
            <span className="c-faint t-micro">今天开始打卡</span>
          )}
        </div>

        {isLoading ? (
          <div className="mt-4 grid w-full grid-cols-3 gap-3">
            <div className="skeleton h-[96px]" />
            <div className="skeleton h-[96px]" />
            <div className="skeleton h-[96px]" />
          </div>
        ) : error ? (
          <p className="c-danger mt-20">词库加载失败：{String(error)}</p>
        ) : plan ? (
          <>
            {/* 今日任务。三张卡的语义按「先认后拼」排：
                待认 → 待复习 → 可拼写 */}
            <div className="mt-4 flex w-full gap-3">
              <StatCard
                value={newCount}
                label="待认词"
                rail="var(--c-brand)"
                hint={reviewOnly ? '今天只复习，已关闭' : `选词记忆 · 上限 ${dailyNew}`}
              />
              <StatCard value={reviewCount} label="待复习" rail="var(--c-info)" hint="按遗忘曲线到期" />
              <StatCard
                value={typeCount}
                label="可拼写"
                rail="var(--c-faint)"
                hint={`复习 ${reviewCount} + 已认 ${readyCount}`}
              />
            </div>

            {/* 先认后拼的提示：还有没认过的词时明说一句，别让用户以为拼写漏词了 */}
            {newCount > 0 && readyCount === 0 ? (
              <div className="alert alert-info mt-4">
                <span>今天还有 {newCount} 个词没认过 —— 先在左边过一遍选词记忆，认过的词才会进拼写练习。</span>
              </div>
            ) : null}

            {/* 积压提示：带一键操作，而不是干说一句 */}
            {plan.backlog ? (
              <div className="alert alert-warn mt-4">
                <span>复习积压较多：共 {plan.dueTotal} 个到期，建议先清复习、暂时少学新词。</span>
                <button type="button" className="btn-secondary btn-sm ml-auto shrink-0" onClick={() => setReviewOnly(true)}>
                  只清复习
                </button>
              </div>
            ) : null}

            {/* 两步走：左边先把今天的新词认一遍，右边拼写。
                「先认后拼」—— 没认过的词不会进拼写练习（用户 2026-10-06 拍板）。 */}
            {newCount === 0 && typeCount === 0 ? (
              <button type="button" disabled className="my-btn-primary btn-lg mt-5 w-full max-w-md">
                今天没有任务了 🎉
              </button>
            ) : (
              <div className="mt-5 flex w-full max-w-2xl gap-3">
                <button
                  type="button"
                  className="my-btn-primary btn-lg flex flex-1 flex-col gap-0.5 py-3"
                  disabled={newCount === 0 || !isReady}
                  onClick={() => start('/recall')}
                >
                  <span className="text-base font-bold leading-tight">① 选词记忆</span>
                  <span className="text-[11px] font-medium leading-tight opacity-90">
                    {!isReady ? '正在准备词卡…' : newCount === 0 ? '今天没有要认的词' : `先认这 ${newCount} 个词`}
                  </span>
                </button>

                <button
                  type="button"
                  className="btn-secondary btn-lg flex flex-1 flex-col gap-0.5 py-3"
                  disabled={typeCount === 0 || !isReady}
                  onClick={() => start('/typing')}
                >
                  <span className="text-base font-bold leading-tight">② 拼写练习</span>
                  <span className="text-[11px] font-medium leading-tight">
                    {!isReady
                      ? '正在准备词卡…'
                      : typeCount === 0
                        ? '先把左边的词认一遍'
                        : `${typeCount} 个词${newCount > 0 ? `（还有 ${newCount} 个没认）` : ''}`}
                  </span>
                </button>
              </div>
            )}

            {/* 自定义勾选框：与设置页的胶囊开关同属一套 token，不再用浏览器原生 checkbox */}
            <button
              type="button"
              role="checkbox"
              aria-checked={reviewOnly}
              onClick={() => setReviewOnly(!reviewOnly)}
              className="c-soft t-sm mt-3 flex cursor-pointer select-none items-center gap-2"
            >
              <span className="checkbox" data-checked={reviewOnly}>
                {reviewOnly ? <IconCheck className="h-3 w-3" /> : null}
              </span>
              今天只复习，不学新词
            </button>

            {/* 学习概览：词书进度 + 最近 7 天并成一张卡。
                原来这是两张上下叠的全宽白卡，加上前面的数字卡，整屏就是「一摞一样的白条」，
                没有节奏。并成一张、左右分栏之后首屏矮了一截，也不用滚。 */}
            <div className="glass mt-6 w-full rounded-2xl px-5 py-4 md:grid md:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)] md:gap-7 md:divide-x md:divide-[color:var(--c-line-soft)]">
              {/* 左：词书进度 */}
              <section className="flex flex-col md:pr-1">
                <div className="flex items-baseline justify-between">
                  <span className="c-ink t-sm font-bold">当前词书：{dictInfo.name}</span>
                  <Link to="/gallery" className="btn-secondary btn-sm">
                    换词书
                  </Link>
                </div>

                <div className="progress-track mt-3">
                  <div className="progress-fill" style={{ width: `${learnedPct}%` }} />
                </div>

                <div className="c-faint t-micro mt-2 flex justify-between">
                  <span>
                    已学 {plan.learnedWords} / {plan.totalWords}（{learnedPct}%）
                  </span>
                  <span>
                    已掌握 {plan.masteredWords} · 生词本 {stubbornCount}
                  </span>
                </div>
              </section>

              {/* 右：最近 7 天（竖向柱状图） */}
              <section className="mt-5 flex flex-col md:mt-0 md:pl-6">
                <div className="mb-3 flex items-baseline justify-between">
                  <span className="c-ink t-sm font-bold">最近 7 天</span>
                  <Link to="/analysis" className="c-brand t-micro font-bold hover:underline">
                    看完整统计
                  </Link>
                </div>

                <div className="flex flex-1 items-end justify-between gap-1.5">
                  {week.map((d, i) => {
                    const isToday = i === week.length - 1
                    const pct = d.count > 0 ? Math.max(12, Math.round((d.count / weekMax) * 100)) : 0
                    return (
                      <div key={d.date} className="flex flex-1 flex-col items-center gap-1">
                        <span className={`t-micro tabular-nums ${d.count > 0 ? 'c-ink-soft font-semibold' : 'c-faint'}`}>
                          {d.count || '·'}
                        </span>
                        <div className="week-bar-track h-14">
                          <div className="week-bar-fill" data-today={isToday} style={{ height: `${pct}%` }} />
                        </div>
                        <span className={`t-micro ${isToday ? 'c-brand font-bold' : 'c-faint'}`}>{isToday ? '今天' : d.label}</span>
                      </div>
                    )
                  })}
                </div>
              </section>
            </div>

            {/* 系统规则收进按需展开，不再常驻占首屏 */}
            <button type="button" className="btn-ghost btn-sm mt-4" onClick={() => setShowRules((v) => !v)}>
              遗忘曲线复习 · 打错的词次日重来
              <IconChevronDown className={`h-3.5 w-3.5 transition-transform ${showRules ? 'rotate-180' : ''}`} />
            </button>
            {showRules ? (
              <div className="c-muted t-sm glass mt-2 w-full rounded-xl px-4 py-3 leading-relaxed">
                学完 → 次日 → 2 天 → 4 天 → 7 天 → 15 天 → 掌握。
                <br />
                打错的词回退两档、次日重来，并自动进生词本。
              </div>
            ) : null}
          </>
        ) : null}
      </main>
    </div>
  )
}
