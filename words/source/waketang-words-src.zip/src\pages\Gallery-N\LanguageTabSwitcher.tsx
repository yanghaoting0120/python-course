import { GalleryContext } from '.'
import type { LanguageCategoryType } from '@/typings'
import { useCallback, useContext } from 'react'

/**
 * 语言切换。
 *
 * 评审 B4-5 / C15：原来用国旗 emoji + 中英混排（「🇬🇧 英语 / 👨‍💻 Code」），
 * 与本项目"只有英语 + 编程词书"的实情相比显得是原版通用框架的残留。
 * 现在改成两枚胶囊 Tab，去 emoji（emoji 在不同系统渲染差异大，
 * 也和整体线性图标风格不一致），文案统一中文。
 *
 * 注：原来引用的 flags/*.png 因此不再需要，已连同目录一起删除。
 */

export type LanguageTabOption = {
  id: LanguageCategoryType
  name: string
}

const options: LanguageTabOption[] = [
  { id: 'en', name: '英语' },
  { id: 'code', name: '编程' },
]

export function LanguageTabSwitcher() {
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  const { state, setState } = useContext(GalleryContext)!

  const onChangeTab = useCallback(
    (tab: string) => {
      setState((draft) => {
        draft.currentLanguageTab = tab as LanguageCategoryType
      })
    },
    [setState],
  )

  return (
    <div className="flex items-center gap-2" role="tablist" aria-label="词库分类">
      {options.map((option) => {
        const active = state.currentLanguageTab === option.id
        return (
          <button
            key={option.id}
            type="button"
            role="tab"
            aria-selected={active}
            className={`tab ${active ? 'tab-active' : ''}`}
            onClick={() => onChangeTab(option.id)}
          >
            {option.name}
          </button>
        )
      })}
    </div>
  )
}
