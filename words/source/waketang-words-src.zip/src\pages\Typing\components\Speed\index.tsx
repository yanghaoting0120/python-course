import { TypingContext } from '../../store'
import InfoBox from './InfoBox'
import { useContext } from 'react'

/**
 * 底部统计条。
 *
 * 评审 B2-4：原来 5 个指标里「时间 / 输入数 / WPM / 正确率」是**打字练习软件**的指标，
 * 与"背单词"这个目标无关（而且是整条 opacity-50，像是刻意让它不重要）。
 * 现在换成对学习有意义的四项：本轮进度 / 一遍过 / 打错过 / 用时。
 */
export default function Speed() {
  // eslint-disable-next-line  @typescript-eslint/no-non-null-assertion
  const { state } = useContext(TypingContext)!
  const seconds = state.timerData.time % 60
  const minutes = Math.floor(state.timerData.time / 60)
  const secondsString = seconds < 10 ? '0' + seconds : seconds + ''
  const minutesString = minutes < 10 ? '0' + minutes : minutes + ''

  const total = state.chapterData.words.length
  const progress = total > 0 ? `${Math.min(state.chapterData.index + 1, total)} / ${total}` : '0 / 0'

  const logs = state.chapterData.userInputLogs ?? []
  const cleanWords = logs.filter((l) => l.correctCount > 0 && l.wrongCount === 0).length
  const fumbledWords = logs.filter((l) => l.wrongCount > 0).length

  return (
    <div className="glass flex w-full rounded-xl px-6 py-3 transition-colors duration-300">
      <InfoBox info={progress} description="本轮" />
      <InfoBox info={cleanWords + ''} description="一遍过" />
      <InfoBox info={fumbledWords + ''} description="打错过" />
      <InfoBox info={`${minutesString}:${secondsString}`} description="用时" />
    </div>
  )
}
