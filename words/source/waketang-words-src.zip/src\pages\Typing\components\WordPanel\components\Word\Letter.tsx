import { EXPLICIT_SPACE } from '@/constants'
import { fontSizeConfigAtom } from '@/store'
import { useAtomValue } from 'jotai'
import React from 'react'

/**
 * 字母状态。
 *
 * 原版只有 normal / correct / wrong —— 没有「当前该打哪个」的锚点，
 * 打完两个字母后视线无法立刻锁定位置。新增 active 表示"下一个待输入"。
 */
export type LetterState = 'normal' | 'correct' | 'wrong' | 'active'

const stateClassNameMap: Record<string, Record<LetterState, string>> = {
  true: {
    normal: 'c-faint',
    correct: 'text-green-400 dark:text-green-700',
    wrong: 'text-red-400 dark:text-red-600',
    active: 'c-brand letter-active',
  },
  false: {
    normal: 'c-soft',
    correct: 'text-green-600 dark:text-green-400',
    wrong: 'text-red-600 dark:text-red-400',
    active: 'c-brand letter-active',
  },
}

export type LetterProps = {
  letter: string
  state?: LetterState
  visible?: boolean
}

const Letter: React.FC<LetterProps> = ({ letter, state = 'normal', visible = true }) => {
  const fontSizeConfig = useAtomValue(fontSizeConfigAtom)
  return (
    <span
      className={`m-0 p-0 font-mono font-normal ${
        stateClassNameMap[(letter === EXPLICIT_SPACE) as unknown as string][state]
      } pr-0.8 duration-0 dark:text-opacity-80`}
      style={{ fontSize: fontSizeConfig.foreignFont.toString() + 'px' }}
    >
      {visible ? letter : '_'}
    </span>
  )
}

export default React.memo(Letter)
