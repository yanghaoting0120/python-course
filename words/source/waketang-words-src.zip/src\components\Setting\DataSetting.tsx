import { Row, Section, StateChip, Toggle } from './parts'
import type { ExportProgress, ImportProgress } from '@/utils/db/data-export'
import { exportDatabase, importDatabase } from '@/utils/db/data-export'
import { useCallback, useState } from 'react'

/**
 * 数据设置 —— 导出 / 导入。
 * 2026-10-06：配色和按钮改走设计系统（原来那个 `bg-gray-200` 进度条和 `disabled:bg-gray-300`
 * 在深色模式下几乎看不见），进度条换成全站统一的 `.progress-track / .progress-fill`。
 */
export default function DataSetting() {
  const [isExporting, setIsExporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [isImporting, setIsImporting] = useState(false)
  const [importProgress, setImportProgress] = useState(0)

  const exportProgressCallback = useCallback(({ totalRows, completedRows, done }: ExportProgress) => {
    if (done) {
      setIsExporting(false)
      setExportProgress(100)
      return true
    }
    if (totalRows) setExportProgress(Math.floor((completedRows / totalRows) * 100))
    return true
  }, [])

  const onClickExport = useCallback(() => {
    setExportProgress(0)
    setIsExporting(true)
    exportDatabase(exportProgressCallback)
  }, [exportProgressCallback])

  const importProgressCallback = useCallback(({ totalRows, completedRows, done }: ImportProgress) => {
    if (done) {
      setIsImporting(false)
      setImportProgress(100)
      return true
    }
    if (totalRows) setImportProgress(Math.floor((completedRows / totalRows) * 100))
    return true
  }, [])

  const onStartImport = useCallback(() => {
    setImportProgress(0)
    setIsImporting(true)
  }, [])

  const onClickImport = useCallback(() => {
    importDatabase(onStartImport, importProgressCallback)
  }, [importProgressCallback, onStartImport])

  return (
    <>
      <Section
        title="数据导出"
        hint="练习记录只保存在这台电脑本地，不会上传到任何服务器。换电脑或重装前请先导出备份。"
      >
        <div className="glass rounded-xl px-4 py-3">
          <div className="mb-2 flex items-baseline justify-between">
            <span className="c-ink-soft t-sm font-semibold">导出进度</span>
            <span className="c-muted t-micro tabular-nums">{exportProgress}%</span>
          </div>
          <div className="progress-track">
            <div className="progress-fill" style={{ width: `${exportProgress}%` }} />
          </div>
        </div>

        <button className="btn-secondary btn-sm" type="button" onClick={onClickExport} disabled={isExporting} title="导出数据">
          {isExporting ? '正在导出…' : '导出数据'}
        </button>

        <p className="c-faint t-micro leading-relaxed">
          为了数据安全，请不要手动修改导出的数据文件。
        </p>
      </Section>

      <Section title="数据导入" hint="导入会完全覆盖当前数据，请谨慎操作。">
        <div className="glass rounded-xl px-4 py-3">
          <div className="mb-2 flex items-baseline justify-between">
            <span className="c-ink-soft t-sm font-semibold">导入进度</span>
            <span className="c-muted t-micro tabular-nums">{importProgress}%</span>
          </div>
          <div className="progress-track">
            <div className="progress-fill" style={{ width: `${importProgress}%` }} />
          </div>
        </div>

        <button className="btn-secondary btn-sm" type="button" onClick={onClickImport} disabled={isImporting} title="导入数据">
          {isImporting ? '正在导入…' : '导入数据'}
        </button>

        <div className="alert alert-danger">
          <span>导入会覆盖当前全部练习记录，操作前建议先导出一份备份。</span>
        </div>
      </Section>
    </>
  )
}
