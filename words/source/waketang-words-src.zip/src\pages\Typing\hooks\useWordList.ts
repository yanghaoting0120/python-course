import { CHAPTER_LENGTH } from '@/constants'
import { currentChapterAtom, currentDictInfoAtom, reviewModeInfoAtom, todaySessionAtom } from '@/store'
import type { Word, WordWithIndex } from '@/typings/index'
import { wordListFetcher } from '@/utils/wordListFetcher'
import { useAtom, useAtomValue } from 'jotai'
import { useMemo } from 'react'
import useSWR from 'swr'

export type UseWordListResult = {
  words: WordWithIndex[]
  isLoading: boolean
  error: Error | undefined
}

/**
 * Use word lists from the current selected dictionary.
 *
 * 蛙课堂背单词改动：
 * 移除了原版针对 CET-4 第 1 章的 20 个「示范单词」硬编码。
 * 原版只要「选中 cet4 且在第 0 章」就展示那 20 个写死的词、完全不读真实词库，
 * 会让艾宾浩斯复习和统计拿到假数据。现在一律读真实词库。
 */
export function useWordList(): UseWordListResult {
  const currentDictInfo = useAtomValue(currentDictInfoAtom)
  const [currentChapter, setCurrentChapter] = useAtom(currentChapterAtom)
  const { isReviewMode, reviewRecord } = useAtomValue(reviewModeInfoAtom)
  const todaySession = useAtomValue(todaySessionAtom)

  // Reset current chapter to 0, when currentChapter is greater than chapterCount.
  if (currentChapter >= currentDictInfo.chapterCount) {
    setCurrentChapter(0)
  }

  const { data: wordList, error, isLoading } = useSWR(currentDictInfo.url, wordListFetcher)

  const words: WordWithIndex[] = useMemo(() => {
    let newWords: Word[]
    if (todaySession) {
      // 今日学习：词表由艾宾浩斯计划给出（复习词在前、已认待拼的词在后）。
      // 「先认后拼」门禁：没在选词记忆里答对过的词 canType 为 false，这里直接剔掉 ——
      // 所以就算会话里带着它们，也进不了拼写。
      newWords = todaySession.words.filter((w) => w.canType)
    } else if (isReviewMode) {
      newWords = reviewRecord?.words ?? []
    } else if (wordList) {
      newWords = wordList.slice(currentChapter * CHAPTER_LENGTH, (currentChapter + 1) * CHAPTER_LENGTH)
    } else {
      newWords = []
    }

    // 记录原始 index, 并对 word.trans 做兜底处理
    return newWords.map((word, index) => {
      let trans: string[]
      if (Array.isArray(word.trans)) {
        trans = word.trans.filter((item) => typeof item === 'string')
      } else if (word.trans === null || word.trans === undefined || typeof word.trans === 'object') {
        trans = []
      } else {
        trans = [String(word.trans)]
      }
      return {
        ...word,
        index,
        trans,
      }
    })
  }, [todaySession, isReviewMode, wordList, reviewRecord?.words, currentChapter])

  return { words, isLoading, error }
}
