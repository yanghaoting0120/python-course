import { classNames } from '@/utils'
import type { ReactNode } from 'react'
import { useCallback, useRef, useState } from 'react'

/**
 * 轻量提示框（纯 CSS 定位，不引 floating-ui —— 它的默认位置是写死的绝对定位，
 * 用在「读音标切换」这类既有布局里有风险）。
 *
 * 2026-10-06 修的一个真 bug：
 *   打字页工具栏在页面最顶上，「开始」「美音」这两个按钮的提示框按默认的 top 方向
 *   渲染到按钮**上方**，一量 top = -15px —— 24px 高的提示框有一大半跑到窗口外面，
 *   字完全看不见，只露出底下一道白边（用户截图指出来的就是这个）。
 *   现在改成：先看首选方向放不放得下，放不下就自动翻到另一侧。
 */
const Tooltip = ({ children, content, className, placement = 'top' }: TooltipProps) => {
  const [visible, setVisible] = useState(false)
  const [side, setSide] = useState<'top' | 'bottom'>(placement)
  const anchorRef = useRef<HTMLDivElement>(null)
  const tipRef = useRef<HTMLSpanElement>(null)

  const placementClasses = {
    top: 'bottom-full pb-2',
    bottom: 'top-full pt-2',
  }[side]

  const show = useCallback(() => {
    const rect = anchorRef.current?.getBoundingClientRect()
    if (rect) {
      // 提示框自身高度 + 与按钮之间的间距（pb-2 / pt-2 = 8px，再留 4px 余量）
      const need = (tipRef.current?.offsetHeight ?? 26) + 12
      const roomAbove = rect.top
      const roomBelow = window.innerHeight - rect.bottom
      const fitsPreferred = placement === 'top' ? roomAbove >= need : roomBelow >= need

      if (fitsPreferred) {
        setSide(placement)
      } else {
        // 首选方向放不下：另一侧放得下就翻过去，两边都放不下就维持原样（至少能露出一部分）
        const other = placement === 'top' ? roomBelow : roomAbove
        setSide(other >= need ? (placement === 'top' ? 'bottom' : 'top') : placement)
      }
    }
    setVisible(true)
  }, [placement])

  return (
    <div className={classNames('relative', className)}>
      <div
        ref={anchorRef}
        onMouseEnter={show}
        onMouseLeave={() => setVisible(false)}
        onFocus={show}
        onBlur={() => setVisible(false)}
      >
        {children}
      </div>
      <div
        className={`${
          visible ? 'opacity-100' : 'opacity-0'
        } ${placementClasses} pointer-events-none absolute left-1/2 z-50 flex -translate-x-1/2 transform items-center justify-center transition-opacity`}
      >
        <span ref={tipRef} className="tooltip">
          {content}
        </span>
      </div>
    </div>
  )
}

export type TooltipProps = {
  children: ReactNode
  /** 显示文本 */
  content: string
  /** 首选方向；上方放不下会自动翻到下方 */
  placement?: 'top' | 'bottom'
  className?: string
}

export default Tooltip
